# -*- coding: utf-8 -*-
# Θ B4 三规则分析(2026-10-12):Avg@k / Maj@k / Pass@k —— 损毁形态判读
# 数据源:user-b A1 重评 146 个 per_env_scores.json(已拉回本地)
# 判读(预注册 theta_prereg §三):崩溃模型 Avg@k 崩而 Pass@k 残留=压均值不抹支撑集;
# 两者同崩=支撑集级损毁(与 P4/P11 权重级互证)
import json, os, re, glob
from collections import defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))
files = glob.glob(os.path.join(BASE, '**', 'per_env_scores.json'), recursive=True)

# 分组:ckpt 基名(去 -a1sNN / -g2rNN / -rvNN / -sNN 评测种子后缀)
def base_name(path):
    d = path.replace('\\', '/')
    m = re.search(r'([^/]+)/global_step_\d+/evaluation/per_env_scores\.json', d)
    if not m:
        return None
    name = m.group(1)
    name = re.sub(r'-(a1s\d+|g2r\d+|rv\d+|s\d+)$', '', name)
    return name

groups = defaultdict(list)
for f in files:
    b = base_name(f)
    if b:
        groups[b].append(f)

def load_envs(path):
    data = json.load(open(path))
    vals = []
    for item in data:
        r = item.get('reward', 0)
        if isinstance(r, dict):
            vals.append(max((float(v) for v in r.values()), default=0.0))
        elif isinstance(r, (int, float)):
            vals.append(float(r))
        else:
            vals.append(0.0)
    return vals

rows = []
for name, fl in sorted(groups.items()):
    if len(fl) < 2:
        continue  # k>=2 才能算三规则
    envs_per_seed = [load_envs(f) for f in fl]
    n_env = min(len(e) for e in envs_per_seed)
    k = len(envs_per_seed)
    # 对齐 env 序(按列表序;dict 已 values 序)
    pass_sum = maj_sum = avg_sum = 0.0
    for i in range(n_env):
        scores = [e[i] for e in envs_per_seed]
        passes = [1.0 if s > 0 else 0.0 for s in scores]
        pass_sum += 1.0 if any(p > 0 for p in passes) else 0.0   # Pass@k
        maj_sum += 1.0 if sum(passes) * 2 > k else 0.0            # Maj@k(严格多数)
        avg_sum += sum(passes) / k                                # Avg@k
    rows.append((name, k, n_env, avg_sum / n_env, maj_sum / n_env, pass_sum / n_env))

# 崩溃带/平台带代表
KEY = ['fl-q3-1b7-consol2', 'theta-fl-static-s2', 'theta-fl-static-s4', 'theta-sk1b7-static-s4',
       'theta-b2-lr25-s2l', 'theta-b2-lr25-s4l', 'e2a-guard-r3', 'e2a-guard-r5rt',
       'e2a-adaptive-r1', 'e2a-adaptive-r4', 'theta-b1-1x150', 'theta-b1-6x25-r1',
       'theta-sk-refresh-r3', 'theta-fl-refresh-r3']

out = os.path.join(BASE, 'b4_results.md')
with open(out, 'w', encoding='utf-8') as w:
    w.write('# B4 三规则全表(Avg@k/Maj@k/Pass@k;数据=user-b A1 per_env,146 文件,%d 组 k>=2)\n\n' % len(rows))
    w.write('| ckpt | k | n_env | Avg@k | Maj@k | Pass@k | Pass−Avg |\n|---|---|---|---|---|---|---|\n')
    for name, k, n, a, m, p in rows:
        mark = ' **' if any(name.startswith(x) for x in KEY) else ''
        w.write('|%s%s | %d | %d | %.3f | %.3f | %.3f | %+.3f |\n' % (name, mark, k, n, a, m, p, p - a))
    w.write('\n(标粗=判读关键模型;Pass−Avg>0 且显著=支撑集残留)\n')
print('groups k>=2:', len(rows))
print('written:', out)
# 关键模型速览
for name, k, n, a, m, p in rows:
    if any(name.startswith(x) for x in KEY):
        print('%-28s k=%d Avg=%.3f Maj=%.3f Pass=%.3f gap=%+.3f' % (name, k, a, m, p, p - a))
