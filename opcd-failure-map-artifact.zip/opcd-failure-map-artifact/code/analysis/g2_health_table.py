# -*- coding: utf-8 -*-
# G2: 健康指标表(H20 链)——每链的 acc/entropy/grad_norm 首末段统计
# 数据源:h20_health_raw.txt(链名 step:N curr_acc/entropy/policy_loss/grad_norm)
import re
from collections import defaultdict

rows = defaultdict(list)
for line in open('h20_health_raw.txt', encoding='utf-8', errors='ignore'):
    m = re.match(r'(\S+) step:(\d+) - actor/curr_acc:([\d.]+) - actor/exp_entropy:([\d.]+) - actor/policy_loss:([\d.]+) - actor/entropy:([\d.]+) - actor/grad_norm:([\d.]+)', line.strip())
    if m:
        rows[m.group(1)].append((int(m.group(2)), float(m.group(3)), float(m.group(4)), float(m.group(5)), float(m.group(6)), float(m.group(7))))

out = ['# G2 健康指标表(H20 链:acc/entropy/grad_norm 首末段)\n',
       '| 链 | n_step | acc 首→末 | entropy 首→末 | grad_norm 首5均→末5均 | 形态 |\n|---|---|---|---|---|---|\n']
for name, rs in sorted(rows.items()):
    rs.sort()
    if len(rs) < 2:
        continue
    acc0, acc1 = rs[0][1], rs[-1][1]
    ent0, ent1 = rs[0][4], rs[-1][4]
    gn_first = sum(r[5] for r in rs[:5]) / min(5, len(rs))
    gn_last = sum(r[5] for r in rs[-5:]) / min(5, len(rs))
    shape = []
    if ent1 < 0.132:
        shape.append('sharpening')
    if ent1 > 0.150:
        shape.append('flattening')
    if acc1 < 0.15 and acc0 >= 0.15:
        shape.append('acc崩溃')
    out.append('| %s | %d | %.3f→%.3f | %.3f→%.3f | %.2f→%.2f | %s |\n' % (
        name, len(rs), acc0, acc1, ent0, ent1, gn_first, gn_last, '/'.join(shape) or '带内'))
open('g2_health_table.md', 'w', encoding='utf-8').write(''.join(out))
print(''.join(out[1:]))
