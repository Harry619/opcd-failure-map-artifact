# -*- coding: utf-8 -*-
# G3: 关键模型 k 种子均值的 bootstrap 95% CI(per-env 重采样, 2000 次)
import json, os, re, glob, random
from collections import defaultdict

random.seed(31)
BS = chr(92)
files = glob.glob(os.path.join('.', '**', 'per_env_scores.json'), recursive=True)

def base_name(path):
    d = path.replace(BS, '/')
    m = re.search(r'([^/]+)/global_step_' + r'\d+' + r'/evaluation/per_env_scores' + r'\.json', d)
    if not m:
        return None
    return re.sub(r'-(a1s\d+|g2r\d+|rv\d+|s\d+)$', '', m.group(1))

def load_envs(path):
    data = json.load(open(path))
    vals = []
    for item in data:
        r = item.get('reward', 0)
        if isinstance(r, dict):
            vals.append(max((float(v) for v in r.values()), default=0.0))
        elif isinstance(r, (int, float)):
            vals.append(float(r))
        else:
            vals.append(0.0)
    return [1.0 if v > 0 else 0.0 for v in vals]

groups = defaultdict(list)
for f in files:
    b = base_name(f)
    if b:
        groups[b].append(load_envs(f))

KEY = ['fl-q3-1b7-consol2', 'theta-fl-static-s2', 'theta-fl-static-s3', 'theta-fl-static-s4',
       'e2a-guard-r1', 'e2a-guard-r3', 'e2a-guard-r1rt', 'theta-fl-refresh-r3b', 'theta-fl-refresh-r4b',
       'theta-sk1b7-static-s4', 'theta-sk1b7-static-s5', 'theta-b2-lr25-s2l']

out = []
for name, seeds in sorted(groups.items()):
    if not any(name.startswith(x) for x in KEY) or len(seeds) < 2:
        continue
    n = min(len(s) for s in seeds)
    seeds = [s[:n] for s in seeds]
    k = len(seeds)
    obs = sum(sum(s) for s in seeds) / (k * n)
    bs = []
    for _ in range(2000):
        idx = [random.randrange(n) for _ in range(n)]
        bs.append(sum(seeds[q][i] for i in idx for q in range(k)) / (k * n))
    bs.sort()
    lo, hi = bs[49], bs[1949]
    out.append('%-26s k=%d mean=%.3f CI95=[%.3f, %.3f] width=%.3f' % (name, k, obs, lo, hi, hi - lo))

open('g3_bootstrap_ci.txt', 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
