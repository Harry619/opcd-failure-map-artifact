#!/bin/bash
# Θ B6 采集器 v3(H20,2026-10-18 晚):v2 两处修正——
# ① merge_model2hf 需先向输出目录预置小文件(config/tokenizer),v2 的 rm -rf+裸 merge 必败
# ② math_eval.sh 必须传 --use_bsl true 才会用 --model 指的 HF;否则读空 /tmp staging(=v1 死因)
# 流程:等 GPU 窗口(72h 上限;try 若真跑完 50 步,窗口=训练退出)→选最高完整断点→merge(已合格则跳过)
#     →数据 stage→1000 题终评(use_bsl)→RESULT+marker
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local RAY_DISABLE_DASHBOARD=1 PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=0
export HF_HOME=$HOME/OPCD-improve/hf_cache TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_b6_early_status.log
CK=$ROOT/ckpts/theta-math8b-refresh-r2-v6
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
hf_ok(){ local HF=$1/actor/huggingface hsz nst
  hsz=$(du -sm $HF 2>/dev/null | cut -f1); hsz=${hsz:-0}
  nst=$(ls $HF/model*.safetensors 2>/dev/null | wc -l)
  [ -f $HF/config.json ] && [ "$nst" -ge 1 ] && [ "$hsz" -gt 15000 ]; }
pick_best(){
  local best=""
  for d in $(ls -d $CK/global_step_* 2>/dev/null | sort -t_ -k3 -n -r); do
    local s0 s1 t0 t1
    s0=$(stat -c %s $d/actor/model_world_size_2_rank_0.pt 2>/dev/null || echo 0)
    s1=$(stat -c %s $d/actor/model_world_size_2_rank_1.pt 2>/dev/null || echo 0)
    { [ "$s0" -gt 5000000000 ] && [ "$s1" -gt 5000000000 ]; } || continue
    sleep 90
    t0=$(stat -c %s $d/actor/model_world_size_2_rank_0.pt 2>/dev/null || echo 0)
    t1=$(stat -c %s $d/actor/model_world_size_2_rank_1.pt 2>/dev/null || echo 0)
    { [ "$s0" = "$t0" ] && [ "$s1" = "$t1" ]; } && { best=$d; break; }
  done
  echo "$best"
}
do_merge(){
  local BEST=$1 HF=$1/actor/huggingface
  hf_ok "$BEST" && { say "HF 已合格,跳过 merge: $BEST"; return 0; }
  rm -rf $HF; mkdir -p $HF
  find $BEST/actor -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $HF/ \;
  (cd $ROOT/opcd && python tools/merge_model2hf.py --local_dir $BEST/actor >> $LOGD/theta_b6_early_merge.log 2>&1)
  hf_ok "$BEST" && { say "merge 强校验过: $BEST"; return 0; }
  say "merge 强校验失败: $BEST"; return 1
}
say "==== 采集器 v3 start (pid $$):等 GPU 窗口(try 若跑完 50 步则窗口=训练退出) ===="
DL=$(( $(date +%s) + 259200 )); PAIR=""; CONF=0
while :; do
  [ $(date +%s) -gt $DL ] && { say "72h 无窗口,退出"; exit 1; }
  g=($(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits))
  a=""; [ "${g[0]:-9}" -lt 5000 ] && [ "${g[1]:-9}" -lt 5000 ] && a="0,1"
  [ -z "$a" ] && [ "${g[2]:-9}" -lt 5000 ] && [ "${g[3]:-9}" -lt 5000 ] && a="2,3"
  if [ -n "$a" ]; then CONF=$((CONF+1)); else CONF=0; fi
  [ $CONF -ge 3 ] && { PAIR=$a; break; }
  sleep 180
done
say "GPU 窗口确认: $PAIR"
BEST=$(pick_best)
[ -n "$BEST" ] || { say "FATAL 窗口已开但无完整断点"; exit 1; }
say "断点选定: $BEST"
ok=0
for i in 1 2 3; do do_merge "$BEST" && { ok=1; break; }; sleep 60; done
[ $ok = 1 ] || { say "FATAL merge 3 连败"; exit 1; }
STEP=$(basename $BEST | grep -oE '[0-9]+')
HF=$BEST/actor/huggingface
cp -f /tmp/b6data/dapo_train.parquet /tmp/dapo_test.parquet /tmp/ 2>/dev/null
say "终评开跑: step${STEP} @ GPU$PAIR (use_bsl)"
ep=$ROOT/ckpts/theta-math8b-r2v6-early-eval/global_step_${STEP}/evaluation/scores.json
ep2=/tmp/theta-math8b-r2v6-early-eval/global_step_${STEP}/evaluation/scores.json
for i in 1 2 3; do
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=$PAIR timeout 14400 \
    bash scripts/math_eval.sh --model "$HF" --exp_name theta-math8b-r2v6-early-eval --nnodes 1 \
    --use_bsl true --max_response_length 16384 --ckpt ${STEP} trainer.n_gpus_per_node=2 \
    >> $LOGD/theta_b6_early_eval.log 2>&1)
  { [ -e "$ep" ] || [ -e "$ep2" ]; } && break
  say "eval try$i 未出 scores,重试"; sleep 60
done
EP=""; [ -e "$ep" ] && EP=$ep; [ -z "$EP" ] && [ -e "$ep2" ] && EP=$ep2
[ -n "$EP" ] || { say "FATAL eval 3 连败"; exit 1; }
read -r EV <<< "$(mean $EP)"
N=$($ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
print(len(list(s.values())) if isinstance(s,dict) else len(s))" "$EP")
say "RESULT B6-early(step${STEP}): $EV (M₁=0.792;早期效应判读; n_items=$N 协议=1000; scores=$EP)"
say "==== 采集器 v3 ALL_DONE ===="
touch $LOGD/.b6_early_done
