#!/bin/bash
# Θ B6 终局评测评测器(H20,2026-10-19 凌晨):等训练进程(experiment_name=theta-math8b-refresh-r2-v6)退出
# →断点稳定→merge→GPU 窗口(优先 0/1,避让届时占 2/3 的 G8)→1000 题终评→RESULT+marker
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local RAY_DISABLE_DASHBOARD=1 PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=0
export HF_HOME=$HOME/OPCD-improve/hf_cache TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_b6_early_status.log
CK=$ROOT/ckpts/theta-math8b-refresh-r2-v6
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
hf_ok(){ local HF=$1/actor/huggingface hsz nst
  hsz=$(du -sm $HF 2>/dev/null | cut -f1); hsz=${hsz:-0}
  nst=$(ls $HF/model*.safetensors 2>/dev/null | wc -l)
  [ -f $HF/config.json ] && [ "$nst" -ge 1 ] && [ "$hsz" -gt 15000 ]; }
pick_best(){
  local best=""
  for d in $(ls -d $CK/global_step_* 2>/dev/null | sort -t_ -k3 -n -r); do
    local s0 s1 t0 t1
    s0=$(stat -c %s $d/actor/model_world_size_2_rank_0.pt 2>/dev/null || echo 0)
    s1=$(stat -c %s $d/actor/model_world_size_2_rank_1.pt 2>/dev/null || echo 0)
    { [ "$s0" -gt 5000000000 ] && [ "$s1" -gt 5000000000 ]; } || continue
    sleep 60
    t0=$(stat -c %s $d/actor/model_world_size_2_rank_0.pt 2>/dev/null || echo 0)
    t1=$(stat -c %s $d/actor/model_world_size_2_rank_1.pt 2>/dev/null || echo 0)
    { [ "$s0" = "$t0" ] && [ "$s1" = "$t1" ]; } && { best=$d; break; }
  done
  echo "$best"
}
say "==== B6 final watcher start (pid $$):等训练进程退出 ===="
# 阶段0:等训练进程消失(12h 上限——若 try 意外死透也走这条路评最高断点)
DL=$(( $(date +%s) + 172800 ))
while pgrep -f "experiment_name=theta-math8b-refresh-r2-v6" > /dev/null 2>&1; do
  [ $(date +%s) -gt $DL ] && { say "48h 训练未退,退出"; exit 1; }
  sleep 300
done
say "训练进程已退出;等 10min 断点落定"
sleep 600
BEST=$(pick_best)
[ -n "$BEST" ] || { say "FATAL 无完整断点"; exit 1; }
STEP=$(basename $BEST | grep -oE '[0-9]+')
say "终局断点: $BEST (step$STEP)"
# merge
ok=0
for i in 1 2 3; do
  hf_ok "$BEST" && { ok=1; say "HF 已合格"; break; }
  HF=$BEST/actor/huggingface
  rm -rf $HF; mkdir -p $HF
  find $BEST/actor -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $HF/ \;
  (cd $ROOT/opcd && python tools/merge_model2hf.py --local_dir $BEST/actor >> $LOGD/theta_b6_early_merge.log 2>&1)
  hf_ok "$BEST" && { ok=1; say "merge 强校验过"; break; }
  say "merge 试$i 失败"; sleep 60
done
[ $ok = 1 ] || { say "FATAL merge 3 连败"; exit 1; }
# 窗口:优先 0/1(G8 届时可能占 2/3)
DL=$(( $(date +%s) + 86400 )); PAIR=""; CONF=0
while :; do
  [ $(date +%s) -gt $DL ] && { say "24h 无窗口,退出"; exit 1; }
  g=($(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits))
  a=""; [ "${g[0]:-9}" -lt 5000 ] && [ "${g[1]:-9}" -lt 5000 ] && a="0,1"
  [ -z "$a" ] && [ "${g[2]:-9}" -lt 5000 ] && [ "${g[3]:-9}" -lt 5000 ] && a="2,3"
  [ -z "$a" ] && [ "${g[1]:-9}" -lt 5000 ] && [ "${g[2]:-9}" -lt 5000 ] && a="1,2"
  if [ -n "$a" ]; then CONF=$((CONF+1)); else CONF=0; fi
  [ $CONF -ge 3 ] && { PAIR=$a; break; }
  sleep 180
done
say "GPU 窗口确认: $PAIR;终局终评开跑 step${STEP}"
HF=$BEST/actor/huggingface
cp -f /tmp/b6data/dapo_train.parquet /tmp/dapo_test.parquet /tmp/ 2>/dev/null
ep=$ROOT/ckpts/theta-math8b-r2v6-final/global_step_${STEP}/evaluation/scores.json
ep2=/tmp/theta-math8b-r2v6-final/global_step_${STEP}/evaluation/scores.json
for i in 1 2 3; do
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=$PAIR timeout 14400 \
    bash scripts/math_eval.sh --model "$HF" --exp_name theta-math8b-r2v6-final --nnodes 1 \
    --use_bsl true --max_response_length 16384 --ckpt ${STEP} trainer.n_gpus_per_node=2 \
    >> $LOGD/theta_b6_final_eval.log 2>&1)
  { [ -e "$ep" ] || [ -e "$ep2" ]; } && break
  say "final eval try$i 未出 scores"; sleep 60
done
EP=""; [ -e "$ep" ] && EP=$ep; [ -z "$EP" ] && [ -e "$ep2" ] && EP=$ep2
[ -n "$EP" ] || { say "FATAL final eval 3 连败"; exit 1; }
read -r EV <<< "$(mean $EP)"
say "RESULT B6-FINAL(step${STEP}): $EV (M₁=0.792; s10=0.730; scores=$EP)"
say "==== B6 final watcher ALL_DONE ===="
touch $LOGD/.b6_final_done
