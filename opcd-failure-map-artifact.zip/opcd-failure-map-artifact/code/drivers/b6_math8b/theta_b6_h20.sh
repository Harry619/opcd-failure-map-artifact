#!/bin/bash
# Θ-B6:math 8B 第三域 refresh 链 r2-r3(GPU0/1,接 B2 后;2026-10-07 骨架部署)
# 预注册:theta_prereg_tier12_20261006.md 未含 B6 判读,发车前须在本文件追加预注册章节!
# ⚠ 发车前人工核对三处(标 [B6-CHECK]):
#   1) 8B 提取档(骨架按单卡 util 0.85;原 8B 提取为 48G 双卡 46G util 0.78,A800 80G 单卡待验证)
#   2) 固化参数与原 M₁(math-q3-8b-consol-user-b)协议一致(lr/步数/kl;骨架暂按 theta 惯例 5e-6×50 步)
#   3) 评测集口径(M₁ 终评 0.792 用的 dapo_test 1000 题,保持一致)
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local RAY_DISABLE_DASHBOARD=1 PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=0
export HF_HOME=/opt/opcd-artifact/hf_cache TMPDIR=/opt/opcd-artifact/tmp RAY_TMPDIR=/opt/opcd-artifact/ray_tmp
export PATH=/opt/opcd-artifact/envs/opcd/bin:$PATH
ROOT=/opt/opcd-artifact; LOGD=$ROOT/logs; ST=$LOGD/theta_b6_status.log
M1=$ROOT/ckpts/math-q3-8b-consol-user-b/best/actor/huggingface
PY=$(command -v python); NSAMP=10
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
wait_pred(){ while [ ! -f $HOME/OPCD-improve/ckpts/.b8m1_done ] || [ ! -f $HOME/OPCD-improve/envs/opcd/.ready ]; do sleep 300; done; }
wait_ready(){
  while ! ls $M1/*.safetensors >/dev/null 2>&1; do
    if ls /root/provider-anon-tmp/b6_incoming/math-q3-8b-consol-user-b/best/actor/huggingface/*.safetensors >/dev/null 2>&1; then
      mkdir -p $ROOT/ckpts && mv /root/provider-anon-tmp/b6_incoming/math-q3-8b-consol-user-b $ROOT/ckpts/ && say "M1 已从 b6_incoming 移位"
    else say "WAIT M1 素材"; sleep 300; fi
  done
  for f in dapo_validation dapo_test; do
    [ -f /tmp/$f.parquet ] || { ln -sf /root/provider-anon-tmp/b6_incoming/$f.parquet /tmp/$f.parquet 2>/dev/null; }
    [ -f /tmp/$f.parquet ] || { say "WAIT $f.parquet"; sleep 300; }
  done
  [ -f /tmp/dapo_train.parquet ] || say "[B6-CHECK] dapo_train.parquet 未到位(math_extract 若需 train 集须从 L40 补)"
}
wait_disk(){ local d; while :; do d=$(df -BG /opt/opcd-artifact|tail -1|awk '{gsub("G","",$4);print $4}'); [ "$d" -ge "$1" ] && return 0; say "WAIT disk ${d}G<$1G"; sleep 300; done; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 40000 ] && return 0; return 1
}
wait_free(){ while :; do local ok=1 g
  for g in "$@"; do is_free $g||{ ok=0;break;}; done
  if [ $ok -eq 1 ]; then sleep 60; ok=1
    for g in "$@"; do is_free $g||{ ok=0;break;}; done
    [ $ok -eq 1 ] && return 0
  fi
  sleep 60
done
}
cleanup_own(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 5
  pgrep -f "verl.trainer.main_pp[o]" >/dev/null 2>&1 || pkill -9 -f "ray::WorkerDic[t]" 2>/dev/null
  sleep 3; true
}
mean_score(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f"{sum(vals)/max(len(vals),1):.6f}",len(vals))
PYEOF
}
# [B6-CHECK-1] 提取档:单卡 util 0.85 起步,OOM 降 0.78(A800 80G 预计充裕)
do_extract(){ local model=$1 name=$2 label=$3 util rc n
  local pool=$ROOT/ckpts/$name/global_step_$label/extract_${NSAMP}_samples
  for util in 0.85 0.78; do
    [ -f "$pool/scores.json" ] && break
    wait_free 2; wait_disk 20
    say "EXTRACT $name start util=$util (8B 双卡)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 \
      bash scripts/math_extract.sh --model "$model" --exp_name $name --nnodes 1 --ckpt $label \
      --prompt_version v4 --exp_sel_with_prev False --val_samples_limit $NSAMP \
      --max_response_length 16384 \
      trainer.n_gpus_per_node=1 \
      actor_rollout_ref.rollout.gpu_memory_utilization=$util \
      > $LOGD/theta_ext_${name}.log 2>&1)
    rc=$?; n=$(ls "$pool/experiences" 2>/dev/null|grep -c experience)
    say "EXTRACT $name rc=$rc exp_files=${n:-0} util=$util"
    [ $rc -eq 0 ] && [ "${n:-0}" -ge $NSAMP ] && [ -f "$pool/scores.json" ] && break
    cleanup_own "$name"; sleep 30
  done
  [ -f "$pool/scores.json" ] || { say "FATAL extract $name"; return 1; }
  read -r EIDX ESCORE EN EMEAN <<< "$($PY - "$pool/scores.json" <<'PYEOF2'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
items=[(i+1,sc(v)) for i,v in enumerate(s.values() if isinstance(s,dict) else s)]
b=max(items,key=lambda x:x[1]); n=len(items)
print(b[0],f"{b[1]:.6f}",n,f"{sum(x[1] for x in items)/n:.6f}")
PYEOF2
)"
  EXPBEST=$pool/experiences/experience_${EIDX}.txt
  [ -f "$EXPBEST" ] || EXPBEST=$(ls $pool/experiences/experience_*.txt 2>/dev/null|sort -V|sed -n "${EIDX}p")
  [ -f "$EXPBEST" ] || { say "FATAL extract $name 候选缺失"; return 1; }
  cp -f "$EXPBEST" $ROOT/runs/theta_${name}_best.txt
  say "POOL $name: n=$EN best=$ESCORE mean=$EMEAN"
  return 0
}
# [B6-CHECK-2] 固化参数对齐原 M₁ 协议(发车前对照 reproduction_results.md 核对 lr/步数/长度档)
do_consol(){ local model=$1 name=$2 expfile=$3
  local ckpt=$ROOT/ckpts/$2/best/COMMIT.json try rc
  for try in 1 2 3; do
    [ -e "$ckpt" ] && { say "SKIP consol $name"; return 0; }
    wait_free 2 3; wait_disk 20
    say "CONSOL $name start try=$try (GPU0/1)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2,3 \
      bash scripts/math_consolidate.sh --model "$model" \
        --exp_name $name --nnodes 1 \
        --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
        --max_response_length 16384 \
        --exp_path "$expfile" \
        trainer.n_gpus_per_node=2 \
        +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
        actor_rollout_ref.actor.fsdp_config.param_offload=True \
        actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
        actor_rollout_ref.ref.fsdp_config.param_offload=True \
        +trainer.save_best_only=True trainer.held_out_rollout=0 \
        >> $LOGD/theta_consol_${name}.log 2>&1)
    rc=$?
    say "CONSOL $name rc=$rc try=$try"
    if [ -e "$ckpt" ]; then
      if [ $rc -eq 0 ] || grep -q "step:50" $LOGD/theta_consol_${name}.log 2>/dev/null; then return 0; fi
      say "PARTIAL consol $name → 清产物重试"
      rm -rf $ROOT/ckpts/$name
    fi
    cleanup_own "$name"; sleep 60
  done
  say "FATAL consol $name 3 连败"; return 1
}
# [B6-CHECK-3] 评测口径与 M₁ 终评 0.792 一致(dapo_test 1000 题,eval_wo_experience)
do_eval(){ local name=$1
  local D=$ROOT/ckpts/$1/best/actor try rc
  ls $D/huggingface/*.safetensors >/dev/null 2>&1 || { say "FATAL eval $name 无 HF 权重"; return 1; }
  STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/$name/best/COMMIT.json|head -1)
  local eprod=$ROOT/ckpts/${name}-eval/global_step_${STEP}/evaluation/scores.json
  for try in 1 2 3; do
    [ -e "$eprod" ] && break
    wait_free 2 3
    say "EVAL $name start try=$try (step=$STEP)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2,3 \
      bash scripts/math_eval.sh --model "$D/huggingface" --exp_name ${name}-eval --nnodes 1 \
      --ckpt ${STEP} trainer.n_gpus_per_node=2 \
      >> $LOGD/theta_eval_${name}.log 2>&1)
    rc=$?; say "EVAL $name rc=$rc try=$try"
    [ -e "$eprod" ] && break
    cleanup_own "${name}-eval"; sleep 60
  done
  [ -e "$eprod" ] || { say "FATAL eval $name"; return 1; }
  read -r EVALMEAN EVALN <<< "$(mean_score $eprod)"
  say "RESULT $name: eval=$EVALMEAN(n=$EVALN)"
  return 0
}

say "==== Θ-B6 start (pid $$): math 8B 第三域 refresh r2-r3,等 B2 退出 ===="
wait_pred
say "B2 已退出。前置检查(M1 移位/数据软链)"
wait_ready
say "开跑。锚:M₁ = math-q3-8b-consol-user-b 终评 0.792(1000 题)"
CUR=$M1
for n in 2 3; do
  say "---- B6 轮 r$n ----"
  do_extract "$CUR" theta-math8b-r${n}ext 99$n || exit 1
  do_consol "$CUR" theta-math8b-refresh-r$n "$EXPBEST" || exit 1
  do_eval theta-math8b-refresh-r$n || exit 1
  CUR=$ROOT/ckpts/theta-math8b-refresh-r$n/best/actor/huggingface
done
say "==== Θ-B6 ALL_DONE:判读(发车前应先补预注册章节)——对照 C1'域决定抗崩性':math 域预期 refresh 不崩 ===="
grep -E "RESULT|POOL" "$ST" | tail -6
