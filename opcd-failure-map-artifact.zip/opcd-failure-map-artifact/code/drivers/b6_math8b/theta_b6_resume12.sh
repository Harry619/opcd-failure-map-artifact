#!/bin/bash
# Θ B6 恢复驱动(2026-10-19 晚,用户指令:恢复到 GPU1/2 续跑到 50 步)
# 机制:动态取最高完整断点 → trainer.resume_from_path(编号续行) → 存到同目录(step38..50)
# 自愈:整链挂 theta_while_guard;每次重入都从"当前最高断点"续(真·断点累积)
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local RAY_DISABLE_DASHBOARD=1 PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=0
export HF_HOME=$HOME/OPCD-improve/hf_cache TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_b6v6_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local m=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1); [ "$m" -lt 10000 ] && return 0; return 1; }
wait_free(){ local wf_n=0
  while :; do local ok=1 g
  for g in "$@"; do is_free $g||{ ok=0;break;}; done
  if [ $ok -eq 1 ]; then sleep 60; ok=1
    for g in "$@"; do is_free $g||{ ok=0;break;}; done
    [ $ok -eq 1 ] && return 0
  fi
  wf_n=$((wf_n+1)); [ $((wf_n % 25)) -eq 0 ] && say "resume wait_free 卡 ${wf_n} 轮"
  sleep 60
done
}
EXTRA="trainer.n_gpus_per_node=2 ray_init.num_cpus=16 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  data.train_files=/tmp/b6data/dapo_train.parquet \
  data.val_files=/tmp/dapo_test.parquet \
  data.max_prompt_length=4096 \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=20480 \
  actor_rollout_ref.rollout.max_num_batched_tokens=16896 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
  +trainer.save_best_only=False trainer.save_freq=2 trainer.held_out_rollout=0 \
  trainer.total_training_steps=50"
M1=$ROOT/ckpts/math-q3-8b-consol-user-b/best/actor/huggingface
POOLDIR=$ROOT/ckpts/theta-math8b-r2ext/global_step_992/extract_10_samples
EXP2=$(find $POOLDIR -name 'experience_6.txt' | head -1)
CK=$ROOT/ckpts/theta-math8b-refresh-r2-v6
DONE=$CK/global_step_50/actor/huggingface/config.json
[ -e "$DONE" ] && { say "SKIP: step50 已在"; exit 0; }
[ -n "$EXP2" ] || { say "FATAL 经验文件缺失"; exit 1; }
pick_hi(){
  for d in $(ls -d $CK/global_step_* 2>/dev/null | sort -t_ -k3 -n -r); do
    local s0 s1
    s0=$(stat -c %s $d/actor/model_world_size_2_rank_0.pt 2>/dev/null || echo 0)
    s1=$(stat -c %s $d/actor/model_world_size_2_rank_1.pt 2>/dev/null || echo 0)
    { [ "$s0" -gt 5000000000 ] && [ "$s1" -gt 5000000000 ]; } && { echo $d; return; }
  done
  echo ""
}
BEST=$(pick_hi)
[ -n "$BEST" ] || { say "FATAL 无完整断点"; exit 1; }
say "==== B6-resume start (pid $$): GPU1/2 从 $(basename $BEST) 续跑至 50 ===="
for try in 1 2 3; do
  [ -e "$DONE" ] && break
  wait_free 1 2
  say "RESUME consol try=$try 从 $BEST (GPU1/2 seed=31 util=0.70)"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=1,2 \
    bash scripts/math_consolidate.sh --model "$M1" \
      --ref_model_path "$M1" \
      --exp_name theta-math8b-refresh-r2-v6 --nnodes 1 \
      --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
      --max_response_length 16384 \
      --exp_path "$EXP2" $EXTRA +actor_rollout_ref.rollout.seed=31 \
      actor_rollout_ref.rollout.gpu_memory_utilization=0.70 \
      trainer.resume_from_path=$BEST \
      >> $LOGD/theta_b6resume_consol.log 2>&1)
  rc=$?
  say "RESUME consol rc=$rc try=$try"
  [ -e "$DONE" ] && break
  NB=$(pick_hi); [ -n "$NB" ] && [ "$NB" != "$BEST" ] && { BEST=$NB; say "断点前进至 $(basename $BEST)"; }
  sleep 60
done
[ -e "$DONE" ] && say "==== B6-resume ALL_DONE (step50 达成) ====" || say "FATAL resume 3 连败(守护将重拉)"
exit 0
