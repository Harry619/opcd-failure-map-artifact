#!/bin/bash
# Θ B6 step10 早期点评测(H20 GPU2 单卡,2026-10-18 深夜):对冲明日 0/1 被占风险,提前落袋早期数据点
# 与 v3 终评互补(v3 评最终/最高断点,双卡协议;本评测 step10,单卡协议—— batching 差异在判读时注明)
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local RAY_DISABLE_DASHBOARD=1 PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=0
export HF_HOME=$HOME/OPCD-improve/hf_cache TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_b6_early_status.log
B=$ROOT/ckpts/theta-math8b-refresh-r2-v6/global_step_10; HF=$B/actor/huggingface
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
gpu2_free(){ local m=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 2); [ "$m" -lt 5000 ]; }
say "==== s10 单卡评测 start (pid $$):merge step10 → GPU2 终评 ===="
# merge(预置小文件+强校验,3 试)
ok=0
for i in 1 2 3; do
  hsz=$(du -sm $HF 2>/dev/null | cut -f1); nst=$(ls $HF/model*.safetensors 2>/dev/null | wc -l)
  if [ -f $HF/config.json ] && [ "$nst" -ge 1 ] && [ "${hsz:-0}" -gt 15000 ]; then ok=1; say "HF 已合格,跳过 merge"; break; fi
  rm -rf $HF; mkdir -p $HF
  find $B/actor -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $HF/ \;
  (cd $ROOT/opcd && python tools/merge_model2hf.py --local_dir $B/actor >> $LOGD/theta_b6_early_merge.log 2>&1)
  hsz=$(du -sm $HF 2>/dev/null | cut -f1); nst=$(ls $HF/model*.safetensors 2>/dev/null | wc -l)
  if [ -f $HF/config.json ] && [ "$nst" -ge 1 ] && [ "${hsz:-0}" -gt 15000 ]; then ok=1; say "merge 过(${hsz}MB ${nst}片)"; break; fi
  say "merge 试$i 失败(${hsz:-0}MB/${nst}片)"; sleep 60
done
[ $ok = 1 ] || { say "FATAL s10 merge 3 连败"; exit 1; }
cp -f /tmp/b6data/dapo_train.parquet /tmp/dapo_test.parquet /tmp/ 2>/dev/null
# eval(3 试;每试前等 GPU2 空)
ep=$ROOT/ckpts/theta-math8b-r2v6-s10e/global_step_10/evaluation/scores.json
ep2=/tmp/theta-math8b-r2v6-s10e/global_step_10/evaluation/scores.json
for i in 1 2 3; do
  C=0; while ! gpu2_free; do sleep 120; C=$((C+1)); [ $C -gt 300 ] && break; done
  say "s10 eval try$i 开跑(GPU2)"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 timeout 18000 \
    bash scripts/math_eval.sh --model "$HF" --exp_name theta-math8b-r2v6-s10e --nnodes 1 \
    --use_bsl true --max_response_length 16384 --ckpt 10 trainer.n_gpus_per_node=1 \
    >> $LOGD/theta_b6_s10_eval.log 2>&1)
  { [ -e "$ep" ] || [ -e "$ep2" ]; } && break
  say "s10 eval try$i 未出 scores"; sleep 60
done
EP=""; [ -e "$ep" ] && EP=$ep; [ -z "$EP" ] && [ -e "$ep2" ] && EP=$ep2
[ -n "$EP" ] || { say "FATAL s10 eval 3 连败"; exit 1; }
read -r EV <<< "$(mean $EP)"
N=$($ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
print(len(list(s.values())) if isinstance(s,dict) else len(s))" "$EP")
say "RESULT B6-s10(单卡协议): $EV (M₁=0.792; n_items=$N; scores=$EP)"
say "==== s10 单卡评测 ALL_DONE ===="
touch $LOGD/.b6_s10_done
