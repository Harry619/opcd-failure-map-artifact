#!/bin/bash
# Θ-B6 v6 最终版(H20 GPU0/1,2026-10-17):十刀补丁(源码已带)+rung21 调通参数+全教训防护
# 教训清单逐条核销:heldout=0(H20死因1)/空批守卫(源码已有,死因2)/内存监控0(死因3)/
# dashboard禁/日志追加/cleanup带ray兜底/best-only防爆盘/M₁强检查(四分片+15G)/
# rung21参数(prompt 4096截断+ppo 20480+batched 16896——user-b 验证跑通的 update 峰值配方)
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local RAY_DISABLE_DASHBOARD=1 PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=0
export HF_HOME=$HOME/OPCD-improve/hf_cache TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_b6v6_status.log
M1=$ROOT/ckpts/math-q3-8b-consol-user-b/best/actor/huggingface
POOLDIR=$ROOT/ckpts/theta-math8b-r2ext/global_step_992/extract_10_samples
PY=$(command -v python)
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local m=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1); [ "$m" -lt 10000 ] && return 0; return 1; }
wait_free(){ local wf_n=0
  while :; do local ok=1 g
    for g in "$@"; do is_free $g||{ ok=0;break;}; done
    if [ $ok -eq 1 ]; then sleep 60; ok=1
      for g in "$@"; do is_free $g||{ ok=0;break;}; done
      [ $ok -eq 1 ] && return 0
    fi
    wf_n=$((wf_n+1))
    if [ $((wf_n % 25)) -eq 0 ]; then
      say "wait_free 卡 ${wf_n} 轮,自动清 ray 残留(无条件版)"
      pkill -9 -f "ray::WorkerDic[t]" 2>/dev/null
    fi
    sleep 60
  done
}
cleanup_own(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 3; pkill -9 -f "ray::WorkerDic[t]" 2>/dev/null; sleep 3; true; }
mean_score(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}',len(vals))
PYEOF
}
pick_best(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
items=[(i+1,sc(v)) for i,v in enumerate(s.values() if isinstance(s,dict) else s)]
b=max(items,key=lambda x:x[1]); n=len(items)
print(b[0],f"{b[1]:.6f}",n)
PYEOF
}
# rung21 调通参数(user-b opcd_master 验证配方,十刀补丁在 H20 源码已带)
EXTRA="trainer.n_gpus_per_node=2 ray_init.num_cpus=16 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  data.train_files=/tmp/b6data/dapo_train.parquet \
  data.val_files=/tmp/dapo_test.parquet \
  data.max_prompt_length=4096 \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=20480 \
  actor_rollout_ref.rollout.max_num_batched_tokens=16896 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
  +trainer.save_best_only=False trainer.save_freq=2 trainer.held_out_rollout=0 \
  trainer.total_training_steps=50"
do_consol(){ local model=$1 name=$2 expfile=$3 sd=$4
  local ckpt=$ROOT/ckpts/$2/global_step_50/actor/huggingface/config.json try rc
  for try in 1 2 3; do
    [ -e "$ckpt" ] && { say "SKIP consol $name"; return 0; }
    wait_free 0 1
    local UTIL=0.70; [ $try -ge 2 ] && UTIL=0.80
    say "CONSOL $name start try=$try (GPU0/1 seed=$sd util=$UTIL rung21)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
      bash scripts/math_consolidate.sh --model "$model" \
        --ref_model_path "$model" \
        --exp_name $name --nnodes 1 \
        --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
        --max_response_length 16384 \
        --exp_path "$expfile" $EXTRA +actor_rollout_ref.rollout.seed=$sd \
        actor_rollout_ref.rollout.gpu_memory_utilization=$UTIL \
        >> $LOGD/theta_b6v6_consol_${name}.log 2>&1)
    rc=$?
    say "CONSOL $name rc=$rc try=$try"
    if [ -e "$ckpt" ]; then
      if [ $rc -eq 0 ] || grep -q "step:50" $LOGD/theta_b6v6_consol_${name}.log 2>/dev/null; then return 0; fi
      say "PARTIAL $name → 清产物重试"; rm -rf $ROOT/ckpts/$name
    fi
    cleanup_own "$name"; sleep 60
  done
  say "FATAL consol $name 3 连败"; return 1
}
do_eval(){ local name=$1 try rc ep
  local D=$ROOT/ckpts/$1/global_step_50/actor
  local eprod=$ROOT/ckpts/${name}-eval/global_step_50/evaluation/scores.json
  for try in 1 2 3; do
    [ -e "$eprod" ] && break
    wait_free 0 1
    say "EVAL $name start try=$try"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
      bash scripts/math_eval.sh --model "$D/huggingface" --exp_name ${name}-eval --nnodes 1 \
      --ckpt 50 trainer.n_gpus_per_node=2 \
      >> $LOGD/theta_b6v6_eval_${name}.log 2>&1)
    rc=$?; say "EVAL $name rc=$rc try=$try"
    [ -e "$eprod" ] && break
    cleanup_own "${name}-eval"; sleep 60
  done
  [ -e "$eprod" ] || { say "FATAL eval $name"; return 1; }
  read -r EV N <<< "$(mean_score $eprod)"
  say "RESULT $name: eval=$EV(n=$N)"
  return 0
}
do_extract(){ local model=$1 name=$2 rc n
  wait_free 0
  say "EXTRACT $name start (GPU0 单卡)"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0 \
    bash scripts/math_extract.sh --model "$model" --exp_name $name --nnodes 1 --ckpt 99 \
    --prompt_version v4 --exp_sel_with_prev False --val_samples_limit 10 \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.85 \
    trainer.n_gpus_per_node=1 ray_init.num_cpus=6 \
    >> $LOGD/theta_b6v6_ext_${name}.log 2>&1)
  rc=$?; n=$(find $ROOT/ckpts/$name -name 'experience_*.txt' 2>/dev/null | wc -l)
  say "EXTRACT $name rc=$rc exp_files=${n:-0}"
  [ "${n:-0}" -ge 10 ]
}

say "==== Θ-B6 v6 最终版 start (pid $$): GPU0/1 十刀+rung21+全防护 ===="
# M₁ 强检查(四分片——M₁ 是 8B 单文件还是分片?查实际结构后适配:总大小>15G 即可)
M1SZ=$(du -sm "$M1" 2>/dev/null | cut -f1)
[ "${M1SZ:-0}" -lt 15000 ] && { say "FATAL M₁ 不完整(${M1SZ:-0}MB)"; exit 1; }
EXP2=$(find $POOLDIR -name 'experience_6.txt' | head -1)
[ -n "$EXP2" ] || EXP2=$(find $POOLDIR -name 'experience_*.txt' | sort -V | sed -n 6p)
[ -f "$EXP2" ] || { say "FATAL r2ext 经验缺失"; exit 1; }
say "M₁(${M1SZ}MB)+r2ext 经验就位,r2 开跑"
do_consol "$M1" theta-math8b-refresh-r2-v6 "$EXP2" 31 || exit 1
do_eval theta-math8b-refresh-r2-v6 || exit 1
do_extract "$ROOT/ckpts/theta-math8b-refresh-r2-v6/global_step_50/actor/huggingface" theta-math8b-r3ext-v6 || exit 1
read -r EIDX ESCORE EN <<< "$(pick_best $(find $ROOT/ckpts/theta-math8b-r3ext-v6 -name scores.json | head -1))"
EXP3=$(find $ROOT/ckpts/theta-math8b-r3ext-v6 -name "experience_${EIDX}.txt" | head -1)
say "POOL r3ext: n=$EN best=$ESCORE"
do_consol "$ROOT/ckpts/theta-math8b-refresh-r2-v6/global_step_50/actor/huggingface" theta-math8b-refresh-r3-v6 "$EXP3" 31 || exit 1
do_eval theta-math8b-refresh-r3-v6 || exit 1
say "==== Θ-B6 v6 ALL_DONE ===="
grep -E "RESULT|POOL" "$ST" | tail -4
