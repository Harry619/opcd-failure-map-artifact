#!/bin/bash
# Θ-B1: 每轮固化步数剂量实验(FL@1.7B, GPU0/1, 接 E2a-A 臂后自动发车)
# 预注册(2026-10-06 定死): 04_笔记/theta_prereg_tier12_20261006.md §一
#   总暴露 150 步固定, 重锚次数 1/3/6 三臂: 1×150 连续 / 3×50(已有=s2/s3/s4 锚, 不重跑) / 6×25
#   判读矩阵: 见预注册 §一表格; 崩溃定义 heldout<0.15 或终评<0.15, 平台带 ≥0.20
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=1000
export HF_HOME=/home/user-b/OPCD/hf_cache
export PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_b1_status.log
M1=$ROOT/ckpts/fl-q3-1b7-consol2/best/actor/huggingface
EXP=$ROOT/runs/fl_exp26.txt
PY=$(command -v python)
# 步数覆盖参数(2026-10-06 部署时按 textgame_consolidate.sh 131/144 行实参校正: 两个参数都覆盖)
STEPS150="trainer.textgame_total_steps=150 trainer.total_training_steps=150"
STEPS25="trainer.textgame_total_steps=25 trainer.total_training_steps=25"
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
wait_pred(){ while pgrep -u user-b -f "theta_e2a_adaptiv[e]" >/dev/null 2>&1; do sleep 120; done; }
wait_disk(){ local d; while :; do d=$(df -BG /home/user-b|tail -1|awk '{gsub("G","",$4);print $4}'); [ "$d" -ge "$1" ] && return 0; say "WAIT disk ${d}G<$1G"; sleep 300; done; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do local ok=1 g
  for g in "$@"; do is_free $g||{ ok=0;break;}; done
  if [ $ok -eq 1 ]; then sleep 60; ok=1
    for g in "$@"; do is_free $g||{ ok=0;break;}; done
    [ $ok -eq 1 ] && return 0
  fi
  sleep 60
done
}
cleanup_own(){ pkill -u user-b -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 5
  pgrep -u user-b -f "verl.trainer.main_pp[o]" >/dev/null 2>&1 || pkill -u user-b -9 -f "ray::WorkerDic[t]" 2>/dev/null
  sleep 3; true
}
EXTRA_FL="trainer.n_gpus_per_node=2 ray_init.num_cpus=8 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.ref.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=12288 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.72 \
  actor_rollout_ref.rollout.max_num_batched_tokens=33792 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=32 \
  +trainer.save_best_only=True trainer.held_out_rollout=1"
mean_score(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f"{sum(vals)/max(len(vals),1):.6f}",len(vals))
PYEOF
}
# do_consol_fl <model> <name> <expfile> <steps> <stepscfg> <bestfreq> <expect_step>
do_consol_fl(){ local model=$1 name=$2 expfile=$3 steps=$4 stepscfg=$5 bfreq=$6 expect=$7
  local ckpt=$ROOT/ckpts/$2/best/COMMIT.json try rc
  for try in 1 2 3; do
    if [ -e "$ckpt" ]; then
      if grep -q "step:$expect" $LOGD/theta_consol_${name}.log 2>/dev/null || [ ! -s "$LOGD/theta_consol_${name}.log" ]; then
        say "SKIP consol $name"; return 0
      fi
    fi
    wait_free 0 1; wait_disk 15
    say "CONSOL $name start try=$try (${steps} 步, GPU0/1)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
      bash scripts/textgame_consolidate.sh --model "$model" \
        --exp_name $name --nnodes 1 \
        --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
        --max_response_length 1024 --experience_max_length 8192 \
        --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
        --exp_path "$expfile" $EXTRA_FL $stepscfg +trainer.best_eval_freq=$bfreq \
        > $LOGD/theta_consol_${name}.log 2>&1)
    rc=$?
    say "CONSOL $name rc=$rc try=$try"
    if [ -e "$ckpt" ] || grep -q "step:$expect" $LOGD/theta_consol_${name}.log 2>/dev/null; then
      grep -q "step:$expect" $LOGD/theta_consol_${name}.log 2>/dev/null && return 0
      [ -e "$ckpt" ] && sleep 5 && grep -q "step:$expect" $LOGD/theta_consol_${name}.log 2>/dev/null && return 0
    fi
    say "PARTIAL consol $name → 清产物重试"
    rm -rf $ROOT/ckpts/$name
    cleanup_own "$name"; sleep 60
  done
  say "FATAL consol $name 3 连败"; return 1
}
do_merge_eval(){ local name=$1
  local D=$ROOT/ckpts/$1/best/actor try rc
  if ! ls $D/huggingface/*.safetensors >/dev/null 2>&1; then
    mkdir -p $D/huggingface
    find $D -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $D/huggingface/ \;
    (cd $ROOT/opcd && $PY tools/merge_model2hf.py --local_dir "$D" >> $LOGD/theta_merge_${name}.log 2>&1) \
      || { say "FATAL merge $name"; return 1; }
    say "MERGED $name"
  fi
  STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/$name/best/COMMIT.json|head -1)
  local eprod=$ROOT/ckpts/${name}-eval/global_step_${STEP}/evaluation/scores.json
  for try in 1 2 3; do
    [ -e "$eprod" ] && break
    wait_free 0 1
    say "EVAL $name start try=$try (GPU0/1 step=$STEP)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
      bash scripts/textgame_eval.sh --model "$D/huggingface" --exp_name ${name}-eval --nnodes 1 --use_bsl true \
      --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      --ckpt ${STEP} trainer.n_gpus_per_node=2 \
      > $LOGD/theta_eval_${name}.log 2>&1)
    rc=$?; say "EVAL $name rc=$rc try=$try"
    [ -e "$eprod" ] && break
    cleanup_own "${name}-eval"; sleep 60
  done
  [ -e "$eprod" ] || { say "FATAL eval $name"; return 1; }
  read -r EVALMEAN EVALN <<< "$(mean_score $eprod)"
  say "RESULT $name: eval=$EVALMEAN(n=$EVALN)"
  return 0
}
say "==== Θ-B1 start (pid $$): 剂量实验 1×150 + 6×25(3×50 用已有锚),等 E2a-A 退出 ===="
wait_pred
say "E2a-A 已退出, GPU0/1 接卡"
[ -d "$M1" ] && [ -f "$EXP" ] || { say "FATAL 前置缺失(M1=$M1 / exp=$EXP)"; exit 1; }
wait_disk 15
# ---- 臂 1: 1×150 连续(无轮界) ----
do_consol_fl "$M1" theta-b1-1x150 "$EXP" 150 "$STEPS150" 10 150 || exit 1
# heldout 曲线提取(每 10 步验证打印行)
grep -o "Held-out Envs Acc: [0-9.]*" $LOGD/theta_consol_theta-b1-1x150.log | sed 's/Held-out Envs Acc: //' | tr '\n' ' ' > $ROOT/runs/theta_b1_1x150_heldout.txt
say "HELDOUT_1x150: $(cat $ROOT/runs/theta_b1_1x150_heldout.txt)"
do_merge_eval theta-b1-1x150 || exit 1
# ---- 臂 2: 6×25(6 轮, 每轮 25 步, 每轮从上轮 best 重启) ----
CUR=$M1
for r in 1 2 3 4 5 6; do
  say "---- B1 6×25 轮 r$r ----"
  do_consol_fl "$CUR" theta-b1-6x25-r$r "$EXP" 25 "$STEPS25" 5 25 || exit 1
  do_merge_eval theta-b1-6x25-r$r || exit 1
  CUR=$ROOT/ckpts/theta-b1-6x25-r$r/best/actor/huggingface
  say "CHAIN_6x25 r$r eval=$EVALMEAN"
done
say "==== B1 ALL_DONE: 判读对照预注册 §一矩阵(锚: 3×50 = s2 0.12/s3 ≤0.10/s4 0.000) ===="
grep -E "RESULT|HELDOUT|CHAIN" "$ST" | tail -12
