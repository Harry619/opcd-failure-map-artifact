#!/bin/bash
# Θ-B1-H20:剂量实验 6×25(GPU2 单卡,2026-10-11 用户令"全都让其在 h20 上跑")
# 1x150 已有结果(0.164,eval dir 在 A6000);本轮只跑 6×25 六轮,每轮独立从 M₁ 锚出发
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=1000
export HF_HOME=/opt/opcd-artifact/hf_cache
export PATH=/opt/opcd-artifact/envs/opcd/bin:$PATH
ROOT=/opt/opcd-artifact; LOGD=$ROOT/logs; ST=$LOGD/theta_b1_h20_status.log
M1=$ROOT/ckpts/fl-q3-1b7-consol2/best/actor/huggingface
FL_EXP=$ROOT/runs/fl_exp26.txt
PY=$(command -v python)
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }

wait_disk(){ local d; while :; do d=$(df -BG $HOME|tail -1|awk '{gsub("G","",$4);print $4}'); [ "$d" -ge "$1" ] && return 0; say "WAIT disk ${d}G<$1G 5min"; sleep 300; done; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do
  is_free 2 && { sleep 30; is_free 2 && return 0; }
  sleep 30
done
}
cleanup_own(){ pkill -u $(whoami) -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 5; true
}
prune_shards(){ local d=$ROOT/ckpts/$1/best/actor
  ls $d/huggingface/*.safetensors >/dev/null 2>&1 || return 0
  rm -f $d/*.pt
}
EXTRA="trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.ref.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=12288 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.2 \
  actor_rollout_ref.rollout.max_num_batched_tokens=33792 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=32 \
  +trainer.save_best_only=True trainer.held_out_rollout=1 +trainer.best_eval_freq=10"

mean_score(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f"{sum(vals)/max(len(vals),1):.6f}",len(vals))
PYEOF
}
do_consol(){ local name=$1
  local ckpt=$ROOT/ckpts/$1/best/COMMIT.json try rc
  for try in 1 2 3; do
    [ -e "$ckpt" ] && { say "SKIP consol $name"; return 0; }
    wait_free; wait_disk 10
    say "CONSOL $name start try=$try (25 步, GPU2)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 \
      bash scripts/textgame_consolidate.sh --model "$M1" \
        --exp_name $name --nnodes 1 \
        --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
        --max_response_length 1024 --experience_max_length 8192 \
        --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
        --exp_path "$FL_EXP" $EXTRA \
        > $LOGD/theta_consol_${name}.log 2>&1)
    rc=$?
    say "CONSOL $name rc=$rc try=$try"
    if [ -e "$ckpt" ]; then
      if [ $rc -eq 0 ] || grep -q "step:25" $LOGD/theta_consol_${name}.log 2>/dev/null; then return 0; fi
      say "PARTIAL consol $name → 清产物重试"
      rm -rf $ROOT/ckpts/$name
    fi
    cleanup_own "$name"; sleep 60
  done
  say "FATAL consol $name 3 连败"; return 1
}
do_merge_eval(){ local name=$1
  local D=$ROOT/ckpts/$1/best/actor try rc
  if ! ls $D/huggingface/*.safetensors >/dev/null 2>&1; then
    mkdir -p $D/huggingface
    find $D -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $D/huggingface/ \;
    (cd $ROOT/opcd && $PY tools/merge_model2hf.py --local_dir "$D" >> $LOGD/theta_merge_${name}.log 2>&1) \
      || { say "FATAL merge $name"; return 1; }
    say "MERGED $name"
  fi
  STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/$name/best/COMMIT.json|head -1)
  local eprod=$ROOT/ckpts/${name}-eval/global_step_${STEP}/evaluation/scores.json
  for try in 1 2 3; do
    [ -e "$eprod" ] && break
    wait_free
    say "EVAL $name start try=$try (step=$STEP)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 \
      bash scripts/textgame_eval.sh --model "$D/huggingface" --exp_name ${name}-eval --nnodes 1 --use_bsl true \
      --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      --ckpt ${STEP} trainer.n_gpus_per_node=1 \
      actor_rollout_ref.rollout.gpu_memory_utilization=0.2 \
      > $LOGD/theta_eval_${name}.log 2>&1)
    rc=$?; say "EVAL $name rc=$rc try=$try"
    [ -e "$eprod" ] && break
    cleanup_own "${name}-eval"; sleep 60
  done
  [ -e "$eprod" ] || { say "FATAL eval $name"; return 1; }
  read -r EVALMEAN EVALN <<< "$(mean_score $eprod)"
  say "RESULT $name: eval=$EVALMEAN(n=$EVALN)"
  prune_shards $name
  return 0
}

say "==== Θ-B1-H20 start (pid $$): 6×25 剂量(GPU2 单卡,util 0.2) ===="
[ -d "$M1" ] && [ -f "$FL_EXP" ] || { say "FATAL 前置缺失"; exit 1; }
say "锚点:M₁(fl-consol2);1x150 已有结果(A6000 eval=0.164,不重跑);6 轮独立"
for i in 1 2 3 4 5 6; do
  say "---- B1 6x25 r$i ----"
  do_consol theta-b1-6x25-r$i || exit 1
  do_merge_eval theta-b1-6x25-r$i || exit 1
done
say "==== Θ-B1-H20 ALL_DONE(6×25 完毕) ===="
grep -E "RESULT" "$ST" | tail -6
