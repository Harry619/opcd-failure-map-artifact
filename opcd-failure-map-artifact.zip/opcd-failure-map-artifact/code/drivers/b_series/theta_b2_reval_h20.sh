#!/bin/bash
# Θ-B2 多种子复评(H20 GPU0 挤占档,2026-10-11):三轮 lr25 ckpt × 种子 44/45(首评各 1 次)
# GPU0 对方 44G/143G,挤占档评测 ~35G 可共存;is_free 阈 95G(GPU1 81G 不碰,只锁 GPU0)
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 HF_HOME=$HOME/OPCD-improve/hf_cache
export TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_b2_reval_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free0(){ local mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 0); [ "$mem" -lt 95000 ] && return 0; return 1; }
cleanup(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 3; true; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
run(){ local n=$1 S=$2 try rc ep
  ep=$ROOT/ckpts/${n}-rv${S}/global_step_${S}/evaluation/scores.json
  [ -e "$ep" ] && return 0
  for try in 1 2 3; do
    while ! is_free0; do sleep 120; done
    say "START $n s$S gpu0 try=$try"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0 \
      bash scripts/textgame_eval.sh --model "$ROOT/ckpts/$n/best/actor/huggingface" \
      --exp_name ${n}-rv${S} --nnodes 1 --use_bsl true --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      --ckpt ${S} trainer.n_gpus_per_node=1 actor_rollout_ref.rollout.gpu_memory_utilization=0.55 \
      > $LOGD/theta_b2rv_${n}_s${S}.log 2>&1)
    rc=$?
    if [ -e "$ep" ]; then read -r EV <<< "$(mean $ep)"; say "RESULT $n s$S: $EV rc=$rc"; return 0; fi
    say "FAIL $n s$S rc=$rc"; cleanup "${n}-rv${S}"; sleep 30
  done
  say "FATAL $n s$S"
}
say "==== B2 复评 start (pid $$) GPU0 挤占档 ===="
for n in theta-b2-lr25-s2l theta-b2-lr25-s3l theta-b2-lr25-s4l; do
  for S in 44 45; do run "$n" "$S"; done
done
say "==== B2 复评 ALL_DONE ===="
grep RESULT "$ST" | tail -6
