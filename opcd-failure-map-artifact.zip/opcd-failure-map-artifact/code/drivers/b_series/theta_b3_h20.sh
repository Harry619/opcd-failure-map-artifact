#!/bin/bash
# Θ-B3:SK@1.7B static 延长链 s4→s5(GPU2/3,接 E2a-B 臂收官后自动发车)
# 目的:"容量买轮数"SK 侧从 1 点(E1l 3 轮缓降)升 2 点;预注册:B 级 1→A 级加固(gap 分析 B3 条)
# 协议:E1l 逐字同(static 固化 sk_exp2,每轮 50 步,12288/0.72 档),唯一延伸=轮数
# 前置:theta-sk1b7-static-s3 ckpt(2026-10-06 从 L40 归档 cyx_20261003 推回)已由 L40 推送守护置位
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=1000
export HF_HOME=/opt/opcd-artifact/hf_cache
export PATH=/opt/opcd-artifact/envs/opcd/bin:$PATH
ROOT=/opt/opcd-artifact; LOGD=$ROOT/logs; ST=$LOGD/theta_b3_status.log
S3=$ROOT/ckpts/theta-sk1b7-static-s3/best/actor/huggingface
SK_EXP=$ROOT/runs/sk_exp2.txt
PY=$(command -v python)
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
wait_pred(){ return 0; }
wait_s3(){ while [ ! -f $HOME/OPCD-improve/ckpts/.relay_theta-sk1b7-static-s3_done ]; do sleep 300; done; }
wait_disk(){ local d; while :; do d=$(df -BG /opt/opcd-artifact|tail -1|awk '{gsub("G","",$4);print $4}'); [ "$d" -ge "$1" ] && return 0; say "WAIT disk ${d}G<$1G"; sleep 300; done; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 95000 ] && return 0; return 1
}
wait_free(){ while :; do local ok=1 g
  for g in "$@"; do is_free $g||{ ok=0;break;}; done
  if [ $ok -eq 1 ]; then sleep 60; ok=1
    for g in "$@"; do is_free $g||{ ok=0;break;}; done
    [ $ok -eq 1 ] && return 0
  fi
  sleep 60
done
}
cleanup_own(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 5
  pgrep -f "verl.trainer.main_pp[o]" >/dev/null 2>&1 || pkill -9 -f "ray::WorkerDic[t]" 2>/dev/null
  sleep 3; true
}
EXTRA="trainer.n_gpus_per_node=1 ray_init.num_cpus=8 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.ref.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=12288 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.2 \
  actor_rollout_ref.rollout.max_num_batched_tokens=33792 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=32 \
  +trainer.save_best_only=True trainer.held_out_rollout=1 +trainer.best_eval_freq=10"
mean_score(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f"{sum(vals)/max(len(vals),1):.6f}",len(vals))
PYEOF
}
do_consol(){ local model=$1 name=$2 expfile=$3
  local ckpt=$ROOT/ckpts/$2/best/COMMIT.json try rc
  for try in 1 2 3; do
    [ -e "$ckpt" ] && { say "SKIP consol $name"; return 0; }
    wait_free 3; wait_disk 15
    say "CONSOL $name start try=$try (GPU2/3)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=3 \
      bash scripts/textgame_consolidate.sh --model "$model" \
        --exp_name $name --nnodes 1 \
        --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
        --max_response_length 1024 --experience_max_length 8192 \
        --textgame_name Sokoban-v0 --textgame_max_steps 5 --textgame_no_think True \
        --exp_path "$expfile" $EXTRA \
        > $LOGD/theta_consol_${name}.log 2>&1)
    rc=$?
    say "CONSOL $name rc=$rc try=$try"
    if [ -e "$ckpt" ]; then
      if [ $rc -eq 0 ] || grep -q "step:50" $LOGD/theta_consol_${name}.log 2>/dev/null; then return 0; fi
      say "PARTIAL consol $name → 清产物重试"
      rm -rf $ROOT/ckpts/$name
    fi
    cleanup_own "$name"; sleep 60
  done
  say "FATAL consol $name 3 连败"; return 1
}
do_merge_eval(){ local name=$1
  local D=$ROOT/ckpts/$1/best/actor try rc
  if ! ls $D/huggingface/*.safetensors >/dev/null 2>&1; then
    mkdir -p $D/huggingface
    find $D -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $D/huggingface/ \;
    (cd $ROOT/opcd && $PY tools/merge_model2hf.py --local_dir "$D" >> $LOGD/theta_merge_${name}.log 2>&1) \
      || { say "FATAL merge $name"; return 1; }
    say "MERGED $name"
  fi
  STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/$name/best/COMMIT.json|head -1)
  local eprod=$ROOT/ckpts/${name}-eval/global_step_${STEP}/evaluation/scores.json
  for try in 1 2 3; do
    [ -e "$eprod" ] && break
    wait_free 3
    say "EVAL $name start try=$try (GPU2/3 step=$STEP)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=3 \
      bash scripts/textgame_eval.sh --model "$D/huggingface" --exp_name ${name}-eval --nnodes 1 --use_bsl true \
      --max_response_length 1024 \
      --textgame_name Sokoban-v0 --textgame_max_steps 5 --textgame_no_think True \
      --ckpt ${STEP} trainer.n_gpus_per_node=1 \
      > $LOGD/theta_eval_${name}.log 2>&1)
    rc=$?; say "EVAL $name rc=$rc try=$try"
    [ -e "$eprod" ] && break
    cleanup_own "${name}-eval"; sleep 60
  done
  [ -e "$eprod" ] || { say "FATAL eval $name"; return 1; }
  read -r EVALMEAN EVALN <<< "$(mean_score $eprod)"
  say "RESULT $name: eval=$EVALMEAN(n=$EVALN)"
  return 0
}

say "==== Θ-B3 start (pid $$): SK@1.7B static 延长 s4-s5,等 E2a-B 收官 ===="
[ -f "$SK_EXP" ] || { say "FATAL 前置缺失 sk_exp2"; exit 1; }
wait_pred
say "E2a-B 已退出。等 s3 父本就位(L40 推送)"
wait_s3
say "s3 就位,开跑 s4(E1l 协议:0.234(M1)→0.211(s2)→0.188(s3) 延长)"
CUR=$S3
for n in 4 5; do
  say "---- B3 轮 s$n ----"
  do_consol "$CUR" theta-sk1b7-static-s$n "$SK_EXP" || exit 1
  do_merge_eval theta-sk1b7-static-s$n || exit 1
  CUR=$ROOT/ckpts/theta-sk1b7-static-s$n/best/actor/huggingface
done
say "==== Θ-B3 ALL_DONE:对照 E1l 3 轮缓降(-0.046),看 s4/s5 是否加速(FL 型)或平台(SK@4B 型)===="
grep RESULT "$ST" | tail -2
