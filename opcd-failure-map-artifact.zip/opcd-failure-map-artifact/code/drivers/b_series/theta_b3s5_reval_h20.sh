#!/bin/bash
# Θ B3 s5 补种子(H20 GPU1,2026-10-12):theta-sk1b7-static-s5 终评种子 44/45(现仅 s43=0.109)
# 排队等 M₁ k=4 复评批退出后自动接卡;util 0.35 挤占档与 AuroOFT 共存
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 HF_HOME=$HOME/OPCD-improve/hf_cache
export TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_b3s5_reval_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free1(){ local mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 1); [ "$mem" -lt 115000 ] && return 0; return 1; }
cleanup(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 3; true; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
M=$ROOT/ckpts/theta-sk1b7-static-s5/best/actor/huggingface
[ -e "$M/model.safetensors" ] || { say "NO_MODEL $M — abort"; exit 1; }
# 等 M₁ 复评批退出(GPU1 让路);超时 4h 兜底
DL=$(( $(date +%s) + 14400 ))
while ! grep -q "ALL_DONE" $ROOT/logs/theta_m1_reval_status.log 2>/dev/null; do
  [ $(date +%s) -gt $DL ] && { say "M1 等待超时,直接开跑"; break; }
  sleep 120
done
run(){ local S=$1 try rc ep
  ep=$ROOT/ckpts/theta-sk1b7-static-s5-g1r${S}/global_step_${S}/evaluation/scores.json
  [ -e "$ep" ] && return 0
  for try in 1 2 3; do
    while ! is_free1; do sleep 120; done
    say "START b3s5 s$S gpu1 try=$try"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=1 \
      bash scripts/textgame_eval.sh --model "$M" \
      --exp_name theta-sk1b7-static-s5-g1r${S} --nnodes 1 --use_bsl true --max_response_length 1024 \
      --textgame_name Sokoban-v0 --textgame_max_steps 5 --textgame_no_think True \
      --ckpt ${S} trainer.n_gpus_per_node=1 actor_rollout_ref.rollout.gpu_memory_utilization=0.35 \
      > $LOGD/theta_g1r_b3s5_s${S}.log 2>&1)
    rc=$?
    if [ -e "$ep" ]; then read -r EV <<< "$(mean $ep)"; say "RESULT b3s5 s$S: $EV rc=$rc"; return 0; fi
    say "FAIL b3s5 s$S rc=$rc"; cleanup "theta-sk1b7-static-s5-g1r${S}"; sleep 30
  done
  say "FATAL b3s5 s$S"
}
say "==== B3 s5 补种子批 start (pid $$) ===="
for S in 44 45; do run "$S"; done
say "==== B3 s5 补种子批 ALL_DONE ===="
