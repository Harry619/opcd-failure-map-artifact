#!/bin/bash
# Θ-E1e:关键峰值种子复跑(GPU0/1,2026-09-30 ZCode):给曲线的两个关键点补第二种子的误差棒
# P1: static s2b(seed=21)——s2 峰值 0.281 的复现(n=2)
# P2: refresh r4b(新提取池 942 + seed=17 固化)——r4 峰值 0.336 的复现(n=2)
# 门控:等 E1d 驱动退出后再接卡(避免相位间隙抢卡扰动主链);协议与 Θ-E1 完全一致
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=1000
export HF_HOME=/home/user-b/OPCD/hf_cache
export PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH

ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_e1e_status.log
M2S=$ROOT/ckpts/theta-fl-static-r2/best/actor/huggingface
R3=$ROOT/ckpts/theta-fl-refresh-r3/best/actor/huggingface
FL_EXP=$ROOT/runs/fl_exp26.txt
PY=$(command -v python); NSAMP=10
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }

wait_e1d_exit(){ while pgrep -u user-b -f "theta_e1d_fl.s[h]" >/dev/null 2>&1; do sleep 120; done; }
wait_disk(){ local d; while :; do d=$(df -BG /home/user-b|tail -1|awk '{gsub("G","",$4);print $4}'); [ "$d" -ge "$1" ] && return 0; say "WAIT disk ${d}G<$1G"; sleep 300; done; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do local ok=1 g
  for g in "$@"; do is_free $g||{ ok=0;break;}; done
  if [ $ok -eq 1 ]; then sleep 60; ok=1
    for g in "$@"; do is_free $g||{ ok=0;break;}; done
    [ $ok -eq 1 ] && return 0
  fi
  sleep 60
done
}
cleanup_own(){ pkill -u user-b -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 5
  pgrep -u user-b -f "verl.trainer.main_pp[o]" >/dev/null 2>&1 || pkill -u user-b -9 -f "ray::WorkerDic[t]" 2>/dev/null
  sleep 3; true
}
prune_shards(){ local d=$ROOT/ckpts/$1/best/actor
  ls $d/huggingface/*.safetensors >/dev/null 2>&1 || { say "PRUNE_SKIP $1"; return 0; }
  rm -f $d/*.pt; say "PRUNED $1 shards"
}

EXTRA="trainer.n_gpus_per_node=2 ray_init.num_cpus=8 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.ref.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=12288 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.72 \
  actor_rollout_ref.rollout.max_num_batched_tokens=33792 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=32 \
  +trainer.save_best_only=True trainer.held_out_rollout=1 +trainer.best_eval_freq=10"

pick_best(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
items=[(i+1,sc(v)) for i,v in enumerate(s.values() if isinstance(s,dict) else s)]
b=max(items,key=lambda x:x[1]); n=len(items)
print(b[0],f"{b[1]:.6f}",n,f"{sum(x[1] for x in items)/n:.6f}")
PYEOF
}
mean_score(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f"{sum(vals)/max(len(vals),1):.6f}",len(vals))
PYEOF
}

say "==== Θ-E1e start (pid $$): GPU0/1 | 等 E1d 退出后接卡: s2b + r4b 种子复跑 ===="
[ -d "$M2S" ] && [ -d "$R3" ] && [ -f "$FL_EXP" ] || { say "FATAL 前置缺失"; exit 1; }
wait_e1d_exit; say "E1d 已退出,E1e 接卡"

say "---- P1: static s2b(seed=21) ----"
ckpt=$ROOT/ckpts/theta-fl-static-r2b/best/COMMIT.json
for try in 1 2 3; do
  [ -e "$ckpt" ] && { say "SKIP s2b"; break; }
  wait_free 0 1; wait_disk 15
  say "CONSOL theta-fl-static-r2b start try=$try (GPU0/1 seed=21)"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
    bash scripts/textgame_consolidate.sh --model "$M2S" \
    --exp_name theta-fl-static-r2b --nnodes 1 \
    --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
    --max_response_length 1024 --experience_max_length 8192 \
    --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
    --exp_path "$FL_EXP" $EXTRA +actor_rollout_ref.rollout.seed=21 \
    > $LOGD/theta_consol_theta-fl-static-r2b.log 2>&1)
  rc=$?
  say "CONSOL theta-fl-static-r2b rc=$rc try=$try"
  if [ -e "$ckpt" ]; then
    if [ $rc -eq 0 ] || grep -q "step:50" $LOGD/theta_consol_theta-fl-static-r2b.log 2>/dev/null; then break; fi
    say "PARTIAL s2b → 清产物重试"; rm -rf $ROOT/ckpts/theta-fl-static-r2b
  fi
  cleanup_own theta-fl-static-r2b; sleep 60
done
[ -e "$ckpt" ] || { say "FATAL s2b 3 连败"; exit 1; }
D=$ROOT/ckpts/theta-fl-static-r2b/best/actor
mkdir -p $D/huggingface; find $D -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $D/huggingface/ \;
(cd $ROOT/opcd && $PY tools/merge_model2hf.py --local_dir "$D" >> $LOGD/theta_merge_s2b.log 2>&1) || { say "FATAL merge s2b"; exit 1; }
STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/theta-fl-static-r2b/best/COMMIT.json|head -1)
eprod=$ROOT/ckpts/theta-fl-static-r2b-eval/global_step_${STEP}/evaluation/scores.json
for try in 1 2 3; do
  [ -e "$eprod" ] && break
  wait_free 0 1
  say "EVAL s2b try=$try step=$STEP"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
    bash scripts/textgame_eval.sh --model "$D/huggingface" --exp_name theta-fl-static-r2b-eval --nnodes 1 --use_bsl true \
    --max_response_length 1024 \
    --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
    --ckpt ${STEP} trainer.n_gpus_per_node=2 \
    > $LOGD/theta_eval_theta-fl-static-r2b.log 2>&1)
  [ -e "$eprod" ] && break
  cleanup_own "theta-fl-static-r2b-eval"; sleep 60
done
read -r EV EN <<< "$(mean_score $eprod 2>/dev/null)"; HB=$(grep -oP '(?<="value": )[0-9.]+' $ROOT/ckpts/theta-fl-static-r2b/best/COMMIT.json|head -1)
say "RESULT theta-fl-static-r2b: eval=${EV:-FAIL}(n=${EN:-0}) heldout_best=$HB@step$STEP"
prune_shards theta-fl-static-r2b

say "---- P2: refresh r4b(池 942 + seed=17) ----"
pool=$ROOT/ckpts/theta-fl-r4bext/global_step_942/extract_${NSAMP}_samples
for util in 0.85 0.90; do
  [ -f "$pool/scores.json" ] && break
  wait_free 1; wait_disk 15
  say "EXTRACT theta-fl-r4bext start util=$util (GPU1 单卡)"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=1 \
    bash scripts/textgame_extract.sh --model "$R3" --exp_name theta-fl-r4bext --nnodes 1 --ckpt 942 \
    --prompt_version v4 --exp_sel_with_prev False --val_samples_limit $NSAMP \
    --max_response_length 8192 --textgame_name FrozenLake-v0-raw --textgame_max_response 1024 \
    --textgame_max_steps 5 --textgame_no_think False \
    actor_rollout_ref.rollout.gpu_memory_utilization=$util \
    trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
    +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
    +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
    > $LOGD/theta_ext_theta-fl-r4bext.log 2>&1)
  rc=$?; n=$(ls "$pool/experiences" 2>/dev/null|grep -c experience)
  say "EXTRACT theta-fl-r4bext rc=$rc exp_files=${n:-0} util=$util"
  [ $rc -eq 0 ] && [ "${n:-0}" -ge $NSAMP ] && [ -f "$pool/scores.json" ] && break
  cleanup_own theta-fl-r4bext; sleep 30
done
[ -f "$pool/scores.json" ] || { say "FATAL extract r4bext"; exit 1; }
read -r EIDX ESCORE ENP EMEAN <<< "$(pick_best $pool/scores.json)"
EXPB=$pool/experiences/experience_${EIDX}.txt
[ -f "$EXPB" ] || EXPB=$(ls $pool/experiences/experience_*.txt|sort -V|sed -n "${EIDX}p")
cp -f "$EXPB" $ROOT/runs/theta_theta-fl-r4bext_best.txt
say "POOL theta-fl-r4bext: n=$ENP best=$ESCORE mean=$EMEAN → $(basename $EXPB)"

ckpt=$ROOT/ckpts/theta-fl-refresh-r4b/best/COMMIT.json
for try in 1 2 3; do
  [ -e "$ckpt" ] && { say "SKIP r4b"; break; }
  wait_free 0 1; wait_disk 15
  say "CONSOL theta-fl-refresh-r4b start try=$try (GPU0/1 seed=17)"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
    bash scripts/textgame_consolidate.sh --model "$R3" \
    --exp_name theta-fl-refresh-r4b --nnodes 1 \
    --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
    --max_response_length 1024 --experience_max_length 8192 \
    --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
    --exp_path "$EXPB" $EXTRA +actor_rollout_ref.rollout.seed=17 \
    > $LOGD/theta_consol_theta-fl-refresh-r4b.log 2>&1)
  rc=$?
  say "CONSOL theta-fl-refresh-r4b rc=$rc try=$try"
  if [ -e "$ckpt" ]; then
    if [ $rc -eq 0 ] || grep -q "step:50" $LOGD/theta_consol_theta-fl-refresh-r4b.log 2>/dev/null; then break; fi
    say "PARTIAL r4b → 清产物重试"; rm -rf $ROOT/ckpts/theta-fl-refresh-r4b
  fi
  cleanup_own theta-fl-refresh-r4b; sleep 60
done
[ -e "$ckpt" ] || { say "FATAL r4b 3 连败"; exit 1; }
D=$ROOT/ckpts/theta-fl-refresh-r4b/best/actor
mkdir -p $D/huggingface; find $D -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $D/huggingface/ \;
(cd $ROOT/opcd && $PY tools/merge_model2hf.py --local_dir "$D" >> $LOGD/theta_merge_r4b.log 2>&1) || { say "FATAL merge r4b"; exit 1; }
STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/theta-fl-refresh-r4b/best/COMMIT.json|head -1)
eprod=$ROOT/ckpts/theta-fl-refresh-r4b-eval/global_step_${STEP}/evaluation/scores.json
for try in 1 2 3; do
  [ -e "$eprod" ] && break
  wait_free 0 1
  say "EVAL r4b try=$try step=$STEP"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
    bash scripts/textgame_eval.sh --model "$D/huggingface" --exp_name theta-fl-refresh-r4b-eval --nnodes 1 --use_bsl true \
    --max_response_length 1024 \
    --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
    --ckpt ${STEP} trainer.n_gpus_per_node=2 \
    > $LOGD/theta_eval_theta-fl-refresh-r4b.log 2>&1)
  [ -e "$eprod" ] && break
  cleanup_own "theta-fl-refresh-r4b-eval"; sleep 60
done
read -r EV EN <<< "$(mean_score $eprod 2>/dev/null)"; HB=$(grep -oP '(?<="value": )[0-9.]+' $ROOT/ckpts/theta-fl-refresh-r4b/best/COMMIT.json|head -1)
say "RESULT theta-fl-refresh-r4b: eval=${EV:-FAIL}(n=${EN:-0}) heldout_best=$HB@step$STEP"
prune_shards theta-fl-refresh-r4b

say "==== Θ-E1e ALL_DONE ===="
