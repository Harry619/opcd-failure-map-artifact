#!/bin/bash
# Θ-E1g:分块式第二种子池构建(GPU2 门控,2026-10-01,用户"空闲窗口跑带断点长任务"机制模板)
# 把 ~2h 的池提取拆成 10 个 ~12min 候选块,每块独立产物=天然检查点,中断后续跑自动跳过已完成块
# 用途:基座第二种子池(seed 942),量化经验选择的种子方差(复现笔记 P5)
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=1000
export HF_HOME=/home/user-b/OPCD/hf_cache
export PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_e1g_status.log
FB=$ROOT/models/Qwen3-1.7B
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i 2 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 2)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free && { sleep 45; is_free && return 0; }; sleep 60; done; }
cleanup(){ pkill -u user-b -9 -f "theta-fl-pool2-c*\$*" 2>/dev/null; true; }

say "==== Θ-E1g start (pid $$): 分块池构建(基座 seed942,10 块×12min) ===="
for i in 1 2 3 4 5 6 7 8 9 10; do
  name=theta-fl-pool2-c$i
  pool=$ROOT/ckpts/$name/global_step_9${i}0/extract_1_samples
  [ -f "$pool/scores.json" ] && { say "SKIP chunk$i(产物在)"; continue; }
  wait_free
  say "CHUNK $i start"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 \
    bash scripts/textgame_extract.sh --model $FB --exp_name $name --nnodes 1 --ckpt 9${i}0 \
    --prompt_version v4 --exp_sel_with_prev False --val_samples_limit 1 \
    --max_response_length 8192 --textgame_name FrozenLake-v0-raw --textgame_max_response 1024 \
    --textgame_max_steps 5 --textgame_no_think False \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.85 \
    trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
    +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
    +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
    > $LOGD/theta_pool2_c$i.log 2>&1)
  rc=$?; n=$(ls "$pool/experiences" 2>/dev/null|grep -c experience)
  say "CHUNK $i rc=$rc exp=${n:-0}"
  [ "$rc" -ne 0 ] && { cleanup; sleep 60; }
done
say "==== Θ-E1g ALL_DONE: 10 块池齐,选择时汇总各块 scores.json ===="
