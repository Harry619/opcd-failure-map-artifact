#!/bin/bash
# Θ-E1h:refresh r3b 第三种子复跑(GPU0/1,2026-10-01 夜,回应 r4b 揭示的种子方差问题)
# 从 M2 重提池(943)+ seed=19 固化 + 评测;协议与主链完全一致
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=1000
export HF_HOME=/home/user-b/OPCD/hf_cache
export PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_e1h_status.log
M2=$ROOT/ckpts/theta-fl-refresh-r2/best/actor/huggingface
PY=$(command -v python); NSAMP=10
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
wait_disk(){ local d; while :; do d=$(df -BG /home/user-b|tail -1|awk '{gsub("G","",$4);print $4}'); [ "$d" -ge "$1" ] && return 0; say "WAIT disk"; sleep 300; done; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do local ok=1 g
  for g in "$@"; do is_free $g||{ ok=0;break;}; done
  if [ $ok -eq 1 ]; then sleep 60; ok=1
    for g in "$@"; do is_free $g||{ ok=0;break;}; done
    [ $ok -eq 1 ] && return 0
  fi
  sleep 60
done
}
cleanup_own(){ pkill -u user-b -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 5
  pgrep -u user-b -f "verl.trainer.main_pp[o]" >/dev/null 2>&1 || pkill -u user-b -9 -f "ray::WorkerDic[t]" 2>/dev/null
  sleep 3; true
}
prune_shards(){ local d=$ROOT/ckpts/$1/best/actor
  ls $d/huggingface/*.safetensors >/dev/null 2>&1 || return 0
  rm -f $d/*.pt; say "PRUNED $1"
}
EXTRA="trainer.n_gpus_per_node=2 ray_init.num_cpus=8 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.ref.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=12288 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.72 \
  actor_rollout_ref.rollout.max_num_batched_tokens=33792 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=32 \
  +trainer.save_best_only=True trainer.held_out_rollout=1 +trainer.best_eval_freq=10"
pick_best(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
items=[(i+1,sc(v)) for i,v in enumerate(s.values() if isinstance(s,dict) else s)]
b=max(items,key=lambda x:x[1]); n=len(items)
print(b[0],f"{b[1]:.6f}",n,f"{sum(x[1] for x in items)/n:.6f}")
PYEOF
}
mean_score(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f"{sum(vals)/max(len(vals),1):.6f}",len(vals))
PYEOF
}

say "==== Θ-E1h start (pid $$): refresh r3b(M2+池943+seed19) ===="
[ -d "$M2" ] || { say "FATAL M2 缺失"; exit 1; }

pool=$ROOT/ckpts/theta-fl-r3bext/global_step_943/extract_${NSAMP}_samples
for util in 0.85 0.90; do
  [ -f "$pool/scores.json" ] && break
  wait_free 1; wait_disk 20
  say "EXTRACT theta-fl-r3bext start util=$util (GPU1)"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=1 \
    bash scripts/textgame_extract.sh --model "$M2" --exp_name theta-fl-r3bext --nnodes 1 --ckpt 943 \
    --prompt_version v4 --exp_sel_with_prev False --val_samples_limit $NSAMP \
    --max_response_length 8192 --textgame_name FrozenLake-v0-raw --textgame_max_response 1024 \
    --textgame_max_steps 5 --textgame_no_think False \
    actor_rollout_ref.rollout.gpu_memory_utilization=$util \
    trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
    +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
    +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
    > $LOGD/theta_ext_theta-fl-r3bext.log 2>&1)
  rc=$?; n=$(ls "$pool/experiences" 2>/dev/null|grep -c experience)
  say "EXTRACT rc=$rc exp=${n:-0} util=$util"
  [ $rc -eq 0 ] && [ "${n:-0}" -ge $NSAMP ] && [ -f "$pool/scores.json" ] && break
  cleanup_own theta-fl-r3bext; sleep 30
done
[ -f "$pool/scores.json" ] || { say "FATAL extract"; exit 1; }
read -r EIDX ESCORE ENP EMEAN <<< "$(pick_best $pool/scores.json)"
EXPB=$pool/experiences/experience_${EIDX}.txt
[ -f "$EXPB" ] || EXPB=$(ls $pool/experiences/experience_*.txt|sort -V|sed -n "${EIDX}p")
cp -f "$EXPB" $ROOT/runs/theta_theta-fl-r3bext_best.txt
say "POOL: n=$ENP best=$ESCORE mean=$EMEAN"

ckpt=$ROOT/ckpts/theta-fl-refresh-r3b/best/COMMIT.json
for try in 1 2 3; do
  [ -e "$ckpt" ] && break
  wait_free 0 1; wait_disk 20
  say "CONSOL theta-fl-refresh-r3b start try=$try (seed=19)"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
    bash scripts/textgame_consolidate.sh --model "$M2" \
    --exp_name theta-fl-refresh-r3b --nnodes 1 \
    --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
    --max_response_length 1024 --experience_max_length 8192 \
    --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
    --exp_path "$EXPB" $EXTRA +actor_rollout_ref.rollout.seed=19 \
    > $LOGD/theta_consol_theta-fl-refresh-r3b.log 2>&1)
  rc=$?
  say "CONSOL rc=$rc try=$try"
  if [ -e "$ckpt" ]; then
    if [ $rc -eq 0 ] || grep -q "step:50" $LOGD/theta_consol_theta-fl-refresh-r3b.log 2>/dev/null; then break; fi
    rm -rf $ROOT/ckpts/theta-fl-refresh-r3b; say "PARTIAL → 清产物重试"
  fi
  cleanup_own theta-fl-refresh-r3b; sleep 60
done
[ -e "$ckpt" ] || { say "FATAL consol"; exit 1; }
D=$ROOT/ckpts/theta-fl-refresh-r3b/best/actor
mkdir -p $D/huggingface; find $D -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $D/huggingface/ \;
(cd $ROOT/opcd && $PY tools/merge_model2hf.py --local_dir "$D" >> $LOGD/theta_merge_r3b.log 2>&1) || { say "FATAL merge"; exit 1; }
STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/theta-fl-refresh-r3b/best/COMMIT.json|head -1)
eprod=$ROOT/ckpts/theta-fl-refresh-r3b-eval/global_step_${STEP}/evaluation/scores.json
for try in 1 2 3; do
  [ -e "$eprod" ] && break
  wait_free 0 1
  say "EVAL try=$try step=$STEP"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
    bash scripts/textgame_eval.sh --model "$D/huggingface" --exp_name theta-fl-refresh-r3b-eval --nnodes 1 --use_bsl true \
    --max_response_length 1024 \
    --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
    --ckpt ${STEP} trainer.n_gpus_per_node=2 \
    > $LOGD/theta_eval_r3b.log 2>&1)
  [ -e "$eprod" ] && break
  cleanup_own "theta-fl-refresh-r3b-eval"; sleep 60
done
read -r EV EN <<< "$(mean_score $eprod 2>/dev/null)"; HB=$(grep -oP '(?<="value": )[0-9.]+' $ROOT/ckpts/theta-fl-refresh-r3b/best/COMMIT.json|head -1)
say "RESULT theta-fl-refresh-r3b: eval=${EV:-FAIL}(n=${EN:-0}) heldout_best=$HB@step$STEP"
prune_shards theta-fl-refresh-r3b
say "==== Θ-E1h ALL_DONE(对照: r3 原值 0.258/r4b 0.156) ===="
