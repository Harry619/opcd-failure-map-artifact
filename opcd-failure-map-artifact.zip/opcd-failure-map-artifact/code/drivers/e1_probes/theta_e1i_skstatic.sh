#!/bin/bash
# Θ-E1i:SK static 延长链 s4→s5(GPU0/1,2026-10-02,用户指令"0/1 卡放实验")
# 目的:回答缺口表"SK static 是'还没崩'还是'不崩'"——FL static 第 2-3 轮崩,SK static 现有 s2=0.36/s3=0.35 无崩征兆
# 协议:与 E1b static 臂完全一致(固定 sk_exp2 反复固化、加固档 EXTRA),仅链起点改为 s3 的 best
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=1000
export HF_HOME=/home/user-b/OPCD/hf_cache
export PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH

ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_e1i_status.log
SK_EXP=$ROOT/runs/sk_exp2.txt
PY=$(command -v python)
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }

wait_disk(){ local d; while :; do d=$(df -BG /home/user-b|tail -1|awk '{gsub("G","",$4);print $4}'); [ "$d" -ge "$1" ] && return 0; say "WAIT disk ${d}G<$1G 5min"; sleep 300; done; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do local ok=1 g
  for g in "$@"; do is_free $g||{ ok=0;break;}; done
  if [ $ok -eq 1 ]; then sleep 60; ok=1
    for g in "$@"; do is_free $g||{ ok=0;break;}; done
    [ $ok -eq 1 ] && return 0
  fi
  sleep 60
done
}
cleanup_own(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 5
  pgrep -f "verl.trainer.main_pp[o]" >/dev/null 2>&1 || pkill -9 -f "ray::WorkerDic[t]" 2>/dev/null
  sleep 3; true
}
prune_shards(){ local d=$ROOT/ckpts/$1/best/actor
  ls $d/huggingface/*.safetensors >/dev/null 2>&1 || { say "PRUNE_SKIP $1"; return 0; }
  rm -f $d/*.pt; say "PRUNED $1 shards"
}

EXTRA="trainer.n_gpus_per_node=2 ray_init.num_cpus=8 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.ref.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=10240 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.70 \
  actor_rollout_ref.rollout.max_num_batched_tokens=33792 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=32 \
  +trainer.save_best_only=True trainer.held_out_rollout=1 +trainer.best_eval_freq=10"

mean_score(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f"{sum(vals)/max(len(vals),1):.6f}",len(vals))
PYEOF
}

do_consol(){ local model=$1 name=$2 expfile=$3
  local ckpt=$ROOT/ckpts/$2/best/COMMIT.json try rc
  for try in 1 2 3; do
    [ -e "$ckpt" ] && { say "SKIP consol $name"; return 0; }
    wait_free 0 1; wait_disk 15
    say "CONSOL $name start try=$try (GPU0/1)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
      bash scripts/textgame_consolidate.sh --model "$model" \
      --exp_name $name --nnodes 1 \
      --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
      --max_response_length 1024 --experience_max_length 8192 \
      --textgame_name Sokoban-v0 --textgame_max_steps 5 --textgame_no_think True \
      --exp_path "$expfile" $EXTRA \
      > $LOGD/theta_consol_${name}.log 2>&1)
    rc=$?
    say "CONSOL $name rc=$rc try=$try"
    if [ -e "$ckpt" ]; then
      if [ $rc -eq 0 ] || grep -q "step:50" $LOGD/theta_consol_${name}.log 2>/dev/null; then return 0; fi
      say "PARTIAL consol $name (rc=$rc, 未达 step:50) → 清产物重试"
      rm -rf $ROOT/ckpts/$name
    fi
    cleanup_own "$name"; sleep 60
  done
  say "FATAL consol $name 3 连败"; return 1
}

do_merge_eval(){ local name=$1
  local D=$ROOT/ckpts/$1/best/actor try rc
  if ! ls $D/huggingface/*.safetensors >/dev/null 2>&1; then
    mkdir -p $D/huggingface
    find $D -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $D/huggingface/ \;
    (cd $ROOT/opcd && $PY tools/merge_model2hf.py --local_dir "$D" >> $LOGD/theta_merge_${name}.log 2>&1) \
      || { say "FATAL merge $name"; return 1; }
    say "MERGED $name"
  fi
  STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/$name/best/COMMIT.json|head -1)
  local eprod=$ROOT/ckpts/${name}-eval/global_step_${STEP}/evaluation/scores.json
  for try in 1 2 3; do
    [ -e "$eprod" ] && break
    wait_free 0 1
    say "EVAL $name start try=$try (GPU0/1 step=$STEP)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,1 \
      bash scripts/textgame_eval.sh --model "$D/huggingface" --exp_name ${name}-eval --nnodes 1 --use_bsl true \
      --max_response_length 1024 \
      --textgame_name Sokoban-v0 --textgame_max_steps 5 --textgame_no_think True \
      --ckpt ${STEP} trainer.n_gpus_per_node=2 \
      > $LOGD/theta_eval_${name}.log 2>&1)
    rc=$?; say "EVAL $name rc=$rc try=$try"
    [ -e "$eprod" ] && break
    cleanup_own "${name}-eval"; sleep 60
  done
  [ -e "$eprod" ] || { say "FATAL eval $name"; return 1; }
  read -r EVALMEAN EVALN <<< "$(mean_score $eprod)"
  TRAJTOK=$(mean_score $ROOT/ckpts/${name}-eval/global_step_${STEP}/evaluation/avg_traj_tokens.json 2>/dev/null|cut -d' ' -f1)
  HELDBEST=$(grep -oP '(?<="value": )[0-9.]+' $ROOT/ckpts/$name/best/COMMIT.json|head -1)
  say "RESULT $name: eval=$EVALMEAN(n=$EVALN) heldout_best=$HELDBEST@step$STEP avg_traj_tokens=${TRAJTOK:-NA}"
  prune_shards $name
  return 0
}

say "==== Θ-E1i start (pid $$): GPU0/1 | SK static 延长 s4→s5 ===="
[ -f "$SK_EXP" ] || { say "FATAL 前置缺失 sk_exp2"; exit 1; }
[ -d "$ROOT/ckpts/theta-sk-static-r3/best/actor/huggingface" ] || { say "FATAL 前置缺失 s3 best"; exit 1; }
say "锚点:SK static s2=0.352(3种子0.328-0.383) s3=0.356(3种子0.344-0.367);FL static 对照:s2≈0.12→s3 区 0.00-0.10"

say "---- P1: SK static s4 ----"
do_consol $ROOT/ckpts/theta-sk-static-r3/best/actor/huggingface theta-sk-static-r4 "$SK_EXP" || exit 1
do_merge_eval theta-sk-static-r4 || exit 1

say "---- P2: SK static s5 ----"
do_consol $ROOT/ckpts/theta-sk-static-r4/best/actor/huggingface theta-sk-static-r5 "$SK_EXP" || exit 1
do_merge_eval theta-sk-static-r5 || exit 1

say "==== Θ-E1i ALL_DONE ===="
grep -E "RESULT" "$ST" | tail -4
