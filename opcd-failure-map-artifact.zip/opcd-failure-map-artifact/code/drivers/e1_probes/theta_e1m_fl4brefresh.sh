#!/bin/bash
# Θ-E1m:FL@4B refresh 短链 r2→r3(GPU2/3,2026-10-03;补 2×2×2 立方最后一格:C3 自举-容量假说的第二域证据)
# 协议:E1j 同构(4B 加固档 10240/0.70,FL 游戏 no_think=True);M1=已迁回的 theta-fl4b-m1
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=1000
export HF_HOME=/home/user-b/OPCD/hf_cache
export PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_e1m_status.log
M1=$ROOT/ckpts/theta-fl4b-m1/best/actor/huggingface
PY=$(command -v python); NSAMP=10
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
wait_disk(){ local d; while :; do d=$(df -BG /home/user-b|tail -1|awk '{gsub("G","",$4);print $4}'); [ "$d" -ge "$1" ] && return 0; say "WAIT disk ${d}G<$1G 5min"; sleep 300; done; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do local ok=1 g
  for g in "$@"; do is_free $g||{ ok=0;break;}; done
  if [ $ok -eq 1 ]; then sleep 60; ok=1
    for g in "$@"; do is_free $g||{ ok=0;break;}; done
    [ $ok -eq 1 ] && return 0
  fi
  sleep 60
done
}
cleanup_own(){ pkill -u user-b -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 5
  pgrep -u user-b -f "verl.trainer.main_pp[o]" >/dev/null 2>&1 || pkill -u user-b -9 -f "ray::WorkerDic[t]" 2>/dev/null
  sleep 3; true
}
prune_shards(){ local d=$ROOT/ckpts/$1/best/actor
  ls $d/huggingface/*.safetensors >/dev/null 2>&1 || { say "PRUNE_SKIP $1"; return 0; }
  rm -f $d/*.pt; say "PRUNED $1 shards"
}
EXTRA="trainer.n_gpus_per_node=2 ray_init.num_cpus=8 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.ref.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=10240 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.70 \
  actor_rollout_ref.rollout.max_num_batched_tokens=33792 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=32 \
  +trainer.save_best_only=True trainer.held_out_rollout=1 +trainer.best_eval_freq=10"
pick_best(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
items=[(i+1,sc(v)) for i,v in enumerate(s.values() if isinstance(s,dict) else s)]
b=max(items,key=lambda x:x[1]); n=len(items)
print(b[0],f"{b[1]:.6f}",n,f"{sum(x[1] for x in items)/n:.6f}")
PYEOF
}
mean_score(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f"{sum(vals)/max(len(vals),1):.6f}",len(vals))
PYEOF
}
do_extract(){ local model=$1 name=$2 label=$3 util rc n
  local pool=$ROOT/ckpts/$name/global_step_$label/extract_${NSAMP}_samples
  for util in 0.85 0.90; do
    [ -f "$pool/scores.json" ] && break
    wait_free 3; wait_disk 15
    say "EXTRACT $name start util=$util (GPU3 单卡)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=3 \
      bash scripts/textgame_extract.sh --model "$model" --exp_name $name --nnodes 1 --ckpt $label \
      --prompt_version v4 --exp_sel_with_prev False --val_samples_limit $NSAMP \
      --max_response_length 8192 --textgame_name FrozenLake-v0-raw --textgame_max_response 1024 \
      --textgame_max_steps 5 --textgame_no_think True \
      actor_rollout_ref.rollout.gpu_memory_utilization=$util \
      trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
      +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
      +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
      > $LOGD/theta_ext_${name}.log 2>&1)
    rc=$?; n=$(ls "$pool/experiences" 2>/dev/null|grep -c experience)
    say "EXTRACT $name rc=$rc exp_files=${n:-0} util=$util"
    [ $rc -eq 0 ] && [ "${n:-0}" -ge $NSAMP ] && [ -f "$pool/scores.json" ] && break
    cleanup_own "$name"; sleep 30
  done
  [ -f "$pool/scores.json" ] || { say "FATAL extract $name"; return 1; }
  read -r EIDX ESCORE EN EMEAN <<< "$(pick_best $pool/scores.json)"
  EXPBEST=$pool/experiences/experience_${EIDX}.txt
  [ -f "$EXPBEST" ] || EXPBEST=$(ls $pool/experiences/experience_*.txt 2>/dev/null|sort -V|sed -n "${EIDX}p")
  [ -f "$EXPBEST" ] || { say "FATAL extract $name 候选缺失"; return 1; }
  cp -f "$EXPBEST" $ROOT/runs/theta_${name}_best.txt
  say "POOL $name: n=$EN best=$ESCORE mean=$EMEAN → $(basename $EXPBEST)"
  return 0
}
do_consol(){ local model=$1 name=$2 expfile=$3
  local ckpt=$ROOT/ckpts/$2/best/COMMIT.json try rc
  for try in 1 2 3; do
    [ -e "$ckpt" ] && { say "SKIP consol $name"; return 0; }
    wait_free 2 3; wait_disk 15
    say "CONSOL $name start try=$try (GPU2/3)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2,3 \
      bash scripts/textgame_consolidate.sh --model "$model" \
      --exp_name $name --nnodes 1 \
      --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
      --max_response_length 1024 --experience_max_length 8192 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think True \
      --exp_path "$expfile" $EXTRA \
      > $LOGD/theta_consol_${name}.log 2>&1)
    rc=$?
    say "CONSOL $name rc=$rc try=$try"
    if [ -e "$ckpt" ]; then
      if [ $rc -eq 0 ] || grep -q "step:50" $LOGD/theta_consol_${name}.log 2>/dev/null; then return 0; fi
      say "PARTIAL consol $name (rc=$rc, 未达 step:50) → 清产物重试"
      rm -rf $ROOT/ckpts/$name
    fi
    cleanup_own "$name"; sleep 60
  done
  say "FATAL consol $name 3 连败"; return 1
}
do_merge_eval(){ local name=$1
  local D=$ROOT/ckpts/$1/best/actor try rc
  if ! ls $D/huggingface/*.safetensors >/dev/null 2>&1; then
    mkdir -p $D/huggingface
    find $D -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $D/huggingface/ \;
    (cd $ROOT/opcd && $PY tools/merge_model2hf.py --local_dir "$D" >> $LOGD/theta_merge_${name}.log 2>&1) \
      || { say "FATAL merge $name"; return 1; }
    say "MERGED $name"
  fi
  STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/$name/best/COMMIT.json|head -1)
  local eprod=$ROOT/ckpts/${name}-eval/global_step_${STEP}/evaluation/scores.json
  for try in 1 2 3; do
    [ -e "$eprod" ] && break
    wait_free 2 3
    say "EVAL $name start try=$try (GPU2/3 step=$STEP)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2,3 \
      bash scripts/textgame_eval.sh --model "$D/huggingface" --exp_name ${name}-eval --nnodes 1 --use_bsl true \
      --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think True \
      --ckpt ${STEP} trainer.n_gpus_per_node=2 \
      > $LOGD/theta_eval_${name}.log 2>&1)
    rc=$?; say "EVAL $name rc=$rc try=$try"
    [ -e "$eprod" ] && break
    cleanup_own "${name}-eval"; sleep 60
  done
  [ -e "$eprod" ] || { say "FATAL eval $name"; return 1; }
  read -r EVALMEAN EVALN <<< "$(mean_score $eprod)"
  HELDBEST=$(grep -oP '(?<="value": )[0-9.]+' $ROOT/ckpts/$name/best/COMMIT.json|head -1)
  say "RESULT $name: eval=$EVALMEAN(n=$EVALN) heldout_best=$HELDBEST@step$STEP"
  prune_shards $name
  return 0
}
say "==== Θ-E1m start (pid $$): GPU2/3 | FL@4B refresh r2→r3(立方最后一格) ===="
[ -d "$M1" ] || { say "FATAL 前置缺失 M1"; exit 1; }
say "对照:M1≈0.90(3种子);SK@4B refresh=M1 0.20→r2 0.38→r3 0.53(容量-自举正例);FL@1.7B refresh 无自举"
say "---- P1: FL@4B refresh r2 ----"
do_extract "$M1" theta-fl4b-r2ext 964 || exit 1
do_consol "$M1" theta-fl4b-refresh-r2 "$EXPBEST" || exit 1
do_merge_eval theta-fl4b-refresh-r2 || exit 1
say "---- P2: FL@4B refresh r3 ----"
do_extract $ROOT/ckpts/theta-fl4b-refresh-r2/best/actor/huggingface theta-fl4b-r3ext 965 || exit 1
do_consol $ROOT/ckpts/theta-fl4b-refresh-r2/best/actor/huggingface theta-fl4b-refresh-r3 "$EXPBEST" || exit 1
do_merge_eval theta-fl4b-refresh-r3 || exit 1
say "==== Θ-E1m ALL_DONE ===="
grep -E "RESULT" "$ST" | tail -2
