#!/bin/bash
# Θ-E2a-B r6 收官轮(H20 版,2026-10-08):user-b 统一迁 H20 后的 B 臂末轮
# 父本:e2a-guard-r5rt best(经 user-b→A800→H20 中转就位);协议=guard 链逐字同
# r6 主轨(seed31)→评测→回滚判读(r6rt seed131)→E2a-B 收官 ALL_DONE
# GPU:0/2 挤占档(排 B2 后);等待:r5rt relay 标记 + B2 退出
ROOT=$HOME/OPCD-improve
LOGD=$ROOT/logs; ST=$LOGD/theta_e2aB_r6_h20_status.log
PARENT=$ROOT/ckpts/e2a-guard-r5rt/best/actor/huggingface; [ -d $ROOT/ckpts/e2a-guard-r5rt/best/actor/huggingface ] || PARENT=$ROOT/ckpts/e2a-guard-r5/best/actor/huggingface
PYBIN=$ROOT/envs/opcd/bin
export PATH=$PYBIN:$PATH
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 HF_HOME=$ROOT/hf_cache
export TMPDIR=$ROOT/tmp RAY_TMPDIR=$ROOT/ray_tmp
NSAMP=10; SEED=31; SEEDRT=131
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
wait_pred(){ while { [ ! -f $HOME/OPCD-improve/ckpts/.relay_e2a-guard-r5rt_done ] && [ ! -f $HOME/OPCD-improve/ckpts/.relay_e2a-guard-r5_done ]; } || [ ! -f $HOME/OPCD-improve/envs/opcd/.ready ]; do sleep 300; done; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 95000 ] && return 0; return 1
}
wait_free(){ while :; do local ok=1 g
  for g in "$@"; do is_free $g||{ ok=0;break;}; done
  if [ $ok -eq 1 ]; then sleep 60; ok=1
    for g in "$@"; do is_free $g||{ ok=0;break;}; done
    [ $ok -eq 1 ] && return 0
  fi
  sleep 60
done
}
cleanup_own(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 5
  pgrep -f "verl.trainer.main_pp[o]" >/dev/null 2>&1 || pkill -9 -f "ray::WorkerDic[t]" 2>/dev/null; sleep 3; true
}
EXTRA="trainer.n_gpus_per_node=2 ray_init.num_cpus=8 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.ref.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=12288 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.25 \
  actor_rollout_ref.rollout.max_num_batched_tokens=33792 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=32 \
  +trainer.save_best_only=True trainer.held_out_rollout=1 +trainer.best_eval_freq=10"
pick_best(){ $PYBIN/python - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
items=[(i+1,sc(v)) for i,v in enumerate(s.values() if isinstance(s,dict) else s)]
b=max(items,key=lambda x:x[1]); n=len(items)
print(b[0],f"{b[1]:.6f}",n,f"{sum(x[1] for x in items)/n:.6f}")
PYEOF
}
mean_score(){ $PYBIN/python - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f"{sum(vals)/max(len(vals),1):.6f}",len(vals))
PYEOF
}
do_extract(){ local model=$1 name=$2 label=$3 util rc n
  local pool=$ROOT/ckpts/$name/global_step_$label/extract_${NSAMP}_samples
  for util in 0.25 0.30; do
    [ -f "$pool/scores.json" ] && break
    wait_free 3; wait_disk
    say "EXTRACT $name start util=$util(GPU0 单卡)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0 \
      bash scripts/textgame_extract.sh --model "$model" --exp_name $name --nnodes 1 --ckpt $label \
      --prompt_version v4 --exp_sel_with_prev False --val_samples_limit $NSAMP \
      --max_response_length 8192 --textgame_name FrozenLake-v0-raw --textgame_max_response 1024 \
      --textgame_max_steps 5 --textgame_no_think False \
      trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
      +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
      +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
      actor_rollout_ref.rollout.gpu_memory_utilization=$util \
      > $LOGD/theta_ext_${name}.log 2>&1)
    rc=$?; n=$(ls "$pool/experiences" 2>/dev/null|grep -c experience)
    say "EXTRACT $name rc=$rc exp_files=${n:-0}"
    [ $rc -eq 0 ] && [ "${n:-0}" -ge $NSAMP ] && [ -f "$pool/scores.json" ] && break
    cleanup_own "$name"; sleep 30
  done
  [ -f "$pool/scores.json" ] || { say "FATAL extract $name"; return 1; }
  read -r EIDX ESCORE EN EMEAN <<< "$(pick_best $pool/scores.json)"
  EXPBEST=$pool/experiences/experience_${EIDX}.txt
  [ -f "$EXPBEST" ] || EXPBEST=$(ls $pool/experiences/experience_*.txt 2>/dev/null|sort -V|sed -n "${EIDX}p")
  cp -f "$EXPBEST" $ROOT/runs/theta_${name}_best.txt
  say "POOL $name: n=$EN best=$ESCORE mean=$EMEAN"
}
wait_disk(){ local d; while :; do d=$(df -BG $ROOT 2>/dev/null|tail -1|awk '{gsub("G","",$4);print $4}'); [ "$d" -ge 50 ] && return 0; say "WAIT disk ${d}G"; sleep 300; done; }
do_consol(){ local model=$1 name=$2 expfile=$3 sd=$4
  local ckpt=$ROOT/ckpts/$2/best/COMMIT.json try rc
  for try in 1 2 3; do
    [ -e "$ckpt" ] && { say "SKIP consol $name"; return 0; }
    wait_free 0 2; wait_disk
    say "CONSOL $name start try=$try (GPU0/2 seed=$sd)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,2 \
      bash scripts/textgame_consolidate.sh --model "$model" \
        --exp_name $name --nnodes 1 \
        --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
        --max_response_length 1024 --experience_max_length 8192 \
        --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
        --exp_path "$expfile" $EXTRA +actor_rollout_ref.rollout.seed=$sd \
        > $LOGD/theta_consol_${name}.log 2>&1)
    rc=$?
    say "CONSOL $name rc=$rc try=$try"
    if [ -e "$ckpt" ]; then
      if [ $rc -eq 0 ] || grep -q "step:50" $LOGD/theta_consol_${name}.log 2>/dev/null; then return 0; fi
      say "PARTIAL consol $name → 清产物重试"
      rm -rf $ROOT/ckpts/$name
    fi
    cleanup_own "$name"; sleep 60
  done
  say "FATAL consol $name 3 连败"; return 1
}
do_eval(){ local name=$1
  local D=$ROOT/ckpts/$1/best/actor try rc
  if ! ls $D/huggingface/*.safetensors >/dev/null 2>&1; then
    mkdir -p $D/huggingface
    find $D -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $D/huggingface/ \;
    (cd $ROOT/opcd && $PYBIN/python tools/merge_model2hf.py --local_dir "$D" >> $LOGD/theta_merge_${name}.log 2>&1) \
      || { say "FATAL merge $name"; return 1; }
  fi
  STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/$name/best/COMMIT.json|head -1)
  local eprod=$ROOT/ckpts/${name}-eval/global_step_${STEP}/evaluation/scores.json
  for try in 1 2 3; do
    [ -e "$eprod" ] && break
    wait_free 0 2
    say "EVAL $name start try=$try (step=$STEP)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0,2 \
      bash scripts/textgame_eval.sh --model "$D/huggingface" --exp_name ${name}-eval --nnodes 1 --use_bsl true \
      --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      --ckpt ${STEP} trainer.n_gpus_per_node=2 \
      > $LOGD/theta_eval_${name}.log 2>&1)
    rc=$?; say "EVAL $name rc=$rc try=$try"
    [ -e "$eprod" ] && break
    cleanup_own "${name}-eval"; sleep 60
  done
  [ -e "$eprod" ] || { say "FATAL eval $name"; return 1; }
  read -r EVALMEAN EVALN <<< "$(mean_score $eprod)"
  say "RESULT $name: eval=$EVALMEAN(n=$EVALN)"
}
say "==== Θ-E2a-B r6 收官轮(H20)start (pid $$):等 r5rt relay+B2 退出 ===="
wait_pred
say "依赖就绪。r6 主轨(seed31)"
do_extract "$PARENT" e2a-guardext-r6 976 || exit 1
do_consol "$PARENT" e2a-guard-r6 "$EXPBEST" $SEED || exit 1
do_eval e2a-guard-r6 || exit 1
R6EVAL=$EVALMEAN; R6BEST=$ROOT/ckpts/e2a-guard-r6/best/actor/huggingface
PREV=0.094
if [ $(awk -v e="$R6EVAL" -v p="$PREV" 'BEGIN{print (e<0.6*p)?1:0}') -eq 1 ]; then
  say "ROLLBACK r6 eval=$R6EVAL < 0.6*$PREV → 重试"
  do_extract "$PARENT" e2a-guardext-r6rt 976 || exit 1
  do_consol "$PARENT" e2a-guard-r6rt "$EXPBEST" $SEEDRT || exit 1
  do_eval e2a-guard-r6rt || exit 1
  if [ $(awk -v a="$EVALMEAN" -v b="$R6EVAL" 'BEGIN{print (a>b)?1:0}') -eq 1 ]; then
    say "RETRY_WIN r6 → 采信重试"; R6EVAL=$EVALMEAN
  else say "RETRY_FAIL r6 → 采信原轮"; fi
else say "GUARD_HOLD r6 eval=$R6EVAL"; fi
say "==== Θ-E2a-B ALL_DONE(H20 收官)===="
grep -E "RESULT|ROLLBACK|RETRY|GUARD" "$ST" | tail -6
