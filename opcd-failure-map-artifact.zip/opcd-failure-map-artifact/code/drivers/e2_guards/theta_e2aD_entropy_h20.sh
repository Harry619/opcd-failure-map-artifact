#!/bin/bash
# Θ-E2a-C: e2a-entropy 组合守门(A臂双门重锚 + B臂回滚;H20 GPU3 单卡挤占档)
# 预注册: theta_e2_design.md §五(2026-10-11);判据发车前定死
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=1000
export HF_HOME=$HOME/OPCD-improve/hf_cache TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_e2aD_status.log
M1=$ROOT/ckpts/fl-q3-1b7-consol2/best/actor/huggingface
FL_EXP=$ROOT/runs/fl_exp26.txt
PY=$(command -v python); NSAMP=10; SEED=31; SEEDRT=131
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
wait_disk(){ local d; while :; do d=$(df -BG $HOME|tail -1|awk '{gsub("G","",$4);print $4}'); [ "$d" -ge "$1" ] && return 0; say "WAIT disk ${d}G<$1G 5min"; sleep 300; done; }
g2_mem(){ nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 3; }
wait_g3(){ local th=$1; while [ "$(g2_mem)" -ge "$th" ]; do say "WAIT gpu3 $(g2_mem)MiB>=$th 2min"; sleep 120; done; }
cleanup_own(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 5; true; }
prune_shards(){ local d=$ROOT/ckpts/$1/best/actor
  ls $d/huggingface/*.safetensors >/dev/null 2>&1 || { say "PRUNE_SKIP $1"; return 0; }
  rm -f $d/*.pt
}
last_entropy(){ grep -o "actor/entropy:[0-9.]*" $LOGD/theta_consol_$1.log 2>/dev/null | tail -1 | cut -d: -f2; }
pick_best(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
items=[(i+1,sc(v)) for i,v in enumerate(s.values() if isinstance(s,dict) else s)]
b=max(items,key=lambda x:x[1]); n=len(items)
print(b[0],f"{b[1]:.6f}",n,f"{sum(x[1] for x in items)/n:.6f}")
PYEOF
}
mean_score(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f"{sum(vals)/max(len(vals),1):.6f}",len(vals))
PYEOF
}
do_extract(){ local model=$1 name=$2 label=$3 util rc n
  local pool=$ROOT/ckpts/$name/global_step_$label/extract_${NSAMP}_samples
  for util in 0.50 0.60; do
    [ -f "$pool/scores.json" ] && break
    wait_free 3; wait_disk 15
    say "EXTRACT $name start util=$util (GPU3 单卡)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=3 \
      bash scripts/textgame_extract.sh --model "$model" --exp_name $name --nnodes 1 --ckpt $label \
      --prompt_version v4 --exp_sel_with_prev False --val_samples_limit $NSAMP \
      --max_response_length 8192 --textgame_name FrozenLake-v0-raw --textgame_max_response 1024 \
      --textgame_max_steps 5 --textgame_no_think False \
      actor_rollout_ref.rollout.gpu_memory_utilization=$util \
      trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
      +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
      +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
      > $LOGD/theta_ext_${name}.log 2>&1)
    rc=$?; n=$(ls "$pool/experiences" 2>/dev/null|grep -c experience)
    say "EXTRACT $name rc=$rc exp_files=${n:-0} util=$util"
    [ $rc -eq 0 ] && [ "${n:-0}" -ge $NSAMP ] && [ -f "$pool/scores.json" ] && break
    cleanup_own "$name"; sleep 30
  done
  [ -f "$pool/scores.json" ] || { say "FATAL extract $name"; return 1; }
  read -r EIDX ESCORE EN EMEAN <<< "$(pick_best $pool/scores.json)"
  EXPBEST=$pool/experiences/experience_${EIDX}.txt
  [ -f "$EXPBEST" ] || EXPBEST=$(ls $pool/experiences/experience_*.txt 2>/dev/null|sort -V|sed -n "${EIDX}p")
  [ -f "$EXPBEST" ] || { say "FATAL extract $name 候选缺失"; return 1; }
  cp -f "$EXPBEST" $ROOT/runs/theta_${name}_best.txt
  say "POOL $name: n=$EN best=$ESCORE mean=$EMEAN"
  return 0
}
EXTRA="trainer.n_gpus_per_node=2 ray_init.num_cpus=8 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.ref.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=12288 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.35 \
  actor_rollout_ref.rollout.max_num_batched_tokens=33792 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=32 \
  +trainer.save_best_only=True trainer.held_out_rollout=1 +trainer.best_eval_freq=10"
do_consol(){ local model=$1 name=$2 expfile=$3 sd=$4
  local ckpt=$ROOT/ckpts/$2/best/COMMIT.json try rc
  for try in 1 2 3; do
    [ -e "$ckpt" ] && { say "SKIP consol $name"; return 0; }
    wait_free 3; wait_disk 15
    say "CONSOL $name start try=$try (GPU3 单卡 seed=$sd)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2,3 \
      bash scripts/textgame_consolidate.sh --model "$model" \
        --exp_name $name --nnodes 1 \
        --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
        --max_response_length 1024 --experience_max_length 8192 \
        --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
        --exp_path "$expfile" $EXTRA +actor_rollout_ref.rollout.seed=$sd \
        > $LOGD/theta_consol_${name}.log 2>&1)
    rc=$?
    say "CONSOL $name rc=$rc try=$try"
    if [ -e "$ckpt" ]; then
      if [ $rc -eq 0 ] || grep -q "step:50" $LOGD/theta_consol_${name}.log 2>/dev/null; then return 0; fi
      say "PARTIAL consol $name → 清产物重试"
      rm -rf $ROOT/ckpts/$name
    fi
    cleanup_own "$name"; sleep 60
  done
  say "FATAL consol $name 3 连败"; return 1
}
do_merge_eval(){ local name=$1
  local D=$ROOT/ckpts/$1/best/actor try rc
  if ! ls $D/huggingface/*.safetensors >/dev/null 2>&1; then
    mkdir -p $D/huggingface
    find $D -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $D/huggingface/ \;
    (cd $ROOT/opcd && $PY tools/merge_model2hf.py --local_dir "$D" >> $LOGD/theta_merge_${name}.log 2>&1) \
      || { say "FATAL merge $name"; return 1; }
    say "MERGED $name"
  fi
  STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/$name/best/COMMIT.json|head -1)
  local eprod=$ROOT/ckpts/${name}-eval/global_step_${STEP}/evaluation/scores.json
  for try in 1 2 3; do
    [ -e "$eprod" ] && break
    wait_free 2 3
    say "EVAL $name start try=$try (GPU2 step=$STEP)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2,3 \
      bash scripts/textgame_eval.sh --model "$D/huggingface" --exp_name ${name}-eval --nnodes 1 --use_bsl true \
      --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      --ckpt ${STEP} trainer.n_gpus_per_node=1 \
      actor_rollout_ref.rollout.gpu_memory_utilization=0.55 \
      > $LOGD/theta_eval_${name}.log 2>&1)
    rc=$?; say "EVAL $name rc=$rc try=$try"
    [ -e "$eprod" ] && break
    cleanup_own "${name}-eval"; sleep 60
  done
  [ -e "$eprod" ] || { say "FATAL eval $name"; return 1; }
  read -r EVALMEAN EVALN <<< "$(mean_score $eprod)"
  say "RESULT $name: eval=$EVALMEAN(n=$EVALN)"
  prune_shards $name
  return 0
}

say "==== Θ-E2a-D start (pid $$): e2a-entropy 纯熵门同轨(E2a-C 去 B 门;等 B3 退出接 GPU3) ===="
wait_pred(){ sleep 5; }
wait_pred
say "B3 已退出,接卡 GPU3。预注册:seed=31,纯 A 门(熵带[0.132,0.150]或eval<0.75×峰→重锚),无回滚,6轮;与 E2a-C 单变量对照=去 B 门"
[ -d "$M1" ] && [ -f "$FL_EXP" ] || { say "FATAL 前置缺失"; exit 1; }
CUR=$M1; EXP=$FL_EXP; PEAK=0.279
for n in 1 2 3 4 5 6; do
  say "---- C 轮 $n(mode=$( [ -f "$ROOT/runs/theta_e2a-entropy-anchorext-r${n}_best.txt" ] && echo refresh-anchored || echo static ))----"
  do_consol "$CUR" e2a-entropy-r$n "$EXP" $SEED || exit 1
  do_merge_eval e2a-entropy-r$n || exit 1
  ROUND_EVAL=$EVALMEAN; ROUND_BEST=$ROOT/ckpts/e2a-entropy-r$n/best/actor/huggingface; ROUND_ENT=$(last_entropy e2a-entropy-r$n)
  say "ENT_TRACK r$n eval=$ROUND_EVAL (纯熵门臂:无回滚门,原轮直接采信)"
  FIRE=0; REASON=""
  if [ -n "$ROUND_ENT" ]; then
    [ $(awk -v a="$ROUND_ENT" 'BEGIN{print (a<0.132)?1:0}') -eq 1 ] && { FIRE=1; REASON="sharpening(entropy=$ROUND_ENT<0.132)"; }
    [ $(awk -v a="$ROUND_ENT" 'BEGIN{print (a>0.150)?1:0}') -eq 1 ] && { FIRE=1; REASON="flattening(entropy=$ROUND_ENT>0.150)"; }
  fi
  [ $(awk -v e="$ROUND_EVAL" -v p="$PEAK" 'BEGIN{print (e<0.75*p)?1:0}') -eq 1 ] && { FIRE=1; REASON="$REASON eval_drop($ROUND_EVAL<0.75*$PEAK)"; }
  if [ $FIRE -eq 1 ]; then
    say "ENT_ANCHOR r$n reason=$REASON → 从采信轮模型重提换锚"
    do_extract "$ROUND_BEST" e2a-entropy-anchorext-r$n 99$n || exit 1
    EXP=$ROOT/runs/theta_e2a-entropy-anchorext-r${n}_best.txt
  else
    say "ENT_GATE_HOLD r$n(A门未触发,static 继续)"
  fi
  PEAK=$(awk -v e="$ROUND_EVAL" -v p="$PEAK" 'BEGIN{print (e>p)?e:p}')
  PREVBEST=$ROUND_BEST; PREV_EVAL=$ROUND_EVAL; CUR=$ROUND_BEST
done
say "==== Θ-E2a-D ALL_DONE ===="
grep -E "RESULT|ENT_" "$ST" | tail -20
