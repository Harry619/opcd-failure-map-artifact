#!/bin/bash
# Θ-E2b:SK@4B refresh 平台攻击(GPU2/3;加宽池 20 候选 + 池门;延长 r6-r7)
# 设计:04_笔记/theta_e2_design.md §三;预注册判据(2026-10-04 定死):
#   r6/r7 任一 ≥0.56 → 平台=提取饱和(容量内仍有空间,C3 加强);
#   两轮均 ≈0.53(±0.023 噪声带) → 平台=域/上下文天花板(同样写入 C3)。
# 池门:提取池 best < 0.6×模型当前 eval → 重提一次,两池取较优;再低则接受并标记。
# 发车协议("视型发车",E2a 出型后用户拍板):
#   1) 本脚本启动后先等 e2a-guard 退出(wait_pred),再等发车令文件 runs/e2b_go;
#   2) 拍板后执行: ssh user-b 'touch /home/user-b/OPCD/runs/e2b_go'
#   3) L40 侧 theta_e2b_push_r5.sh 探测到 go 即推送 r5 父本(8.3G),推完 touch runs/e2b_r5_ready;
#   4) 本脚本确认 r5 就位后开跑。全程无人值守,断点续跑幂等(产物存在即 SKIP)。
# 已知限制(与 E2a 同):中断重启后 CUR_EVAL 回初值 0.531,池门基线偏松,巡检日志可查。
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=1000
export HF_HOME=/home/user-b/OPCD/hf_cache
export PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_e2b_status.log
R5=$ROOT/ckpts/theta-sk-refresh-r5/best/actor/huggingface
PY=$(command -v python); NSAMP=20
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
wait_pred(){ while pgrep -u user-b -f "theta_e2a_guar[d]" >/dev/null 2>&1; do sleep 120; done; }
wait_go(){ while [ ! -f $ROOT/runs/e2b_go ]; do sleep 300; done; }
wait_r5(){ while :; do
  [ -f "$R5/model.safetensors.index.json" ] && ls "$R5"/model-*-of-*.safetensors >/dev/null 2>&1 && return 0
  sleep 300; done; }
wait_disk(){ local d; while :; do d=$(df -BG /home/user-b|tail -1|awk '{gsub("G","",$4);print $4}'); [ "$d" -ge "$1" ] && return 0; say "WAIT disk ${d}G<$1G 5min"; sleep 300; done; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do local ok=1 g
  for g in "$@"; do is_free $g||{ ok=0;break;}; done
  if [ $ok -eq 1 ]; then sleep 60; ok=1
    for g in "$@"; do is_free $g||{ ok=0;break;}; done
    [ $ok -eq 1 ] && return 0
  fi
  sleep 60
done
}
cleanup_own(){ pkill -u user-b -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 5
  pgrep -u user-b -f "verl.trainer.main_pp[o]" >/dev/null 2>&1 || pkill -u user-b -9 -f "ray::WorkerDic[t]" 2>/dev/null
  sleep 3; true
}
prune_shards(){ local d=$ROOT/ckpts/$1/best/actor
  ls $d/huggingface/*.safetensors >/dev/null 2>&1 || { say "PRUNE_SKIP $1"; return 0; }
  rm -f $d/*.pt
}
# SK@4B 加固档(E1b 2026-09-29 修订:token 预算 10240 / util 0.70 压 update 峰值防邻居挤卡 OOM)
EXTRA="trainer.n_gpus_per_node=2 ray_init.num_cpus=8 \
  +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
  actor_rollout_ref.actor.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=True \
  actor_rollout_ref.ref.fsdp_config.param_offload=True \
  actor_rollout_ref.actor.ppo_max_token_len_per_gpu=10240 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.70 \
  actor_rollout_ref.rollout.max_num_batched_tokens=33792 \
  actor_rollout_ref.rollout.enable_chunked_prefill=False \
  +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=32 \
  +trainer.save_best_only=True trainer.held_out_rollout=1 +trainer.best_eval_freq=10"
pick_best(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
items=[(i+1,sc(v)) for i,v in enumerate(s.values() if isinstance(s,dict) else s)]
b=max(items,key=lambda x:x[1]); n=len(items)
print(b[0],f"{b[1]:.6f}",n,f"{sum(x[1] for x in items)/n:.6f}")
PYEOF
}
mean_score(){ $PY - "$1" <<'PYEOF'
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except (TypeError,ValueError):
        if isinstance(v,list):
            try: return sum(map(float,v))/len(v)
            except Exception: return 0.0
        return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f"{sum(vals)/max(len(vals),1):.6f}",len(vals))
PYEOF
}
do_extract(){ local model=$1 name=$2 label=$3 util rc n
  local pool=$ROOT/ckpts/$name/global_step_$label/extract_${NSAMP}_samples
  for util in 0.85 0.90; do
    [ -f "$pool/scores.json" ] && break
    wait_free 3; wait_disk 18
    say "EXTRACT $name start util=$util (GPU3 单卡,${NSAMP} 候选)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=3 \
      bash scripts/textgame_extract.sh --model "$model" --exp_name $name --nnodes 1 --ckpt $label \
      --prompt_version v4 --exp_sel_with_prev False --val_samples_limit $NSAMP \
      --max_response_length 8192 --textgame_name Sokoban-v0 --textgame_max_response 1024 \
      --textgame_max_steps 5 --textgame_no_think True \
      actor_rollout_ref.rollout.gpu_memory_utilization=$util \
      trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
      +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
      +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
      > $LOGD/theta_ext_${name}.log 2>&1)
    rc=$?; n=$(ls "$pool/experiences" 2>/dev/null|grep -c experience)
    say "EXTRACT $name rc=$rc exp_files=${n:-0} util=$util"
    [ $rc -eq 0 ] && [ "${n:-0}" -ge $NSAMP ] && [ -f "$pool/scores.json" ] && break
    cleanup_own "$name"; sleep 30
  done
  [ -f "$pool/scores.json" ] || { say "FATAL extract $name"; return 1; }
  read -r EIDX ESCORE EN EMEAN <<< "$(pick_best $pool/scores.json)"
  EXPBEST=$pool/experiences/experience_${EIDX}.txt
  [ -f "$EXPBEST" ] || EXPBEST=$(ls $pool/experiences/experience_*.txt 2>/dev/null|sort -V|sed -n "${EIDX}p")
  [ -f "$EXPBEST" ] || { say "FATAL extract $name 候选缺失"; return 1; }
  cp -f "$EXPBEST" $ROOT/runs/theta_${name}_best.txt
  say "POOL $name: n=$EN best=$ESCORE mean=$EMEAN"
  return 0
}
do_consol(){ local model=$1 name=$2 expfile=$3
  local ckpt=$ROOT/ckpts/$2/best/COMMIT.json try rc
  for try in 1 2 3; do
    [ -e "$ckpt" ] && { say "SKIP consol $name"; return 0; }
    wait_free 2 3; wait_disk 18
    say "CONSOL $name start try=$try (GPU2/3)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2,3 \
      bash scripts/textgame_consolidate.sh --model "$model" \
        --exp_name $name --nnodes 1 \
        --kl_loss_type full --kl_topk 256 --actor_lr 5e-6 \
        --max_response_length 1024 --experience_max_length 8192 \
        --textgame_name Sokoban-v0 --textgame_max_steps 5 --textgame_no_think True \
        --exp_path "$expfile" $EXTRA \
        > $LOGD/theta_consol_${name}.log 2>&1)
    rc=$?
    say "CONSOL $name rc=$rc try=$try"
    if [ -e "$ckpt" ]; then
      if [ $rc -eq 0 ] || grep -q "step:50" $LOGD/theta_consol_${name}.log 2>/dev/null; then return 0; fi
      say "PARTIAL consol $name → 清产物重试"
      rm -rf $ROOT/ckpts/$name
    fi
    cleanup_own "$name"; sleep 60
  done
  say "FATAL consol $name 3 连败"; return 1
}
do_merge_eval(){ local name=$1
  local D=$ROOT/ckpts/$1/best/actor try rc
  if ! ls $D/huggingface/*.safetensors >/dev/null 2>&1; then
    mkdir -p $D/huggingface
    find $D -maxdepth 1 -type f ! -name "*.pt" -exec cp {} $D/huggingface/ \;
    (cd $ROOT/opcd && $PY tools/merge_model2hf.py --local_dir "$D" >> $LOGD/theta_merge_${name}.log 2>&1) \
      || { say "FATAL merge $name"; return 1; }
    say "MERGED $name"
  fi
  STEP=$(grep -oP '(?<="global_step": )[0-9]+' $ROOT/ckpts/$name/best/COMMIT.json|head -1)
  local eprod=$ROOT/ckpts/${name}-eval/global_step_${STEP}/evaluation/scores.json
  for try in 1 2 3; do
    [ -e "$eprod" ] && break
    wait_free 2 3
    say "EVAL $name start try=$try (GPU2/3 step=$STEP)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2,3 \
      bash scripts/textgame_eval.sh --model "$D/huggingface" --exp_name ${name}-eval --nnodes 1 --use_bsl true \
      --max_response_length 1024 \
      --textgame_name Sokoban-v0 --textgame_max_steps 5 --textgame_no_think True \
      --ckpt ${STEP} trainer.n_gpus_per_node=2 \
      > $LOGD/theta_eval_${name}.log 2>&1)
    rc=$?; say "EVAL $name rc=$rc try=$try"
    [ -e "$eprod" ] && break
    cleanup_own "${name}-eval"; sleep 60
  done
  [ -e "$eprod" ] || { say "FATAL eval $name"; return 1; }
  read -r EVALMEAN EVALN <<< "$(mean_score $eprod)"
  say "RESULT $name: eval=$EVALMEAN(n=$EVALN)"
  prune_shards $name
  return 0
}

say "==== Θ-E2b start (pid $$): SK@4B 平台攻击(20 候选+池门 r6-r7),等 e2a-guard 退出+发车令 ===="
wait_pred
say "e2a-guard 已退出。等发车令 runs/e2b_go(用户拍板后 touch;不 touch 则永等,无副作用)"
wait_go
say "发车令收到。等 L40 推送 r5 父本(runs/e2b_r5_ready;L40 守护 5min 探测+推送 8.3G)"
wait_r5
say "r5 父本就位。CUR_EVAL=0.531(r5 点估计,报告 §1.3);预注册:≥0.56=提取饱和 / ≈0.53=域天花板"
wait_disk 18
CUR=$R5; CUR_EVAL=0.531
for n in 6 7; do
  say "---- E2b 轮 r$n(${NSAMP} 候选,池门阈=0.6×$CUR_EVAL)----"
  do_extract "$CUR" theta-sk-r${n}ext-w20 99$n || exit 1
  ESC1=$ESCORE; EXP1=$EXPBEST
  if [ $(awk -v b="$ESC1" -v c="$CUR_EVAL" 'BEGIN{print (b<0.6*c)?1:0}') -eq 1 ]; then
    say "POOLGATE_LOW r$n best=$ESC1 < 0.6×$CUR_EVAL → 重提一次"
    do_extract "$CUR" theta-sk-r${n}ext-w20rt 99$n || exit 1
    if [ $(awk -v a="$ESCORE" -v b="$ESC1" 'BEGIN{print (a>b)?1:0}') -eq 1 ]; then
      say "POOLGATE_RESCUED r$n rt=$ESCORE > orig=$ESC1 → 用重提池"
    else
      say "POOLGATE_STILLLOW r$n rt=$ESCORE ≤ orig=$ESC1 → 接受较优并标记"
      EXPBEST=$EXP1; ESCORE=$ESC1
    fi
  else
    say "POOLGATE_OK r$n best=$ESC1 ≥ 0.6×$CUR_EVAL"
  fi
  do_consol "$CUR" theta-sk-refresh-r$n "$EXPBEST" || exit 1
  do_merge_eval theta-sk-refresh-r$n || exit 1
  CUR=$ROOT/ckpts/theta-sk-refresh-r$n/best/actor/huggingface
  CUR_EVAL=$EVALMEAN
done
say "==== Θ-E2b ALL_DONE:判据对照(预注册 2026-10-04)===="
say "r6/r7 任一 ≥0.56 → PLATEAU_BROKEN(提取饱和,C3 加强);均 ≈0.53(±0.023) → CEILING(域天花板)"
grep -E "RESULT|POOL" "$ST" | tail -8
