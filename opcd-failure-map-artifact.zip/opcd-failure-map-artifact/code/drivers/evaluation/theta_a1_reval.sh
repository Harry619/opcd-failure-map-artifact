#!/bin/bash
# Θ-A1 重评守护:逐环境明细 + k 采样三规则(2026-10-06)
# 预注册: 04_笔记/theta_prereg_tier12_20261006.md §三/§四
# 协议: 单卡动态找空卡; 作业文件 runs/a1_reval_todo.txt, 每行: name|env|no_think|seeds(空格分隔)
# 产物: ckpts/<name>-a1s<S>/global_step_<S>/evaluation/{scores,per_env_scores,per_env_rewards_raw}.json
# 幂等: 产物存在即 SKIP; FAIL×2 记 FATAL_JOB 跳过; 本地无 HF 记 MISSING 跳过(拉回后自动补)
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_a1_reval_status.log
TODO=${TODO_FILE:-$ROOT/runs/a1_reval_todo.txt}
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 RAY_memory_monitor_refresh_ms=1000
export HF_HOME=$ROOT/hf_cache
PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH
say(){ echo "[$(date '+%F %T')] $1" >> "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
pick_gpu(){ local g
  for g in $( [ -f $ROOT/runs/gpu01_lent ] && echo "2 3" || echo "1 0 2 3" ); do is_free $g && { echo $g; return 0; }; done
  return 1
}
failn(){ echo $(cat $ROOT/runs/a1_fail_$1_$2 2>/dev/null || echo 0); }
run_one(){ local n=$1 env=$2 nt=$3 S=$4 g rc prod scores big extra
  local hf=$ROOT/ckpts/$n/best/actor/huggingface
  prod=$ROOT/ckpts/${n}-a1s${S}/global_step_${S}/evaluation/per_env_scores.json
  scores=$ROOT/ckpts/${n}-a1s${S}/global_step_${S}/evaluation/scores.json
  [ -e "$prod" ] && return 0
  [ "$(failn $n $S)" -ge 2 ] && { say "FATAL_JOB $n s$S (fail×2)"; return 0; }
  [ -f "$hf/config.json" ] || { say "MISSING $n (无 HF, 拉回后自动补)"; return 0; }
  # 2026-10-06 20:40 修复:4B 模型单卡评测 util 0.8 放不下 KV cache(vllm: No available memory
  # for the cache blocks),按名字分档 4B(SK 系除 1b7 外全是 4B)追加 util 0.90
  big=0
  case "$n" in
    *1b7*) big=0;;
    *4b*|*sk*) big=1;;
  esac
  extra=""
  [ $big -eq 1 ] && extra="actor_rollout_ref.rollout.gpu_memory_utilization=0.90"
  g=$(pick_gpu) || { say "NO_FREE_GPU $n s$S (等待)"; return 1; }
  say "START $n seed=$S gpu=$g$( [ $big -eq 1 ] && echo " [4B util0.90]" )"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=$g \
    bash scripts/textgame_eval.sh --model "$hf" --exp_name ${n}-a1s${S} --nnodes 1 --use_bsl true \
    --max_response_length 1024 --textgame_name $env --textgame_max_steps 5 --textgame_no_think $nt \
    --ckpt ${S} trainer.n_gpus_per_node=1 $extra \
    > $LOGD/theta_a1_${n}_s${S}.log 2>&1)
  rc=$?
  if [ -e "$prod" ]; then
    say "OK $n seed=$S rc=$rc"; rm -f $ROOT/runs/a1_fail_$n_$S
  elif [ -e "$scores" ]; then
    say "OK_NOPERENV $n seed=$S (scores 有而 per_env 无 → patch 未生效?)"
    echo $(($(failn $n $S)+1)) > $ROOT/runs/a1_fail_$n_$S
  else
    say "FAIL $n seed=$S rc=$rc"
    echo $(($(failn $n $S)+1)) > $ROOT/runs/a1_fail_$n_$S
  fi
  sleep 20
}
count_pending(){ local pend=0 n env nt S
  while IFS='|' read -r n env nt seeds; do
    [ -z "$n" ] && continue; case "$n" in \#*) continue;; esac
    for S in $seeds; do
      [ -e "$ROOT/ckpts/${n}-a1s${S}/global_step_${S}/evaluation/per_env_scores.json" ] || pend=$((pend+1))
    done
  done < "$TODO"
  echo $pend
}
pick_gpu(){ local g partner chain_alive
  # 链感知让位(2026-10-06 用户令:GPU2 常驻保活但不再饿死主链;04:30 事故补丁)
  for g in $( [ -f $ROOT/runs/gpu01_lent ] && echo "2 3" || echo "1 0 2 3" ); do
    is_free $g || continue
    case $g in 0) partner=1;; 1) partner=0;; 2) partner=3;; 3) partner=2;; esac
    case $g in
      0|1) pgrep -u user-b -f "theta_e2a_adaptiv[e]_|theta_b1_dos[e]" >/dev/null 2>&1 && chain_alive=1 || chain_alive=0 ;;
      2|3) pgrep -u user-b -f "theta_e2a_guar[d]|theta_e2b[_.]|theta_b2_l[r]" >/dev/null 2>&1 && chain_alive=1 || chain_alive=0 ;;
    esac
    if [ "$chain_alive" -eq 1 ]; then continue; fi
    # 2026-10-06 20:40 加严:链活即让位(原"链活且配对卡空才让"在链等待窗口仍会抢卡,
    # 20:24/04:30 两次饿死主链;A1 定位=无链期碎片窗口消化者,牺牲吞吐换主链确定性)
    echo $g; return 0
  done
  return 1
}
say "==== Θ-A1 重评守护 start (pid $$) ===="
[ -f "$TODO" ] || { say "FATAL 无作业文件 $TODO"; exit 1; }
PREV=-1
while :; do
  PEND=$(count_pending)
  if [ "$PEND" -eq 0 ]; then say "==== A1 ALL_DONE ($(date '+%F %T')) ===="; break; fi
  say "PASS start pending=$PEND"
  while IFS='|' read -r n env nt seeds; do
    [ -z "$n" ] && continue; case "$n" in \#*) continue;; esac
    for S in $seeds; do run_one "$n" "$env" "$nt" "$S"; done
  done < "$TODO"
  PEND2=$(count_pending)
  say "PASS end pending=$PEND2"
  [ "$PEND2" -eq 0 ] && { say "==== A1 ALL_DONE ($(date '+%F %T')) ===="; break; }
  if [ "$PEND2" -eq "$PEND" ]; then say "无进展(等卡/等拉回), sleep 600"; sleep 600; fi
done
