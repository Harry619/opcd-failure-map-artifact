#!/bin/bash
# Θ GPU2 复评批(H20,2026-10-11):B2 三轮 + B3-H20 s4 的多种子补齐,全单卡 GPU2
# B2 已有 s44/s45(16:28 批);本批补 s46/s47 使三轮达 5 种子口径;B3-H20 s4 补 3 种子
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 HF_HOME=$HOME/OPCD-improve/hf_cache
export TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_gpu2_reval_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free2(){ local mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 2); [ "$mem" -lt 95000 ] && return 0; return 1; }
cleanup(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 3; true; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
run(){ local n=$1 env=$2 nt=$3 S=$4 try rc ep
  ep=$ROOT/ckpts/${n}-g2r${S}/global_step_${S}/evaluation/scores.json
  [ -e "$ep" ] && return 0
  for try in 1 2 3; do
    while ! is_free2; do sleep 120; done
    say "START $n s$S gpu2 try=$try"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 \
      bash scripts/textgame_eval.sh --model "$ROOT/ckpts/$n/best/actor/huggingface" \
      --exp_name ${n}-g2r${S} --nnodes 1 --use_bsl true --max_response_length 1024 \
      --textgame_name $env --textgame_max_steps 5 --textgame_no_think $nt \
      --ckpt ${S} trainer.n_gpus_per_node=1 actor_rollout_ref.rollout.gpu_memory_utilization=0.55 \
      > $LOGD/theta_g2r_${n}_s${S}.log 2>&1)
    rc=$?
    if [ -e "$ep" ]; then read -r EV <<< "$(mean $ep)"; say "RESULT $n s$S: $EV rc=$rc"; return 0; fi
    say "FAIL $n s$S rc=$rc"; cleanup "${n}-g2r${S}"; sleep 30
  done
  say "FATAL $n s$S"
}
say "==== GPU2 复评批 start (pid $$) ===="
for S in 46 47; do
  run theta-b2-lr25-s2l FrozenLake-v0-raw False "$S"
  run theta-b2-lr25-s3l FrozenLake-v0-raw False "$S"
  run theta-b2-lr25-s4l FrozenLake-v0-raw False "$S"
done
for S in 43 44 45; do run theta-sk1b7-static-s4 Sokoban-v0 True "$S"; done
say "==== GPU2 复评批 ALL_DONE ===="
grep RESULT "$ST" | tail -9
