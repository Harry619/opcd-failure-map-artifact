#!/bin/bash
# Θ k=5 加深批(H20 GPU1,2026-10-15):C 臂全链 s46(postC 只评了44/45)+E 臂 s45/s46
# GPU1 单卡零竞态;幂等(产物在跳过)
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local RAY_DISABLE_DASHBOARD=1 PYTHONUNBUFFERED=1 HF_HOME=$HOME/OPCD-improve/hf_cache
export TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_k5reval_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free1(){ local mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 1); [ "$mem" -lt 120000 ] && return 0; return 1; }
cleanup(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 3; true; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
run(){ local mname=$1 S=$2 try rc ep M
  M=$ROOT/ckpts/$mname/best/actor/huggingface
  [ -e "$M/model.safetensors" ] || { say "SKIP $mname(无 HF)"; return 0; }
  ep=$ROOT/ckpts/${mname}-pv${S}/global_step_${S}/evaluation/scores.json
  [ -e "$ep" ] && return 0
  for try in 1 2 3; do
    while ! is_free1; do sleep 120; done
    say "K3_START $mname s$S gpu1 try=$try"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=1 \
      bash scripts/textgame_eval.sh --model "$M" \
      --exp_name ${mname}-pv${S} --nnodes 1 --use_bsl true --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      --ckpt ${S} trainer.n_gpus_per_node=1 \
      actor_rollout_ref.rollout.gpu_memory_utilization=0.5 \
      actor_rollout_ref.rollout.max_num_batched_tokens=8192 \
      >> $LOGD/theta_k3_${mname}_s${S}.log 2>&1)
    rc=$?
    if [ -e "$ep" ]; then read -r EV <<< "$(mean $ep)"; say "K3_RESULT $mname s$S: $EV rc=$rc"; return 0; fi
    say "K3_FAIL $mname s$S rc=$rc"; cleanup "${mname}-pv${S}"; sleep 30
  done
  say "K3_FATAL $mname s$S"
}
say "==== k=5 加深批 start (pid $$, GPU1) ===="
# C 臂 s46
for n in r2 r3rt; do run e2a-combo-$n 47; run e2a-combo-$n 48; done
# E 臂 s45/s46
for n in r1rt r2; do run e2a-blind-$n 47; run e2a-blind-$n 48; done
say "==== k=5 加深批 ALL_DONE ===="
