#!/bin/bash
# Θ M₁ 锚点 k=4 复评(H20 GPU1,2026-10-11):fl-q3-1b7-consol2 种子 43-46,跨机锚点加固
# 预注册: theta_e2_design.md §七;util 0.35 挤占档与 AuroOFT 共存(~50G)
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 HF_HOME=$HOME/OPCD-improve/hf_cache
export TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_m1_reval_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free1(){ local mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 1); [ "$mem" -lt 115000 ] && return 0; return 1; }
cleanup(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 3; true; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
M=$ROOT/ckpts/fl-q3-1b7-consol2/best/actor/huggingface
[ -e "$M/config.json" ] || { say "NO_MODEL $M — abort"; exit 1; }
run(){ local S=$1 try rc ep
  ep=$ROOT/ckpts/fl-q3-1b7-consol2-g1r${S}/global_step_${S}/evaluation/scores.json
  [ -e "$ep" ] && return 0
  for try in 1 2 3; do
    while ! is_free1; do sleep 120; done
    say "START M1 s$S gpu1 try=$try"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=1 \
      bash scripts/textgame_eval.sh --model "$M" \
      --exp_name fl-q3-1b7-consol2-g1r${S} --nnodes 1 --use_bsl true --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      --ckpt ${S} trainer.n_gpus_per_node=1 actor_rollout_ref.rollout.gpu_memory_utilization=0.35 \
      > $LOGD/theta_g1r_m1_s${S}.log 2>&1)
    rc=$?
    if [ -e "$ep" ]; then read -r EV <<< "$(mean $ep)"; say "RESULT M1 s$S: $EV rc=$rc"; return 0; fi
    say "FAIL M1 s$S rc=$rc"; cleanup "fl-q3-1b7-consol2-g1r${S}"; sleep 30
  done
  say "FATAL M1 s$S"
}
say "==== M₁ k=4 复评批 start (pid $$) ===="
for S in 43 44 45 46; do run "$S"; done
say "==== M₁ k=4 复评批 ALL_DONE ===="
