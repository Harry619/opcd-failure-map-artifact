#!/bin/bash
# Θ math-8B M₁ 复评(H20 GPU2,2026-10-12):math-q3-8b-consol-user-b 终评锚 0.792 加固(种子 43/44)
# 排队等 r5rt 重试批退出后接卡;util 0.5 挤占版(与 C/D 共存:10+50+72=132G<143G)
# 口径=B6-CHECK-3:dapo_test 1000 题与 M₁ 终评 0.792 一致
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 HF_HOME=$HOME/OPCD-improve/hf_cache
export TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_m8_reval_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free2(){ local mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 2); [ "$mem" -lt 130000 ] && return 0; return 1; }
cleanup(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 3; true; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
M=$ROOT/ckpts/math-q3-8b-consol-user-b/best/actor/huggingface
[ -e "$M/config.json" ] || { say "NO_MODEL $M — abort"; exit 1; }
# 等 r5rt 重试批让路;超时 5h 兜底
DL=$(( $(date +%s) + 18000 ))
while ! grep -q "ALL_DONE" $ROOT/logs/theta_r5rt2_status.log 2>/dev/null; do
  [ $(date +%s) -gt $DL ] && { say "r5rt2 等待超时,直接开跑"; break; }
  sleep 180
done
run(){ local S=$1 try rc ep
  ep=$ROOT/ckpts/math-q3-8b-consol-user-b-mr${S}/global_step_${S}/evaluation/scores.json
  [ -e "$ep" ] && return 0
  for try in 1 2 3; do
    while ! is_free2; do sleep 120; done
    say "START math-M1 s$S gpu2 try=$try"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 \
      bash scripts/math_eval.sh --model "$M" \
      --exp_name math-q3-8b-consol-user-b-mr${S} --nnodes 1 \
      --ckpt ${S} trainer.n_gpus_per_node=1 \
      actor_rollout_ref.rollout.gpu_memory_utilization=0.5 \
      > $LOGD/theta_mr_math_s${S}.log 2>&1)
    rc=$?
    if [ -e "$ep" ]; then read -r EV <<< "$(mean $ep)"; say "RESULT math-M1 s$S: $EV rc=$rc"; return 0; fi
    say "FAIL math-M1 s$S rc=$rc"; cleanup "math-q3-8b-consol-user-b-mr${S}"; sleep 30
  done
  say "FATAL math-M1 s$S"
}
say "==== math-8B M₁ 复评批 start (pid $$, GPU2 util 0.5, 等 r5rt2 让路) ===="
for S in 43 44; do run "$S"; done
say "==== math-8B M₁ 复评批 ALL_DONE ===="
