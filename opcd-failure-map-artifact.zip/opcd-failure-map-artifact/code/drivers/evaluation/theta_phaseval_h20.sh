#!/bin/bash
# Θ 链伴评测守护(H20,2026-10-12):E2a-C 链每轮 RESULT 自动加评种子 44/45(全链 k=3)
# 相位感知:C 固化 generate(70G)/update(7-25G) 交替——eval 等 GPU2<40G(update 相隙)启动,
# 池=util0.5×143−25≈46G >> kv 需求;C 回 generate 后 70+55=125G<143G 物理活
# 配方=M1v2 实证:util 0.5+batched 8192;幂等(产物在跳过)
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 HF_HOME=$HOME/OPCD-improve/hf_cache
export TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_phaseval_status.log
CS=$ROOT/logs/theta_e2aC_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
cleanup(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 3; true; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
g2(){ nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 2; }

run_one(){ local model=$1 mname=$2 S=$3 try rc ep
  ep=$ROOT/ckpts/${mname}-pv${S}/global_step_${S}/evaluation/scores.json
  [ -e "$ep" ] && return 0
  for try in 1 2 3; do
    # 相位感知:等 GPU2 进 update 相隙(<40G)
    local waited=0
    while [ "$(g2)" -ge 40000 ]; do
      sleep 45; waited=$((waited+1)); [ $waited -gt 240 ] && break
    done
    say "PV_START $mname s$S gpu2 try=$try (gpu2=$(g2)MiB)"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 \
      bash scripts/textgame_eval.sh --model "$model" \
      --exp_name ${mname}-pv${S} --nnodes 1 --use_bsl true --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      --ckpt ${S} trainer.n_gpus_per_node=1 \
      actor_rollout_ref.rollout.gpu_memory_utilization=0.5 \
      actor_rollout_ref.rollout.max_num_batched_tokens=8192 \
      > $LOGD/theta_pv_${mname}_s${S}.log 2>&1)
    rc=$?
    if [ -e "$ep" ]; then read -r EV <<< "$(mean $ep)"; say "PV_RESULT $mname s$S: $EV rc=$rc"; return 0; fi
    say "PV_FAIL $mname s$S rc=$rc(可能撞 C generate 相位)"; cleanup "${mname}-pv${S}"; sleep 60
  done
  say "PV_FATAL $mname s$S"
}

say "==== 链伴评测守护 start (pid $$) ===="
SEEN=""
while :; do
  # C 链活着才跟随;C 收官后把尾巴评完再退
  CALIVE=$(pgrep -cf 'e2aC_combo_h20.s[h]')
  # 解析新 RESULT 行
  while IFS= read -r line; do
    name=$(echo "$line" | grep -oP 'RESULT \K[a-z0-9-]+(?=:)' | head -1)
    [ -z "$name" ] && continue
    case "$SEEN" in *"|$name|"*) continue;; esac
    SEEN="$SEEN|$name|"
    M=$ROOT/ckpts/$name/best/actor/huggingface
    [ -e "$M/model.safetensors" ] || continue
    say "PV_NEW $name → 加评 s44/s45"
    run_one "$M" "$name" 44
    run_one "$M" "$name" 45
  done < <(grep -E '^\[.*RESULT e2a-combo' "$CS" 2>/dev/null)
  [ "$CALIVE" -eq 0 ] && [ -n "$SEEN" ] && { say "C 链已收官且加评完成,退出"; break; }
  sleep 180
done
say "==== 链伴评测守护 ALL_DONE ===="
