#!/bin/bash
# Θ C 链收官后统一补评(H20 GPU2 独占,2026-10-12):e2a-combo 全部轮次 k=3 加评(种子 44/45)
# 教训:链运行期的相隙评测会撞 wake 相位(phaseval 挤死 r1rt try=1)——改为链退出后独占跑
# 顺序保证:autosched 互斥模式已含本脚本名,G9/G8 在本批完成后才发车
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 HF_HOME=$HOME/OPCD-improve/hf_cache
export TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_postC_reval_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free2(){ local mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 2); [ "$mem" -lt 95000 ] && return 0; return 1; }
cleanup(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 3; true; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
# 等 C 链退出(最长 30h 兜底)
DL=$(( $(date +%s) + 108000 ))
while pgrep -f "theta_e2aC_combo_h20.s[h]" >/dev/null 2>&1; do
  [ $(date +%s) -gt $DL ] && { say "C 等待超时 30h,强制开跑"; break; }
  sleep 300
done
say "C 链已退出,独占 GPU2 开始统一补评"
run(){ local model=$1 mname=$2 S=$3 try rc ep
  ep=$ROOT/ckpts/${mname}-pv${S}/global_step_${S}/evaluation/scores.json
  [ -e "$ep" ] && return 0
  for try in 1 2 3; do
    while ! is_free2; do sleep 120; done
    say "POSTC_START $mname s$S try=$try"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 \
      bash scripts/textgame_eval.sh --model "$model" \
      --exp_name ${mname}-pv${S} --nnodes 1 --use_bsl true --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      --ckpt ${S} trainer.n_gpus_per_node=1 \
      actor_rollout_ref.rollout.gpu_memory_utilization=0.55 \
      actor_rollout_ref.rollout.max_num_batched_tokens=8192 \
      > $LOGD/theta_postc_${mname}_s${S}.log 2>&1)
    rc=$?
    if [ -e "$ep" ]; then read -r EV <<< "$(mean $ep)"; say "POSTC_RESULT $mname s$S: $EV rc=$rc"; return 0; fi
    say "POSTC_FAIL $mname s$S rc=$rc"; cleanup "${mname}-pv${S}"; sleep 30
  done
  say "POSTC_FATAL $mname s$S"
}
say "==== postC 统一补评批 start (pid $$) ===="
for d in $ROOT/ckpts/e2a-combo-r*; do
  name=$(basename $d)
  M=$d/best/actor/huggingface
  [ -e "$M/model.safetensors" ] || continue
  say "POSTC_NEW $name"
  run_one(){ :; }
  run "$M" "$name" 44
  run "$M" "$name" 45
done
say "==== postC 统一补评批 ALL_DONE ===="
