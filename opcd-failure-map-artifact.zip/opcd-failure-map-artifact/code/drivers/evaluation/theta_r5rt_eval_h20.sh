#!/bin/bash
# Θ r5rt 补评测(H20 GPU2,2026-10-11):E2a-B 链唯一缺评测的实验点
# r5rt = e2a-guard r5 回滚重试固化(10-09 中断时 best 已落盘但从未评测)
# 协议:FL@1.7B,FrozenLake-v0-raw,no_think False,种子 43-46,单卡 GPU2 挤占档 util 0.55
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 HF_HOME=$HOME/OPCD-improve/hf_cache
export TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_r5rt_eval_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free0(){ local mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 0); [ "$mem" -lt 95000 ] && return 0; return 1; }
cleanup(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 3; true; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }

M=$ROOT/ckpts/e2a-guard-r5rt/best/actor/huggingface
# 前置:模型必须就位
if [ ! -e "$M/config.json" ]; then say "NO_MODEL $M — abort"; exit 1; fi

run(){ local S=$1 try rc ep
  ep=$ROOT/ckpts/e2a-guard-r5rt-g2r${S}/global_step_${S}/evaluation/scores.json
  [ -e "$ep" ] && return 0
  for try in 1 2 3; do
    while ! is_free0; do sleep 120; done
    say "START e2a-guard-r5rt s$S gpu2 try=$try"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0 \
      bash scripts/textgame_eval.sh --model "$M" \
      --exp_name e2a-guard-r5rt-g2r${S} --nnodes 1 --use_bsl true --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      --ckpt ${S} trainer.n_gpus_per_node=1 actor_rollout_ref.rollout.gpu_memory_utilization=0.45 \
      > $LOGD/theta_g2r_e2a-guard-r5rt_s${S}.log 2>&1)
    rc=$?
    if [ -e "$ep" ]; then read -r EV <<< "$(mean $ep)"; say "RESULT e2a-guard-r5rt s$S: $EV rc=$rc"; return 0; fi
    say "FAIL e2a-guard-r5rt s$S rc=$rc"; cleanup "e2a-guard-r5rt-g2r${S}"; sleep 30
  done
  say "FATAL e2a-guard-r5rt s$S"
}
say "==== r5rt 补评测批 start (pid $$) ===="
for S in 43 44 45 46; do run "$S"; done
say "==== r5rt 补评测批 ALL_DONE ===="
