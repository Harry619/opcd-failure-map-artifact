#!/bin/bash
# Θ r5rt 评测重试批(H20 GPU2,2026-10-12 02:30):首批四种子全 FATAL(kv cache:util 0.45 时
# profile 峰值吃掉预算),修复=util 0.55+显式 max_num_batched_tokens=8192 降 profile 峰值
# GPU2 与 E2a-C 双卡固化并行(C 仅占 ~10G,123G 空闲);预注册: theta_prereg §六(r5rt 判读分支)
export NCCL_P2P_DISABLE=1 MALLOC_ARENA_MAX=2 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export RAY_ADDRESS=local PYTHONUNBUFFERED=1 HF_HOME=$HOME/OPCD-improve/hf_cache
export TMPDIR=$HOME/OPCD-improve/tmp RAY_TMPDIR=$HOME/OPCD-improve/ray_tmp
export WANDB_MODE=disabled WANDB_DISABLED=true
export PATH=$HOME/OPCD-improve/envs/opcd/bin:$PATH
ROOT=$HOME/OPCD-improve; LOGD=$ROOT/logs; ST=$LOGD/theta_r5rt2_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free2(){ local mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 2); [ "$mem" -lt 120000 ] && return 0; return 1; }
cleanup(){ pkill -9 -f "verl.trainer.main_pp[o].*$1" 2>/dev/null; sleep 3; true; }
mean(){ $ROOT/envs/opcd/bin/python -c "
import json,sys
s=json.load(open(sys.argv[1]))
def sc(v):
    try: return float(v)
    except: return 0.0
vals=[sc(v) for v in (s.values() if isinstance(s,dict) else s)]
print(f'{sum(vals)/max(len(vals),1):.6f}')" "$1"; }
M=$ROOT/ckpts/e2a-guard-r5rt/best/actor/huggingface
[ -e "$M/config.json" ] || { say "NO_MODEL $M — abort"; exit 1; }
run(){ local S=$1 try rc ep
  ep=$ROOT/ckpts/e2a-guard-r5rt-g2r${S}/global_step_${S}/evaluation/scores.json
  [ -e "$ep" ] && return 0
  for try in 1 2 3; do
    while ! is_free2; do sleep 120; done
    say "START r5rt s$S gpu2 try=$try"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 \
      bash scripts/textgame_eval.sh --model "$M" \
      --exp_name e2a-guard-r5rt-g2r${S} --nnodes 1 --use_bsl true --max_response_length 1024 \
      --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      --ckpt ${S} trainer.n_gpus_per_node=1 \
      actor_rollout_ref.rollout.gpu_memory_utilization=0.55 \
      actor_rollout_ref.rollout.max_num_batched_tokens=8192 \
      > $LOGD/theta_g2r2_r5rt_s${S}.log 2>&1)
    rc=$?
    if [ -e "$ep" ]; then read -r EV <<< "$(mean $ep)"; say "RESULT r5rt s$S: $EV rc=$rc"; return 0; fi
    say "FAIL r5rt s$S rc=$rc"; cleanup "e2a-guard-r5rt-g2r${S}"; sleep 30
  done
  say "FATAL r5rt s$S"
}
say "==== r5rt 重试批 start (pid $$, GPU2 修复配方) ===="
for S in 43 44 45 46; do run "$S"; done
say "==== r5rt 重试批 ALL_DONE ===="
