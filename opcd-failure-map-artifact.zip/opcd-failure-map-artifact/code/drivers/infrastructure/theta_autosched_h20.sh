#!/bin/bash
# Θ 自动调度守护(H20,2026-10-12):轮询四卡空闲显存,够大即按队列自动发车排队实验
# 用户指令固化:"巡检中加入检测剩余空闲显存,够大就找匹配显存需求的实验并行跑"
# 规则:①队列有序(G9lo→G9hi→G8)②新链(G系/E)同时最多 1 条与 C 并存(C 续轮 init 需 ≥20G 池)
# ③D 在跑时不发(D+C+新链三流会把 C 的续轮 init 挤死)④防抖:连续 2 次检查(隔 90s)显存够才发
export PATH=/usr/bin:/bin:$PATH
ROOT=$HOME/OPCD-improve; LOG=$ROOT/logs/theta_autosched.log
say(){ echo "[$(date '+%F %T')] $1" >> "$LOG"; }
G(){ nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1; }
# 队列: 名字|脚本|GPU列表(逗号)|每卡需求MiB
QUEUE="
G9lo|theta_e2aG9lo_h20.sh|2,3|65000
G9hi|theta_e2aG9hi_h20.sh|2,3|65000
"
say "==== autosched start (pid $$) ===="
while :; do
  # D 在跑 → 不发(保护 C 续轮)
  pgrep -f "theta_e2aD_entropy_h20.s[h]" >/dev/null 2>&1 && { sleep 300; continue; }
  # 已有新链(E/G9/G8)在跑或等待 → 不发第二条
  if pgrep -f "e2aE_blind_h20.s[h]|e2aG9lo_h20.s[h]|e2aG9hi_h20.s[h]|e2aC_combo_h20.s[h]|postC_reval_h20.s[h]" >/dev/null 2>&1; then
    sleep 300; continue
  fi
  while IFS='|' read -r name script gpus need; do
    [ -z "$name" ] && continue
    [ -e "$ROOT/.autosched_${name}_done" ] && continue
    # 检查 1
    ok=1
    for g in ${gpus//,/ }; do [ "$(G $g)" -gt $((143000 - need)) ] && ok=0; done
    [ $ok -eq 0 ] && continue
    sleep 90
    # 检查 2(防抖)
    ok=1
    for g in ${gpus//,/ }; do [ "$(G $g)" -gt $((143000 - need)) ] && ok=0; done
    [ $ok -eq 0 ] && continue
    say "DISPATCH $name → $script (GPU$gpus 需${need}MiB/卡)"
    nohup bash $ROOT/scripts/$script > $ROOT/logs/theta_${name}_console.log 2>&1 &
    sleep 10
    break  # 一次只发一条,下轮再判
  done <<< "$QUEUE"
  sleep 300
done
