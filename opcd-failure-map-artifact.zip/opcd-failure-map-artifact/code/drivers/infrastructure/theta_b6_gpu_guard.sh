#!/bin/bash
# Θ B6 护卡守望(2026-10-19,用户指令"影响 B6 就关掉新开的实验"):B6 训练存续期间,
# 每 90s 扫 0/1 卡 compute-apps;非 B6 进程树的外来 pid 驻留(连续 2 次确认)→ 记录并 kill
# B6 训练进程消失后自动退出(终局交给 final watcher)
ST=~/OPCD-improve/logs/theta_b6_gpuguard.log
say(){ echo "[$(date '+%F %T')] $1" >> $ST; }
say "==== B6 护卡守望 start (pid $$) ===="
while :; do
  pgrep -f "experiment_name=theta-math8b-refresh-r2-v6" >/dev/null 2>&1 || { say "B6 训练进程已退出,守望结束"; exit 0; }
  for g in 0 1; do
    pids=$(nvidia-smi -i $g --query-compute-apps=pid --format=csv,noheader 2>/dev/null | tr -d " " | grep -v "^$")
    for p in $pids; do
      [ "$p" = "2177238" ] || [ "$p" = "2177401" ] && continue
      # 非 B6 worker:查 cmdline 是否 B6 相关(ray 主/worker 均含 verl 或 experiment_name)
      cmd=$(tr "\0" " " < /proc/$p/cmdline 2>/dev/null)
      echo "$cmd" | grep -qE "verl|main_ppo|ray::|theta-math8b" && continue
      say "外来进程 gpu$g pid=$p: $(echo $cmd | cut -c1-80) → 第二次确认后清退"
      echo "$p" >> /tmp/.b6_gpuguard_seen
    done
  done
  # 二次确认机制:上一轮记录且本轮仍在的 pid 才 kill
  if [ -f /tmp/.b6_gpuguard_seen ]; then
    for p in $(cat /tmp/.b6_gpuguard_seen | sort -u); do
      if [ -d /proc/$p ]; then
        cmd=$(tr "\0" " " < /proc/$p/cmdline 2>/dev/null)
        echo "$cmd" | grep -qE "verl|main_ppo|ray::|theta-math8b" && continue
        kill $p 2>/dev/null && say "已清退外来 pid=$p (B6 保护)"
      fi
    done
    rm -f /tmp/.b6_gpuguard_seen
  fi
  sleep 90
done
