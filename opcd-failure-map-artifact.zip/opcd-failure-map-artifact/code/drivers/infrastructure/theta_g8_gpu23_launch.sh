#!/bin/bash
# Θ G8 挪 GPU2/3 发车器(H20,2026-10-16):等 GPU2/3 空闲(G9hi 收官后,连续 3×5min 双卡<10G)
# → G8 改绑 GPU2/3 → 重挂 guard;GPU0 被对方重负载(117G)占,G8 双卡在 0/1 池负死循环,故挪
export PATH=/usr/bin:/bin:$PATH
ROOT=$HOME/OPCD-improve; LOG=$ROOT/logs/theta_g8_launch23.log
say(){ echo "[$(date '+%F %T')] $1" >> "$LOG"; }
g(){ nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1; }
say "==== g8_gpu23_launch start (pid $$) ===="
CONFIRM=0
while :; do
  G2=$(g 2); G3=$(g 3)
  # G9 全系退出(防与 G9hi 撞)且双卡净空
  if [ "$G2" -lt 10000 ] && [ "$G3" -lt 10000 ] && ! pgrep -f 'e2aG9l[o]|e2aG9h[i]' >/dev/null 2>&1; then
    CONFIRM=$((CONFIRM+1)); say "GPU2/3 空窗信号 ${CONFIRM}/3 (${G2}/${G3}MiB)"
    if [ $CONFIRM -ge 3 ]; then
      say "三连确认,G8 改绑 GPU2/3 并发车"
      sed -i -e '121s/CUDA_VISIBLE_DEVICES=0,1/CUDA_VISIBLE_DEVICES=2,3/' -e '155s/CUDA_VISIBLE_DEVICES=0,1/CUDA_VISIBLE_DEVICES=2,3/' -e '80s/CUDA_VISIBLE_DEVICES=0 /CUDA_VISIBLE_DEVICES=3 /' $ROOT/scripts/theta_e2aG8_h20.sh
      bash -n $ROOT/scripts/theta_e2aG8_h20.sh && { nohup bash $ROOT/scripts/theta_while_guard.sh $ROOT/scripts/theta_e2aG8_h20.sh $ROOT/logs/theta_e2aG8_status.log > /dev/null 2>&1 & say "G8 已上 GPU2/3,launch 退出"; } || say "改绑语法错,人工介入"
      break
    fi
  else
    CONFIRM=0
  fi
  sleep 300
done
