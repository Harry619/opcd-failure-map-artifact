#!/bin/bash
# Θ G8 复活守望(H20,2026-10-16):等 GPU0 对方占用退到 <40G(连续 3×5min 确认,吸取 watcher
# 用持续总占用而非 pid 的教训)→ G8 自动复活(重挂 guard);或 B6 收官(ALL_DONE)→ G8 挪 GPU2/3 复活
export PATH=/usr/bin:/bin:$PATH
ROOT=$HOME/OPCD-improve; LOG=$ROOT/logs/theta_g8_watch.log
say(){ echo "[$(date '+%F %T')] $1" >> "$LOG"; }
g0(){ nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i 0; }
say "==== g8_window_watch start (pid $$) ===="
CONFIRM=0
while :; do
  # 条件A:GPU0 空窗(<40G 三连) → G8 上 GPU0/1
  G0=$(g0)
  if [ "$G0" -lt 40000 ]; then
    CONFIRM=$((CONFIRM+1)); say "GPU0 空窗信号 ${CONFIRM}/3 (${G0}MiB)"
    if [ $CONFIRM -ge 3 ]; then
      say "GPU0 三连确认,复活 G8(GPU0/1)"
      pkill -f 'theta_while_guard.sh .*e2aG[8]' 2>/dev/null; pkill -f 'scripts/theta_e2aG[8]' 2>/dev/null; sleep 3
      nohup bash $ROOT/scripts/theta_while_guard.sh $ROOT/scripts/theta_e2aG8_h20.sh $ROOT/logs/theta_e2aG8_status.log > /dev/null 2>&1 &
      say "G8 已复活,watch 退出"; break
    fi
  else
    CONFIRM=0
  fi
  # 条件B:B6 收官 → G8 挪 GPU2/3 复活(改卡号后重挂)
  if tail -3 $ROOT/logs/theta_b6_status.log 2>/dev/null | grep -q 'ALL_DONE'; then
    say "B6 已收官,G8 改绑 GPU2/3 复活"
    sed -i -e '121s/CUDA_VISIBLE_DEVICES=0,1/CUDA_VISIBLE_DEVICES=2,3/' -e '155s/CUDA_VISIBLE_DEVICES=0,1/CUDA_VISIBLE_DEVICES=2,3/' -e '80s/CUDA_VISIBLE_DEVICES=0/CUDA_VISIBLE_DEVICES=3/' $ROOT/scripts/theta_e2aG8_h20.sh
    bash -n $ROOT/scripts/theta_e2aG8_h20.sh && { nohup bash $ROOT/scripts/theta_while_guard.sh $ROOT/scripts/theta_e2aG8_h20.sh $ROOT/logs/theta_e2aG8_status.log > /dev/null 2>&1 & say "G8 已上 GPU2/3"; } || say "改绑语法错,人工介入"
    break
  fi
  sleep 300
done
