#!/bin/bash
# Θ 通用 while 守护器(H20,2026-10-13):断连/FATAL 自愈+收官自动退出
# 用法: theta_while_guard.sh <脚本绝对路径> <status日志绝对路径>
# 机制: 跑脚本→sleep 60→status 尾部出现 ALL_DONE 则退出,否则重拉(脚本幂等,断点续)
S=$1; ST=$2
[ -x "$S" ] || S2=$(ls "$S" 2>/dev/null) || { echo "[guard] NO_SCRIPT $S"; exit 1; }
CON=${S%.sh}_console.log
echo "[guard] start $S (watch $ST)" >> ~/OPCD-improve/logs/theta_guard.log
while :; do
  bash "$S" >> "$CON" 2>&1
  sleep 60
  if tail -5 "$ST" 2>/dev/null | grep -q 'ALL_DONE'; then
    echo "[guard] $S ALL_DONE, guard exit" >> ~/OPCD-improve/logs/theta_guard.log
    break
  fi
done
