#!/bin/bash
# Θ-P10:关键判定复评(GPU2 门控,2026-10-01):今日两个头条数字的换种子复评
# sk-static-r3 "不崩 0.367" 与 fl-refresh-r7 "新高 0.390" 各 ×2 评测种子,验证判定稳健性
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p10_status.log
PY=/home/user-b/miniconda3/envs/opcd/bin/python
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free 2 && { sleep 45; is_free 2 && return 0; }; sleep 60; done; }
score_of(){ $PY -c "import json,sys;s=json.load(open(sys.argv[1]));v=[x if isinstance(x,(int,float)) else sum(y for y in x if isinstance(y,(int,float)))/max(len(x),1) for x in (s.values() if isinstance(s,dict) else s)];print('%.6f'%(sum(v)/max(len(v),1)))" "$1" 2>/dev/null; }

ev(){ # $1=tag $2=model $3=game $4=nothink $5=seed
  local prod=$ROOT/ckpts/$1/global_step_$5/evaluation/scores.json rc
  [ -f "$prod" ] && { say "SKIP $1@$5"; return 0; }
  wait_free 2
  say "REVAL $1 seed=$5"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 NCCL_P2P_DISABLE=1 HF_HOME=$ROOT/hf_cache \
    PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH RAY_ADDRESS=local PYTHONUNBUFFERED=1 \
    bash scripts/textgame_eval.sh --model "$2" --exp_name $1 --nnodes 1 --use_bsl true \
    --max_response_length 1024 --textgame_name $3 --textgame_max_steps 5 --textgame_no_think $4 \
    --ckpt $5 trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.85 \
    +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
    +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
    > $LOGD/theta_reval_${1}_$5.log 2>&1)
  rc=$?
  [ -f "$prod" ] && { say "RESULT $1 seed=$5 score=$(score_of $prod) rc=$rc"; return 0; }
  say "REVAL $1@$5 FAIL rc=$rc"; return 0
}

SKS3=$ROOT/ckpts/theta-sk-static-r3/best/actor/huggingface
FLR7=$ROOT/ckpts/theta-fl-refresh-r7/best/actor/huggingface
say "==== Θ-P10 start (pid $$): GPU2 门控,头条判定复评 4 次 ===="
ev reval-sk-s3  $SKS3 Sokoban-v0     True  41
ev reval-sk-s3  $SKS3 Sokoban-v0     True  42
ev reval-fl-r7  $FLR7 FrozenLake-v0-raw False 41
ev reval-fl-r7  $FLR7 FrozenLake-v0-raw False 42
say "==== Θ-P10 ALL_DONE(对照原值:sk-s3=0.367, fl-r7=0.390) ===="
