#!/bin/bash
# Θ-P10b:其余头条数字换种子复评(GPU0 门控,2026-10-01)
# sk-r3 0.531 ×2 / fl-r4 0.336 ×1 / fl-s3 0.102 ×1 / sk-s2 0.352 ×1
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p10b_status.log
PY=/home/user-b/miniconda3/envs/opcd/bin/python
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free 0 && { sleep 45; is_free 0 && return 0; }; sleep 60; done; }
score_of(){ $PY -c "import json,sys;s=json.load(open(sys.argv[1]));v=[x if isinstance(x,(int,float)) else sum(y for y in x if isinstance(y,(int,float)))/max(len(x),1) for x in (s.values() if isinstance(s,dict) else s)];print('%.6f'%(sum(v)/max(len(v),1)))" "$1" 2>/dev/null; }
ev(){ local tag=$1 mp=$2 tg=$3 nth=$4 sd=$5
  local prod=$ROOT/ckpts/$1/global_step_$5/evaluation/scores.json rc
  [ -f "$prod" ] && { say "SKIP $1@$5"; return 0; }
  wait_free 0
  say "REVAL $1 seed=$5"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0 NCCL_P2P_DISABLE=1 HF_HOME=$ROOT/hf_cache \
    PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH RAY_ADDRESS=local PYTHONUNBUFFERED=1 \
    bash scripts/textgame_eval.sh --model "$2" --exp_name $1 --nnodes 1 --use_bsl true \
    --max_response_length 1024 --textgame_name $3 --textgame_max_steps 5 --textgame_no_think $4 \
    --ckpt $5 trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.85 \
    +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
    +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
    > $LOGD/theta_reval_${1}_$5.log 2>&1)
  rc=$?
  [ -f "$prod" ] && { say "RESULT $1 seed=$5 score=$(score_of $prod) rc=$rc"; return 0; }
  say "REVAL $1@$5 FAIL rc=$rc"; return 0
}

say "==== Θ-P10b start (pid $$): GPU0 门控,头条复评 5 次 ===="
ev reval-sk-r3 $ROOT/ckpts/theta-sk-refresh-r3/best/actor/huggingface  Sokoban-v0      True  41
ev reval-sk-r3 $ROOT/ckpts/theta-sk-refresh-r3/best/actor/huggingface  Sokoban-v0      True  42
ev reval-fl-r4 $ROOT/ckpts/theta-fl-refresh-r4/best/actor/huggingface  FrozenLake-v0-raw False 41
ev reval-fl-s3 $ROOT/ckpts/theta-fl-static-r3/best/actor/huggingface   FrozenLake-v0-raw False 41
ev reval-sk-s2 $ROOT/ckpts/theta-sk-static-r2/best/actor/huggingface   Sokoban-v0      True  41
say "==== Θ-P10b ALL_DONE(对照: sk-r3=0.531 fl-r4=0.336 fl-s3=0.102 sk-s2=0.352) ===="
