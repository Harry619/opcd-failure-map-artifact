#!/bin/bash
# Θ-P11:崩溃模型上下文恢复测试(GPU2 门控,2026-10-01)
# 给崩溃的 static 模型把原经验加回上下文做全游戏 128-env 评测:
# 恢复→权重未坏仅内化通道断裂;仍零→权重损坏。Θ 机制判据。
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p11_status.log
PY=/home/user-b/miniconda3/envs/opcd/bin/python
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free 2 && { sleep 45; is_free 2 && return 0; }; sleep 60; done; }
score_of(){ $PY -c "import json,sys;s=json.load(open(sys.argv[1]));v=[x if isinstance(x,(int,float)) else sum(y for y in x if isinstance(y,(int,float)))/max(len(x),1) for x in (s.values() if isinstance(s,dict) else s)];print('%.6f'%(sum(v)/max(len(v),1)))" "$1" 2>/dev/null; }
ic(){ local tag=$1 mp=$2 prod=$ROOT/ckpts/$1/global_step_0/evaluation/scores.json util rc
  [ -f "$prod" ] && { say "SKIP $tag"; return 0; }
  for util in 0.85 0.90; do
    wait_free 2
    say "RECOVER $tag start util=$util"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 NCCL_P2P_DISABLE=1 HF_HOME=$ROOT/hf_cache \
      PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH RAY_ADDRESS=local PYTHONUNBUFFERED=1 \
      bash scripts/textgame_eval.sh --model "$mp" --exp_name $tag --nnodes 1 --ckpt 0 --use_bsl true \
      --max_response_length 1024 --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 --textgame_no_think False \
      trainer.eval_prepend_experience=True trainer.experience_path=$ROOT/runs/fl_exp26.txt \
      trainer.experience_max_length=8192 data.max_prompt_length=10752 \
      trainer.textgame_max_prompt_length=10752 \
      actor_rollout_ref.rollout.max_num_batched_tokens=11776 \
      actor_rollout_ref.rollout.gpu_memory_utilization=$util \
      trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
      +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
      +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
      > $LOGD/theta_recover_${tag}.log 2>&1)
    rc=$?
    [ -f "$prod" ] && { say "RESULT $tag with-ctx=$(score_of $prod) rc=$rc"; return 0; }
    say "RECOVER $tag FAIL rc=$rc util=$util"; sleep 20
  done
  return 0
}

say "==== Θ-P11 start (pid $$): GPU2 门控,崩溃模型±上下文恢复 4 组 ===="
say "对照(无上下文原值): s3=0.102 s3b=0.000 s3c=0.031 s4=0.000"
ic recover_s3  $ROOT/ckpts/theta-fl-static-r3/best/actor/huggingface
ic recover_s3b $ROOT/ckpts/theta-fl-static-r3b/best/actor/huggingface
ic recover_s3c $ROOT/ckpts/theta-fl-static-r3c/best/actor/huggingface
ic recover_s4  $ROOT/ckpts/theta-fl-static-r4/best/actor/huggingface
say "==== Θ-P11 ALL_DONE ===="
