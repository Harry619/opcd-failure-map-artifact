#!/bin/bash
# Θ-P1 探针驱动(GPU2 门控,2026-09-30):E1b/E1d 队列的任何空窗自动回填测量
# 逐模型加载 vLLM(每模型独立进程,显存即时释放),产物 runs/theta_p1_probe/<tag>.json 幂等跳过
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p1_status.log
PY=/home/user-b/miniconda3/envs/opcd/bin/python
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free 2 && { sleep 60; is_free 2 && return 0; }; sleep 60; done; }

say "==== Θ-P1 probe start (pid $$): GPU2 门控,9 模型对齐度测量 ===="
probe(){ local tag=$1 mp=$2 ep=$3 rc
  [ -f $ROOT/runs/theta_p1_probe/$tag.json ] && { say "SKIP $tag"; return 0; }
  wait_free 2
  say "PROBE $tag start (GPU2)"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 HF_HOME=$ROOT/hf_cache \
    $PY $ROOT/scripts/theta_p1_probe.py "$tag" "$mp" "$ep" >> $LOGD/theta_probe.log 2>&1)
  rc=$?
  grep "DONE $tag\|Error\|Traceback" $LOGD/theta_probe.log 2>/dev/null | tail -1 | while read -r l; do say "$l"; done
  say "PROBE $tag rc=$rc"
  return 0
}

B=$ROOT/models/Qwen3-1.7B; FE=$ROOT/runs/fl_exp26.txt
probe base      $B $FE
probe refresh_M1 $ROOT/ckpts/fl-q3-1b7-consol2/best/actor/huggingface $FE
probe refresh_M2 $ROOT/ckpts/theta-fl-refresh-r2/best/actor/huggingface $ROOT/runs/theta_theta-fl-r2ext_best.txt
probe refresh_M3 $ROOT/ckpts/theta-fl-refresh-r3/best/actor/huggingface $ROOT/runs/theta_theta-fl-r3ext_best.txt
probe refresh_M4 $ROOT/ckpts/theta-fl-refresh-r4/best/actor/huggingface $ROOT/runs/theta_theta-fl-r4ext_best.txt
probe refresh_M5 $ROOT/ckpts/theta-fl-refresh-r5/best/actor/huggingface $ROOT/runs/theta_theta-fl-r5ext_best.txt
probe static_M2s $ROOT/ckpts/theta-fl-static-r2/best/actor/huggingface $FE
probe static_s3  $ROOT/ckpts/theta-fl-static-r3/best/actor/huggingface $FE
probe static_s3b $ROOT/ckpts/theta-fl-static-r3b/best/actor/huggingface $FE
say "==== Θ-P1 ALL_DONE — 汇总: grep DONE $LOGD/theta_probe.log ===="
$PY - <<'EOF'
import json,glob
rows=[]
for f in sorted(glob.glob("/home/user-b/OPCD/runs/theta_p1_probe/*.json")):
    d=json.load(open(f))
    a=d["alignment"]
    rows.append((d["tag"],d["student"]["valid_rate"],d["teacher"]["valid_rate"],a["mean_jsd"],a["top_agree_rate"]))
print(f"{'tag':14s} stu_valid tea_valid  jsd     agree")
for r in rows: print(f"{r[0]:14s} {r[1]:8} {r[2]:9} {r[3]:7} {r[4]:6}")
EOF
