#!/usr/bin/env python
# Θ-P1 师生对齐度探针(2026-09-30 ZCode):单卡 vLLM 离线测量 M_k±经验 的行为分布对齐度
# 用法: theta_p1_probe.py <tag> <model_path> [exp_path]   → runs/theta_p1_probe/<tag>.json
# 度量: ①student(无经验)/teacher(有经验,system 注入,训练同构)各 8 采样×固定 24 状态
#       ②valid_rate/动作直方图/长度 ③per-state JSD + top-action 一致率 = 可达性/可导性观测量
import json, os, re, sys, math
from collections import Counter
from vllm import LLM, SamplingParams
from transformers import AutoTokenizer

ROOT = "/home/user-b/OPCD"
OUT = f"{ROOT}/runs/theta_p1_probe"; os.makedirs(OUT, exist_ok=True)

def load_states():
    p = f"{ROOT}/ckpts/theta-fl-refresh-r2-eval/global_step_50/evaluation/fixed_samples.json"
    samples = json.load(open(p))
    firsts = [s["prompt"] for s in samples if s["prompt"].lstrip().startswith("Step 0")]
    states = firsts if len(firsts) >= 8 else [s["prompt"] for s in samples]
    return states[:24]

ACT = re.compile(r"\[(up|down|left|right|w|a|s|d)\]", re.I)
def parse_action(t):
    m = ACT.search(t)
    return m.group(1).lower() if m else None

def jsd(c1, c2):
    d = 0.0; n1, n2 = sum(c1.values()) or 1, sum(c2.values()) or 1
    for k in set(c1) | set(c2):
        p = c1.get(k, 0)/n1; q = c2.get(k, 0)/n2; m = (p+q)/2
        if p > 0: d += 0.5*p*math.log(p/m)
        if q > 0: d += 0.5*q*math.log(q/m)
    return d

def run(tag, model_path, exp_path):
    outj = f"{OUT}/{tag}.json"
    if os.path.exists(outj):
        print(f"SKIP {tag} (产物在)"); return 0
    states = load_states()
    tok = AutoTokenizer.from_pretrained(model_path)
    exp_text = open(exp_path).read() if exp_path else None
    def build(content, exp):
        msgs = ([{"role": "system", "content": exp}] if exp else []) + [{"role": "user", "content": content}]
        return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True, enable_thinking=True)
    ps = [build(c, None) for c in states] + [build(c, exp_text) for c in states]
    llm = LLM(model=model_path, gpu_memory_utilization=0.85, max_model_len=13312,
              enforce_eager=True, trust_remote_code=True)
    sp = SamplingParams(n=8, temperature=0.7, top_p=0.8, max_tokens=1024, seed=1234)
    rs = llm.generate(ps, sp)
    n = len(states); res = {"tag": tag, "model": model_path, "exp": exp_path, "n_states": n}
    for cond, off in (("student", 0), ("teacher", n)):
        outs = [o for r in rs[off:off+n] for o in r.outputs]
        acts = [parse_action(o.text) for o in outs]
        res[cond] = {"valid_rate": round(sum(a is not None for a in acts)/len(acts), 4),
                     "mean_len": round(sum(len(o.text) for o in outs)/len(outs), 1),
                     "action_hist": dict(Counter(a for a in acts if a))}
    per = []
    for i in range(n):
        c1 = Counter(filter(None, (parse_action(o.text) for o in rs[i].outputs)))
        c2 = Counter(filter(None, (parse_action(o.text) for o in rs[n+i].outputs)))
        t1 = c1.most_common(1)[0][0] if c1 else None
        t2 = c2.most_common(1)[0][0] if c2 else None
        per.append({"jsd": round(jsd(c1, c2), 4), "top_agree": int(t1 == t2 and t1 is not None)})
    res["alignment"] = {"mean_jsd": round(sum(p["jsd"] for p in per)/n, 4),
                        "top_agree_rate": round(sum(p["top_agree"] for p in per)/n, 4)}
    json.dump(res, open(outj, "w"), ensure_ascii=False, indent=1)
    print(f"DONE {tag}: stu_valid={res['student']['valid_rate']} tea_valid={res['teacher']['valid_rate']} "
          f"jsd={res['alignment']['mean_jsd']} agree={res['alignment']['top_agree_rate']}")
    return 0

if __name__ == "__main__":
    tag, mp = sys.argv[1], sys.argv[2]
    ep = sys.argv[3] if len(sys.argv) > 3 else ""
    sys.exit(run(tag, mp, ep or None))
