#!/bin/bash
# Θ-P2:Sokoban 域对齐度探针(GPU0 门控,2026-09-30):回填 E1d 单卡提取窗口/相位间隙
# 模型缺失(如 r3/s2/s3 尚未训完)时轮询等待其出现(上限 20h),逐模型幂等
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p2_status.log
PY=/home/user-b/miniconda3/envs/opcd/bin/python
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free 0 && { sleep 60; is_free 0 && return 0; }; sleep 60; done; }
wait_model(){ local mp=$1 t=0
  while [ ! -d "$mp" ] && [ $t -lt 1200 ]; do [ $((t%12)) -eq 0 ] && say "WAIT model $mp"; sleep 600; t=$((t+1)); done
  [ -d "$mp" ] || { say "TIMEOUT model $mp 不存在,跳过"; return 1; }
  return 0
}
probe(){ local tag=$1 mp=$2 ep=$3 rc
  [ -f $ROOT/runs/theta_p1_probe/$tag.json ] && { say "SKIP $tag"; return 0; }
  wait_model "$mp" || return 0
  wait_free 0
  say "PROBE $tag start (GPU0)"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0 HF_HOME=$ROOT/hf_cache \
    $PY $ROOT/scripts/theta_p2_probe_sk.py "$tag" "$mp" "$ep" >> $LOGD/theta_probe2.log 2>&1)
  rc=$?
  tail -1 $LOGD/theta_probe2.log 2>/dev/null | cut -c1-140 | while read -r l; do say "$l"; done
  say "PROBE $tag rc=$rc"; return 0
}

say "==== Θ-P2 probe start (pid $$): GPU0 门控,SK 域 7 模型对齐度测量 ===="
SB=$ROOT/models/Qwen3-4B-Instruct-2507; SE=$ROOT/runs/sk_exp2.txt
probe sk_base $SB $SE
probe sk_M1 $ROOT/ckpts/sk-q3-4b-consol2/best/actor/huggingface $SE
probe sk_r2 $ROOT/ckpts/theta-sk-refresh-r2/best/actor/huggingface $ROOT/runs/theta_theta-sk-r2ext_best.txt
probe sk_r3 $ROOT/ckpts/theta-sk-refresh-r3/best/actor/huggingface $ROOT/runs/theta_theta-sk-r3ext_best.txt
probe sk_s2 $ROOT/ckpts/theta-sk-static-r2/best/actor/huggingface $SE
probe sk_s3 $ROOT/ckpts/theta-sk-static-r3/best/actor/huggingface $SE
say "==== Θ-P2 ALL_DONE ===="
