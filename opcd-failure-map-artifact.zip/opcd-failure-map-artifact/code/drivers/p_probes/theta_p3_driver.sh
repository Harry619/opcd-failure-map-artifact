#!/bin/bash
# Θ-P3:经验质量分解探针(GPU0 门控,2026-09-30):把每轮选出的最优经验放回基座模型测
# 目的:分离池分数上涨中"经验文本质量"与"模型能力演化"的贡献(基座+exp_k vs M_k+exp_k 对照)
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p3_status.log
PY=/home/user-b/miniconda3/envs/opcd/bin/python
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free 0 && { sleep 45; is_free 0 && return 0; }; sleep 60; done; }

say "==== Θ-P3 start (pid $$): GPU0 门控,基座×逐轮经验 分解测量 ===="
FB=$ROOT/models/Qwen3-1.7B; FE=$ROOT/runs/fl_exp26.txt
probe_fl(){ local tag=$1 ep=$2
  [ -f $ROOT/runs/theta_p1_probe/$tag.json ] && { say "SKIP $tag"; return 0; }
  wait_free 0
  say "PROBE $tag start"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0 HF_HOME=$ROOT/hf_cache \
    $PY $ROOT/scripts/theta_p1_probe.py "$tag" "$FB" "$ep" >> $LOGD/theta_probe3.log 2>&1)
  say "PROBE $tag rc=$?"
}
probe_fl baseexp_fl_r1 $FE
probe_fl baseexp_fl_r2 $ROOT/runs/theta_theta-fl-r2ext_best.txt
probe_fl baseexp_fl_r3 $ROOT/runs/theta_theta-fl-r3ext_best.txt
probe_fl baseexp_fl_r4 $ROOT/runs/theta_theta-fl-r4ext_best.txt
probe_fl baseexp_fl_r5 $ROOT/runs/theta_theta-fl-r5ext_best.txt
probe_fl baseexp_fl_r6 $ROOT/runs/theta_theta-fl-r6ext_best.txt

SB=$ROOT/models/Qwen3-4B-Instruct-2507; SE=$ROOT/runs/sk_exp2.txt
probe_sk(){ local tag=$1 ep=$2
  [ -f $ROOT/runs/theta_p1_probe/$tag.json ] && { say "SKIP $tag"; return 0; }
  wait_free 0
  say "PROBE $tag start"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0 HF_HOME=$ROOT/hf_cache \
    $PY $ROOT/scripts/theta_p2_probe_sk.py "$tag" "$SB" "$ep" >> $LOGD/theta_probe3.log 2>&1)
  say "PROBE $tag rc=$?"
}
probe_sk baseexp_sk_r1 $SE
probe_sk baseexp_sk_r2 $ROOT/runs/theta_theta-sk-r2ext_best.txt
probe_sk baseexp_sk_r3 $ROOT/runs/theta_theta-sk-r3ext_best.txt
say "==== Θ-P3 ALL_DONE ===="
