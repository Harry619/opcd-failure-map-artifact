#!/bin/bash
# Θ-P4:探针族扩展队列(GPU0 门控,2026-09-30,用户要求多排短时程序)
# 18 个短程序(每个 2-5 分钟):救援(3) + 交叉臂(3) + 中局状态(7) + 贪心解码(5)
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p4_status.log
PY=/home/user-b/miniconda3/envs/opcd/bin/python
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free 0 && { sleep 45; is_free 0 && return 0; }; sleep 60; done; }

run(){ local tag=$1 mp=$2 ep=$3 mode=$4
  [ -f $ROOT/runs/theta_p1_probe/$tag.json ] && { say "SKIP $tag"; return 0; }
  wait_free 0
  say "PROBE $tag start ${mode:+mode=$mode}"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0 HF_HOME=$ROOT/hf_cache \
    $PY $ROOT/scripts/theta_p1_probe_v2.py "$tag" "$mp" "$ep" "$mode" >> $LOGD/theta_probe4.log 2>&1)
  say "PROBE $tag rc=$?"
}

FB=$ROOT/models/Qwen3-1.7B; FE=$ROOT/runs/fl_exp26.txt
R5E=$ROOT/runs/theta_theta-fl-r5ext_best.txt; R6E=$ROOT/runs/theta_theta-fl-r6ext_best.txt; R3E=$ROOT/runs/theta_theta-fl-r3ext_best.txt
M1=$ROOT/ckpts/fl-q3-1b7-consol2/best/actor/huggingface
M3=$ROOT/ckpts/theta-fl-refresh-r3/best/actor/huggingface
M5=$ROOT/ckpts/theta-fl-refresh-r5/best/actor/huggingface
S3=$ROOT/ckpts/theta-fl-static-r3/best/actor/huggingface
S3B=$ROOT/ckpts/theta-fl-static-r3b/best/actor/huggingface
M2S=$ROOT/ckpts/theta-fl-static-r2/best/actor/huggingface

say "==== Θ-P4 start (pid $$): GPU0 门控,18 短程序(救援/交叉/中局/贪心) ===="

# --- 救援:崩溃模型 + 新鲜经验 ---
run rescue_s3_r5exp  $S3  $R5E full
run rescue_s3_r6exp  $S3  $R6E full
run rescue_s3b_r6exp $S3B $R6E full

# --- 交叉臂:对方臂的经验能否导控 ---
run cross_M3_staleexp  $M3  $FE full
run cross_M5_staleexp  $M5  $FE full
run cross_M2s_r5exp    $M2S $R5E full

# --- 中局状态(非首轮) ---
run late_base      $FB  $FE late
run late_refresh_M1 $M1 $FE late
run late_refresh_M3 $M3 $R3E late
run late_refresh_M5 $M5 $R5E late
run late_static_s3  $S3 $FE late
run late_sk_M1 $ROOT/ckpts/sk-q3-4b-consol2/best/actor/huggingface $ROOT/runs/sk_exp2.txt late
run late_sk_r2 $ROOT/ckpts/theta-sk-refresh-r2/best/actor/huggingface $ROOT/runs/theta_theta-sk-r2ext_best.txt late

# --- 贪心解码(argmax 行为) ---
run greedy_base       $FB  $FE greedy
run greedy_refresh_M1 $M1  $FE greedy
run greedy_refresh_M3 $M3  $R3E greedy
run greedy_refresh_M5 $M5  $R5E greedy
run greedy_static_s3  $S3  $FE greedy

say "==== Θ-P4 ALL_DONE ===="
