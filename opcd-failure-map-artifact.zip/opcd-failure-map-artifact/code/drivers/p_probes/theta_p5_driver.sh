#!/bin/bash
# Θ-P5:经验池分布探针(GPU0 门控,2026-09-30):基座×池内全部候选,画池质量分布演化
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p5_status.log
PY=/home/user-b/miniconda3/envs/opcd/bin/python
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free 0 && { sleep 45; is_free 0 && return 0; }; sleep 60; done; }
run(){ local tag=$1 mp=$2 ep=$3 scr=$4
  [ -f $ROOT/runs/theta_p1_probe/$tag.json ] && { say "SKIP $tag"; return 0; }
  wait_free 0
  say "PROBE $tag start"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=0 HF_HOME=$ROOT/hf_cache \
    $PY $ROOT/scripts/$scr "$tag" "$mp" "$ep" full >> $LOGD/theta_probe5.log 2>&1)
  say "PROBE $tag rc=$?"
}

FB=$ROOT/models/Qwen3-1.7B; SB=$ROOT/models/Qwen3-4B-Instruct-2507
say "==== Θ-P5 start (pid $$): GPU0 门控,池分布 30 候选 ===="
for pool in fl-r2:902:theta-fl-r2ext fl-r6:906:theta-fl-r6ext; do
  tagp=${pool%%:*}; rest=${pool#*:}; lbl=${rest%%:*}; dir=${rest#*:}
  for i in $(seq 1 10); do
    ep=$ROOT/ckpts/$dir/global_step_$lbl/extract_10_samples/experiences/experience_${i}.txt
    [ -f "$ep" ] && run pooldist_${tagp}_e$i $FB "$ep" theta_p1_probe_v2.py
  done
done
for i in $(seq 1 10); do
  ep=$ROOT/ckpts/theta-sk-r2ext/global_step_912/extract_10_samples/experiences/experience_${i}.txt
  [ -f "$ep" ] && run pooldist_sk-r2_e$i $SB "$ep" theta_p2_probe_sk.py
done
say "==== Θ-P5 ALL_DONE ===="
$PY - <<'EOF'
import json,glob,collections
for grp in ["fl-r2","fl-r6","sk-r2"]:
    vals=[]
    for f in sorted(glob.glob(f"/home/user-b/OPCD/runs/theta_p1_probe/pooldist_{grp}_e*.json")):
        d=json.load(open(f)); vals.append(d["teacher"]["valid_rate"])
    if vals: print(grp,"n=",len(vals),"tea_valid mean=%.3f"%((sum(vals)/len(vals)),))
EOF
