#!/bin/bash
# Θ-P6:经验截断 + 跨域导控探针(GPU1 门控,2026-09-30):导控信号定位与跨域可迁移性
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p6_status.log
PY=/home/user-b/miniconda3/envs/opcd/bin/python
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free 1 && { sleep 45; is_free 1 && return 0; }; sleep 60; done; }
run(){ local tag=$1 mp=$2 ep=$3 scr=$4
  [ -f $ROOT/runs/theta_p1_probe/$tag.json ] && { say "SKIP $tag"; return 0; }
  wait_free 1
  say "PROBE $tag start"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=1 HF_HOME=$ROOT/hf_cache \
    $PY $ROOT/scripts/$scr "$tag" "$mp" "$ep" full >> $LOGD/theta_probe6.log 2>&1)
  say "PROBE $tag rc=$?"
}

FB=$ROOT/models/Qwen3-1.7B; SB=$ROOT/models/Qwen3-4B-Instruct-2507
M1=$ROOT/ckpts/fl-q3-1b7-consol2/best/actor/huggingface
FE=$ROOT/runs/fl_exp26.txt; SE=$ROOT/runs/sk_exp2.txt
TD=$ROOT/runs/theta_trunc; mkdir -p $TD

say "==== Θ-P6 start (pid $$): GPU1 门控,截断 3 + 跨域 4 ===="
# 截断准备(字符比例,保持头部)
$PY - <<'EOF'
src=open("/home/user-b/OPCD/runs/fl_exp26.txt",encoding="utf-8").read()
for q in (25,50,75):
    open(f"/home/user-b/OPCD/runs/theta_trunc/exp{q}.txt","w",encoding="utf-8").write(src[:int(len(src)*q/100)])
print("TRUNC_READY", len(src))
EOF
say "截断文件就绪"
run trunc25_M1 $M1 $TD/exp25.txt theta_p1_probe_v2.py
run trunc50_M1 $M1 $TD/exp50.txt theta_p1_probe_v2.py
run trunc75_M1 $M1 $TD/exp75.txt theta_p1_probe_v2.py

# 跨域导控
run xdom_FLbase_SKexp  $FB $SE theta_p1_probe_v2.py
run xdom_FLbase_SKr2exp $FB $ROOT/runs/theta_theta-sk-r2ext_best.txt theta_p1_probe_v2.py
run xdom_SKbase_FLexp  $SB $FE theta_p2_probe_sk.py
run xdom_SKbase_FLr5exp $SB $ROOT/runs/theta_theta-fl-r5ext_best.txt theta_p2_probe_sk.py
say "==== Θ-P6 ALL_DONE ===="
