#!/bin/bash
# Θ-P7:逐代经验 In-Context 基线(全游戏 128 env,复用论文口径 ic 调用,2026-09-30)
# FL 六代经验上 GPU0 门控,SK 三代经验上 GPU1 门控;输出论文级 IC 分数分解池演化
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p7_status.log
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ local g=$1; while :; do is_free $g && { sleep 45; is_free $g && return 0; }; sleep 60; done; }
PY=/home/user-b/miniconda3/envs/opcd/bin/python
score_of(){ $PY -c "import json,sys;s=json.load(open(sys.argv[1]));v=[x if isinstance(x,(int,float)) else sum(y for y in x if isinstance(y,(int,float)))/max(len(x),1) for x in (s.values() if isinstance(s,dict) else s)];print('%.6f'%(sum(v)/max(len(v),1)))" "$1" 2>/dev/null; }

ic_run(){ # $1=gpu $2=tag $3=model $4=exp $5=textgame $6=nothink
  local g=$1 tag=$2 model=$3 exp=$4 tg=$5 nth=$6 prod=$ROOT/ckpts/$2/global_step_0/evaluation/scores.json util rc
  [ -f "$prod" ] && { say "SKIP $tag"; return 0; }
  for util in 0.85 0.90; do
    wait_free $g
    say "IC $tag start gpu$g util=$util"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=$g NCCL_P2P_DISABLE=1 HF_HOME=$ROOT/hf_cache \
      PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH RAY_ADDRESS=local PYTHONUNBUFFERED=1 \
      bash scripts/textgame_eval.sh --model "$model" --exp_name $tag --nnodes 1 --ckpt 0 --use_bsl true \
      --max_response_length 1024 --textgame_name $tg --textgame_max_steps 5 --textgame_no_think $nth \
      trainer.eval_prepend_experience=True \
      trainer.experience_path=$exp \
      trainer.experience_max_length=8192 data.max_prompt_length=10752 \
      trainer.textgame_max_prompt_length=10752 \
      actor_rollout_ref.rollout.max_num_batched_tokens=11776 \
      actor_rollout_ref.rollout.gpu_memory_utilization=$util \
      trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
      +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
      +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
      > $LOGD/theta_ic_${tag}.log 2>&1)
    rc=$?
    [ -f "$prod" ] && { say "RESULT $tag ic=$(score_of $prod) rc=$rc"; return 0; }
    say "IC $tag FAIL rc=$rc util=$util"; sleep 20
  done
  say "IC $tag 两档均败"; return 0
}

FB=$ROOT/models/Qwen3-1.7B; SB=$ROOT/models/Qwen3-4B-Instruct-2507
say "==== Θ-P7 start (pid $$): IC 基线 9 组(FL@GPU0, SK@GPU1) ===="
ic_run 0 icb-fl-r1 $FB $ROOT/runs/fl_exp26.txt FrozenLake-v0-raw False
ic_run 0 icb-fl-r2 $FB $ROOT/runs/theta_theta-fl-r2ext_best.txt FrozenLake-v0-raw False
ic_run 0 icb-fl-r3 $FB $ROOT/runs/theta_theta-fl-r3ext_best.txt FrozenLake-v0-raw False
ic_run 0 icb-fl-r4 $FB $ROOT/runs/theta_theta-fl-r4ext_best.txt FrozenLake-v0-raw False
ic_run 0 icb-fl-r5 $FB $ROOT/runs/theta_theta-fl-r5ext_best.txt FrozenLake-v0-raw False
ic_run 0 icb-fl-r6 $FB $ROOT/runs/theta_theta-fl-r6ext_best.txt FrozenLake-v0-raw False
ic_run 1 icb-sk-r1 $SB $ROOT/runs/sk_exp2.txt Sokoban-v0 True
ic_run 1 icb-sk-r2 $SB $ROOT/runs/theta_theta-sk-r2ext_best.txt Sokoban-v0 True
ic_run 1 icb-sk-r3 $SB $ROOT/runs/theta_theta-sk-r3ext_best.txt Sokoban-v0 True
say "==== Θ-P7 ALL_DONE ===="
