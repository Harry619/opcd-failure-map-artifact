#!/bin/bash
# Θ-P8:评测噪声标定(GPU1 门控,2026-09-30):同模型不同 rollout 种子 × 终评,量 128-env 协议噪声带
# base×5 seed + M1×3 seed;所有曲线的 ±判定以此为实测依据
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p8_status.log
PY=/home/user-b/miniconda3/envs/opcd/bin/python
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free 1 && { sleep 45; is_free 1 && return 0; }; sleep 60; done; }
score_of(){ $PY -c "import json,sys;s=json.load(open(sys.argv[1]));v=[x if isinstance(x,(int,float)) else sum(y for y in x if isinstance(y,(int,float)))/max(len(x),1) for x in (s.values() if isinstance(s,dict) else s)];print('%.6f'%(sum(v)/max(len(v),1)))" "$1" 2>/dev/null; }

ev(){ # $1=tag $2=model $3=seed
  local prod=$ROOT/ckpts/$1/global_step_$3/evaluation/scores.json rc
  [ -f "$prod" ] && { say "SKIP $1@$3"; return 0; }
  wait_free 1
  say "EVAL $1 seed=$3"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=1 NCCL_P2P_DISABLE=1 HF_HOME=$ROOT/hf_cache \
    PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH RAY_ADDRESS=local PYTHONUNBUFFERED=1 \
    bash scripts/textgame_eval.sh --model "$2" --exp_name $1 --nnodes 1 --use_bsl true \
    --max_response_length 1024 --textgame_name FrozenLake-v0-raw --textgame_max_steps 5 \
    --textgame_no_think False --ckpt $3 \
    trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.85 \
    +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
    +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
    > $LOGD/theta_noise_${1}_$3.log 2>&1)
  rc=$?
  [ -f "$prod" ] && { say "RESULT $1 seed=$3 score=$(score_of $prod) rc=$rc"; return 0; }
  say "EVAL $1@$3 FAIL rc=$rc"; return 0
}

FB=$ROOT/models/Qwen3-1.7B
M1=$ROOT/ckpts/fl-q3-1b7-consol2/best/actor/huggingface
say "==== Θ-P8 start (pid $$): GPU1 门控,噪声标定 8 次 ===="
for s in 41 42 43 44 45; do ev noisecal-base $FB $s; done
for s in 41 42 43; do ev noisecal-m1 $M1 $s; done
say "==== Θ-P8 ALL_DONE — 汇总: ===="
for f in $ROOT/ckpts/noisecal-base/global_step_*/evaluation/scores.json $ROOT/ckpts/noisecal-m1/global_step_*/evaluation/scores.json; do
  echo "$(basename $(dirname $(dirname $(dirname $f))))/$(basename $(dirname $(dirname $f))): $(score_of $f)"
done
