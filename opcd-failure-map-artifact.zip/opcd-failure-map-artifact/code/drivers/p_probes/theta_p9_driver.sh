#!/bin/bash
# Θ-P9:GPU2 单卡回填队列(2026-10-01 ZCode,用户夜间排队指令)
# 内容:sk_r3 探针 → SK 池分布 10 候选 → SK IC 基线 3 组 → 等待 sk_s2/s3 模型探针
# 门控 GPU2;产物与 P2/P5/P7 共享,幂等不重复
ROOT=/home/user-b/OPCD; LOGD=$ROOT/logs; ST=$LOGD/theta_p9_status.log
PY=/home/user-b/miniconda3/envs/opcd/bin/python
say(){ echo "[$(date '+%F %T')] $1" | tee -a "$ST"; }
is_free(){ local pids p busy mem
  pids=$(nvidia-smi -i $1 --query-compute-apps=pid --format=csv,noheader 2>/dev/null|tr -d " ")
  [ -z "$pids" ] && return 0
  busy=0
  for p in $pids; do tr "\0" " " </proc/$p/cmdline 2>/dev/null|grep -qE "verl|ray|main_ppo|vllm" && busy=1; done
  [ $busy -eq 1 ] && return 1
  mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $1)
  [ "$mem" -lt 8000 ] && return 0; return 1
}
wait_free(){ while :; do is_free 2 && { sleep 45; is_free 2 && return 0; }; sleep 60; done; }
wait_model(){ local mp=$1 t=0
  while [ ! -d "$mp" ] && [ $t -lt 120 ]; do [ $((t%6)) -eq 0 ] && say "WAIT model $mp"; sleep 600; t=$((t+1)); done
  [ -d "$mp" ] || { say "TIMEOUT $mp,跳过"; return 1; }
  return 0
}
run(){ local tag=$1 mp=$2 ep=$3 scr=$4
  [ -f $ROOT/runs/theta_p1_probe/$tag.json ] && { say "SKIP $tag"; return 0; }
  wait_free 2
  say "PROBE $tag start"
  (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 HF_HOME=$ROOT/hf_cache \
    $PY $ROOT/scripts/$scr "$tag" "$mp" "$ep" full >> $LOGD/theta_probe9.log 2>&1)
  say "PROBE $tag rc=$?"
}
score_of(){ $PY -c "import json,sys;s=json.load(open(sys.argv[1]));v=[x if isinstance(x,(int,float)) else sum(y for y in x if isinstance(y,(int,float)))/max(len(x),1) for x in (s.values() if isinstance(s,dict) else s)];print('%.6f'%(sum(v)/max(len(v),1)))" "$1" 2>/dev/null; }
ic(){ local tag=$1 ep=$2 prod=$ROOT/ckpts/$1/global_step_0/evaluation/scores.json util rc
  [ -f "$prod" ] && { say "SKIP $tag"; return 0; }
  for util in 0.85 0.90; do
    wait_free 2
    say "IC $tag start util=$util"
    (cd $ROOT/opcd && CUDA_VISIBLE_DEVICES=2 NCCL_P2P_DISABLE=1 HF_HOME=$ROOT/hf_cache \
      PATH=/home/user-b/miniconda3/envs/opcd/bin:$PATH RAY_ADDRESS=local PYTHONUNBUFFERED=1 \
      bash scripts/textgame_eval.sh --model $ROOT/models/Qwen3-4B-Instruct-2507 --exp_name $tag --nnodes 1 --ckpt 0 --use_bsl true \
      --max_response_length 1024 --textgame_name Sokoban-v0 --textgame_max_steps 5 --textgame_no_think True \
      trainer.eval_prepend_experience=True trainer.experience_path=$ep \
      trainer.experience_max_length=8192 data.max_prompt_length=10752 \
      trainer.textgame_max_prompt_length=10752 \
      actor_rollout_ref.rollout.max_num_batched_tokens=11776 \
      actor_rollout_ref.rollout.gpu_memory_utilization=$util \
      trainer.n_gpus_per_node=1 ray_init.num_cpus=4 \
      +actor_rollout_ref.rollout.engine_kwargs.vllm.max_num_seqs=16 \
      +actor_rollout_ref.actor.fsdp_config.model_dtype=bf16 \
      > $LOGD/theta_ic_${tag}.log 2>&1)
    rc=$?
    [ -f "$prod" ] && { say "RESULT $tag ic=$(score_of $prod)"; return 0; }
    say "IC $tag FAIL rc=$rc util=$util"; sleep 20
  done
  return 0
}

SB=$ROOT/models/Qwen3-4B-Instruct-2507; SE=$ROOT/runs/sk_exp2.txt
say "==== Θ-P9 start (pid $$): GPU2 门控,SK 探针/池分布/IC 队列 ===="
run sk_r3 $ROOT/ckpts/theta-sk-refresh-r3/best/actor/huggingface $ROOT/runs/theta_theta-sk-r3ext_best.txt theta_p2_probe_sk.py
for i in $(seq 1 10); do
  ep=$ROOT/ckpts/theta-sk-r2ext/global_step_912/extract_10_samples/experiences/experience_${i}.txt
  [ -f "$ep" ] && run pooldist_sk-r2_e$i $SB "$ep" theta_p2_probe_sk.py
done
ic icb-sk-r1 $SE
ic icb-sk-r2 $ROOT/runs/theta_theta-sk-r2ext_best.txt
ic icb-sk-r3 $ROOT/runs/theta_theta-sk-r3ext_best.txt
if wait_model $ROOT/ckpts/theta-sk-static-r2/best/actor/huggingface; then
  run sk_s2 $ROOT/ckpts/theta-sk-static-r2/best/actor/huggingface $SE theta_p2_probe_sk.py
fi
if wait_model $ROOT/ckpts/theta-sk-static-r3/best/actor/huggingface; then
  run sk_s3 $ROOT/ckpts/theta-sk-static-r3/best/actor/huggingface $SE theta_p2_probe_sk.py
fi
say "==== Θ-P9 ALL_DONE ===="
