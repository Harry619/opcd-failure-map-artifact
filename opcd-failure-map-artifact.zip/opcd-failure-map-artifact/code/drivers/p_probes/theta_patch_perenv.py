#!/usr/bin/env python3
"""Θ-A1 patch: ray_trainer.py textgame 验证留存区新增逐环境明细.
新增输出: per_env_scores.json / per_env_rewards_raw.json (不动任何已有文件与行为)
安全: 备份 .bak_perenv_20261006; 插入后 py_compile 语法验证, 失败自动回滚; 幂等(已 patch 则跳过).
预注册: 04_笔记/theta_prereg_tier12_20261006.md §三
"""
import py_compile, shutil, sys

P = "/home/user-b/OPCD/opcd/verl/verl/trainer/ppo/ray_trainer.py"
ANCHOR = 'safe_write_json("random_samples.json", saved_samples, indent=2)'

INSERT = '''
                try:
                    _per_env = []
                    for _ei in sorted(env_trajectories.keys()):
                        _t = env_trajectories[_ei]
                        _per_env.append({
                            "env": _ei,
                            "reward": _t.get("reward", 0),
                            "steps": len(_t.get("history", [])),
                            "stop_reason": _t.get("stop_reason", "unknown"),
                        })
                    safe_write_json("per_env_scores.json", _per_env)
                    safe_write_json("per_env_rewards_raw.json", heldout_rewards_all)
                except Exception as _e:
                    print(f"[per_env dump] WARN: {_e}")'''

src = open(P, encoding="utf-8").read()
if "per_env_scores.json" in src:
    print("ALREADY_PATCHED")
    sys.exit(0)
cnt = src.count(ANCHOR)
assert cnt == 1, f"anchor 非唯一(count={cnt}), 中止防误插"
shutil.copy2(P, P + ".bak_perenv_20261006")
patched = src.replace(ANCHOR, ANCHOR + INSERT)
open(P, "w", encoding="utf-8").write(patched)
try:
    py_compile.compile(P, doraise=True)
    print("PATCHED_OK syntax_verified backup=", P + ".bak_perenv_20261006")
except Exception as e:
    shutil.copy2(P + ".bak_perenv_20261006", P)
    print("PATCH_ROLLED_BACK compile_error:", e)
    sys.exit(1)
